import tkinter as tk
from tkinter import ttk, filedialog, messagebox, scrolledtext
import pandas as pd
import os
import numpy as np
import matplotlib.pyplot as plt
import sys
import time
import webbrowser
import platform
import subprocess

# Aggiunge la directory corrente al path per trovare i moduli
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

# Import dai moduli
from device_base import Device
from fuel_generator import FuelGenerator
from pv_generator import PVGenerator
from wind_generator import WindGenerator
from battery import Battery
from load import Load
from grid_connection import GridConnection
from microgrid_on_grid_optimizer import MicrogridOnGridOptimizer
from load import Load

from microgrid_visualization import MicrogridPlotViewer, MicrogridStatistics

class MicrogridOnGridConfigApp:
    def __init__(self, root):
        self.root = root
        self.root.title("On-Grid Microgrid Optimization System")
        self.root.geometry("800x750")
        
        self.excel_filename = ""
        self.weather_filename = ""
        self.load_filename = ""
        self.tariff_filename = ""
        
        # Variabili per le selezioni specifiche
        self.sheet_carico = tk.StringVar(value="")
        self.sheet_meteo = tk.StringVar(value="")
        self.sheet_tariffa = tk.StringVar(value="")  # Rimosso "Tariffa" come default
     
        self.devices = []
        self.device_frames = []
        
        self.load_sheets = []
        self.meteo_sheets = []
        self.device_sheets = []
        self.tariff_sheets = []
        
        # Salva riferimento all'ottimizzatore
        self.optimizer = None
        
        # Aggiunge riferimenti ai visualizzatori
        self.plot_viewer = None
        self.statistics = None
        
        self.create_widgets()
    
    def show_plots_page(self):
        """Mostra i grafici usando l'oggetto MicrogridPlotViewer."""
        if self.plot_viewer and self.optimizer and self.optimizer.results:
            self.plot_viewer.show_plots_page()
        else:
            messagebox.showerror("Error", "No simulation results available. Please run optimization first.")
        
        
    def create_widgets(self):
        # Main frame
        main_frame = ttk.Frame(self.root, padding="10")
        main_frame.pack(fill=tk.BOTH, expand=True)
        offgrid_label = ttk.Label(main_frame, text="ON-GRID", 
                                 font=("Arial", 24, "bold"), 
                                 foreground="black")
        offgrid_label.pack(side=tk.TOP, anchor=tk.NE, padx=10, pady=5)
        # Sezione di selezione dei file
        file_frame = ttk.LabelFrame(main_frame, text="File Selection", padding="10")
        file_frame.pack(fill=tk.X, padx=5, pady=5)
        
        # Dispositivi in Excel
        ttk.Button(file_frame, text="Select Devices Excel", command=self.select_excel).grid(row=0, column=0, padx=5, pady=5, sticky=tk.W)
        self.excel_label = ttk.Label(file_frame, text="No file selected")
        self.excel_label.grid(row=0, column=1, padx=5, pady=5, sticky=tk.W)
        
        # Dati meteo
        ttk.Button(file_frame, text="Select Weather Data", command=self.select_weather).grid(row=1, column=0, padx=5, pady=5, sticky=tk.W)
        self.weather_label = ttk.Label(file_frame, text="No file selected")
        self.weather_label.grid(row=1, column=1, padx=5, pady=5, sticky=tk.W)
        
        # Selezione del foglio meteo
        ttk.Label(file_frame, text="Weather Sheet:").grid(row=1, column=2, padx=5, pady=5, sticky=tk.E)
        self.meteo_combo = ttk.Combobox(file_frame, textvariable=self.sheet_meteo, state="readonly", width=15)
        self.meteo_combo.grid(row=1, column=3, padx=5, pady=5, sticky=tk.W)
        
        # Carica dati
        ttk.Button(file_frame, text="Select Load Data", command=self.select_load).grid(row=2, column=0, padx=5, pady=5, sticky=tk.W)
        self.load_label = ttk.Label(file_frame, text="No file selected")
        self.load_label.grid(row=2, column=1, padx=5, pady=5, sticky=tk.W)
        
        # Carica il foglio selezionato
        ttk.Label(file_frame, text="Load Sheet:").grid(row=2, column=2, padx=5, pady=5, sticky=tk.E)
        self.load_combo = ttk.Combobox(file_frame, textvariable=self.sheet_carico, state="readonly", width=15)
        self.load_combo.grid(row=2, column=3, padx=5, pady=5, sticky=tk.W)
        
        # Tariff Data
        ttk.Button(file_frame, text="Select Tariff Data", command=self.select_tariff).grid(row=3, column=0, padx=5, pady=5, sticky=tk.W)
        self.tariff_label = ttk.Label(file_frame, text="No file selected")
        self.tariff_label.grid(row=3, column=1, padx=5, pady=5, sticky=tk.W)
        
        # Carica il foglio tariffa selezionato
        ttk.Label(file_frame, text="Tariff Sheet:").grid(row=3, column=2, padx=5, pady=5, sticky=tk.E)
        self.tariff_combo = ttk.Combobox(file_frame, textvariable=self.sheet_tariffa, state="readonly", width=15)
        self.tariff_combo.grid(row=3, column=3, padx=5, pady=5, sticky=tk.W)
        
        # Sezione di configurazione del dispositivo
        device_frame = ttk.LabelFrame(main_frame, text="Device Configuration", padding="10")
        device_frame.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        # Pulsanti per aggiungere dispositivi
        button_frame = ttk.Frame(device_frame)
        button_frame.pack(fill=tk.X, padx=5, pady=5)
        
        ttk.Button(button_frame, text="Add Fuel Generator", command=lambda: self.add_device_frame("fuel")).pack(side=tk.LEFT, padx=5)
        ttk.Button(button_frame, text="Add PV Generator", command=lambda: self.add_device_frame("pv")).pack(side=tk.LEFT, padx=5)
        ttk.Button(button_frame, text="Add Wind Generator", command=lambda: self.add_device_frame("wind")).pack(side=tk.LEFT, padx=5)
        ttk.Button(button_frame, text="Add Battery", command=lambda: self.add_device_frame("battery")).pack(side=tk.LEFT, padx=5)
        opt_frame = ttk.Frame(main_frame)

        
        # Canvas per l'elenco dei dispositivi scorrevoli
        self.canvas = tk.Canvas(device_frame)
        scrollbar = ttk.Scrollbar(device_frame, orient="vertical", command=self.canvas.yview)
        self.scrollable_frame = ttk.Frame(self.canvas)
        
        self.scrollable_frame.bind(
            "<Configure>",
            lambda e: self.canvas.configure(scrollregion=self.canvas.bbox("all"))
        )
        
        self.canvas.create_window((0, 0), window=self.scrollable_frame, anchor="nw")
        self.canvas.configure(yscrollcommand=scrollbar.set)
        
        self.canvas.pack(side="left", fill="both", expand=True, padx=5, pady=5)
        scrollbar.pack(side="right", fill="y", padx=5, pady=5)
        
        # Pulsanti di ottimizzazione
        opt_frame = ttk.Frame(main_frame)
        opt_frame.pack(fill=tk.X, padx=5, pady=10)
        ttk.Button(opt_frame, text="Run Optimization", command=self.run_optimization).pack(side=tk.RIGHT, padx=5)
        ttk.Button(opt_frame, text="Clear All Devices", command=self.clear_devices).pack(side=tk.RIGHT, padx=5)
        ttk.Button(opt_frame, text="View Statistics", command=self.show_statistics).pack(side=tk.RIGHT, padx=5)
        ttk.Button(opt_frame, text="View Plots", command=self.show_plots_page).pack(side=tk.RIGHT, padx=5)
        ttk.Button(opt_frame, text="Open Output Folder", command=self.open_output_folder).pack(side=tk.RIGHT, padx=5)
        
    def open_output_folder(self):
        """Apre la cartella di output con l'esploratore di file del sistema."""
        output_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "output")
        if not os.path.exists(output_dir):
            os.makedirs(output_dir)
            
        try:
            if platform.system() == 'Darwin':  # macOS
                subprocess.call(('open', output_dir))
            elif platform.system() == 'Windows':  # Windows
                os.startfile(output_dir)
            else:  # Linux
                subprocess.call(('xdg-open', output_dir))
        except Exception as e:
            messagebox.showerror("Error", f"Failed to open output folder: {e}")
        
    def select_excel(self):
        self.excel_filename = filedialog.askopenfilename(
            title="Select Devices Excel File",
            filetypes=(("Excel files", "*.xlsx"), ("All files", "*.*"))
        )
        if self.excel_filename:
            self.excel_label.config(text=os.path.basename(self.excel_filename))
            # Controlla i nomi dei fogli
            try:
                xl = pd.ExcelFile(self.excel_filename)
                self.device_sheets = xl.sheet_names
            except Exception as e:
                messagebox.showerror("Error", f"Could not read Excel file: {e}")
    
    def select_weather(self):
        self.weather_filename = filedialog.askopenfilename(
            title="Select Weather Data File",
            filetypes=(("Excel files", "*.xlsx"), ("All files", "*.*"))
        )
        if self.weather_filename:
            self.weather_label.config(text=os.path.basename(self.weather_filename))
            # Caricare le schede meteo disponibili
            try:
                xl = pd.ExcelFile(self.weather_filename)
                self.meteo_sheets = [sheet for sheet in xl.sheet_names if sheet.startswith("Meteo")]
                self.meteo_combo['values'] = self.meteo_sheets
                if self.meteo_sheets:
                    self.sheet_meteo.set(self.meteo_sheets[0])
            except Exception as e:
                messagebox.showerror("Error", f"Could not read weather file: {e}")
    
    def select_load(self):
        self.load_filename = filedialog.askopenfilename(
            title="Select Load Data File",
            filetypes=(("Excel files", "*.xlsx"), ("All files", "*.*"))
        )
        if self.load_filename:
            self.load_label.config(text=os.path.basename(self.load_filename))
            # Caricare i fogli di carico disponibili
            try:
                xl = pd.ExcelFile(self.load_filename)
                self.load_sheets = [sheet for sheet in xl.sheet_names if sheet.startswith("carico")]
                self.load_combo['values'] = self.load_sheets
                if self.load_sheets:
                    self.sheet_carico.set(self.load_sheets[0])
            except Exception as e:
                messagebox.showerror("Error", f"Could not read load file: {e}")
    
    def select_tariff(self):
        self.tariff_filename = filedialog.askopenfilename(
            title="Select Tariff Data File",
            filetypes=(("Excel files", "*.xlsx"), ("All files", "*.*"))
        )
        if self.tariff_filename:
            self.tariff_label.config(text=os.path.basename(self.tariff_filename))
            # Caricare i fogli di tariffa disponibili
            try:
                xl = pd.ExcelFile(self.tariff_filename)
                self.tariff_sheets = xl.sheet_names
                self.tariff_combo['values'] = self.tariff_sheets
                
                # Imposta "Tariffa" come predefinito se esiste, altrimenti usa il primo foglio
                if "Tariffa" in self.tariff_sheets:
                    self.sheet_tariffa.set("Tariffa")
                elif self.tariff_sheets:
                    self.sheet_tariffa.set(self.tariff_sheets[0])
            except Exception as e:
                messagebox.showerror("Error", f"Could not read tariff file: {e}")
    
    def add_device_frame(self, device_type):
        if not self.excel_filename:
            messagebox.showerror("Error", "Please select a devices Excel file first.")
            return
            
        if device_type in ["pv", "wind"] and not self.weather_filename:
            messagebox.showerror("Error", "Please select a weather data file first.")
            return
        
        # Crea frame per questo dispositivo
        device_frame = ttk.LabelFrame(self.scrollable_frame, padding="5")
        device_frame.pack(fill=tk.X, padx=5, pady=5)
        
        # Immissione dell'ID del dispositivo
        ttk.Label(device_frame, text="Device ID:").grid(row=0, column=0, padx=5, pady=5, sticky=tk.W)
        id_var = tk.StringVar()
        if device_type == "fuel":
            id_var.set(f"fuel_gen_{len([d for d in self.devices if d['type'] == 'fuel'])}")
        elif device_type == "pv":
            id_var.set(f"pv_gen_{len([d for d in self.devices if d['type'] == 'pv'])}")
        elif device_type == "wind":
            id_var.set(f"wind_gen_{len([d for d in self.devices if d['type'] == 'wind'])}")
        elif device_type == "battery":
            id_var.set(f"battery_{len([d for d in self.devices if d['type'] == 'battery'])}")
            
        ttk.Entry(device_frame, textvariable=id_var, width=20).grid(row=0, column=1, padx=5, pady=5, sticky=tk.W)
        
        # Selezione del foglio
        ttk.Label(device_frame, text="Excel Sheet:").grid(row=0, column=2, padx=5, pady=5, sticky=tk.W)
        sheet_var = tk.StringVar()
        sheet_combo = ttk.Combobox(device_frame, textvariable=sheet_var, values=self.device_sheets, width=25)
        sheet_combo.grid(row=0, column=3, padx=5, pady=5, sticky=tk.W)
        
        # Imposta il foglio predefinito in base al tipo di dispositivo
        if device_type == "fuel" and "gen_comb" in self.device_sheets:
            sheet_var.set("gen_comb")
        elif device_type == "pv" and "gen_foto" in self.device_sheets:
            sheet_var.set("gen_foto")
        elif device_type == "wind" and "gen_eoli" in self.device_sheets:
            sheet_var.set("gen_eoli")
        elif device_type == "battery" and "accumulatore" in self.device_sheets:
            sheet_var.set("accumulatore")
        
        # Etichetta del tipo di dispositivo
        device_type_label = ttk.Label(device_frame, text=f"Type: {device_type.upper()}")
        device_type_label.grid(row=0, column=4, padx=5, pady=5, sticky=tk.W)
        
        # Prepara info per il pulsante DETTAGLI
        device_info = {"type": device_type, "sheet": sheet_var}
        
        # Pulsante DETTAGLI
        details_btn = ttk.Button(device_frame, text="DETAILS", 
                               command=lambda: self.show_device_details(device_type, device_info))
        details_btn.grid(row=0, column=5, padx=5, pady=5, sticky=tk.W)
        
        # Pulsante Rimuovi
        remove_btn = ttk.Button(device_frame, text="Remove", 
                              command=lambda f=device_frame, d={"type": device_type, "id": id_var, "sheet": sheet_var}: 
                                     self.remove_device(f, d))
        remove_btn.grid(row=0, column=6, padx=5, pady=5, sticky=tk.E)
        
        # Conserva questo dispositivo (con parametri aggiuntivi per batteria)
        if device_type == "battery":
            min_soc = tk.StringVar(value="20")
            init_soc = tk.StringVar(value="50")
            soc_target = tk.StringVar(value="50")
            
            # Store this device with parameters
            device_info = {
                "type": device_type, 
                "id": id_var, 
                "sheet": sheet_var, 
                "frame": device_frame,
                "min_soc": min_soc,
                "init_soc": init_soc,
                "soc_target": soc_target
            }
        else:
            device_info = {"type": device_type, "id": id_var, "sheet": sheet_var, "frame": device_frame}
        
        self.devices.append(device_info)
        self.device_frames.append(device_frame)
    
    def show_device_details(self, device_type, device_info):
        """Mostra una finestra di dialogo con i dettagli del dispositivo letti dal file Excel."""
        # Verifica che il file Excel sia selezionato
        if not self.excel_filename:
            messagebox.showerror("Error", "Please select Excel file first.")
            return
            
        # Ottieni il foglio selezionato nella lista a discesa
        sheet_name = device_info.get("sheet", tk.StringVar()).get()
        if not sheet_name:
            if device_type == "fuel":
                sheet_name = "gen_comb"
            elif device_type == "pv":
                sheet_name = "gen_foto"
            elif device_type == "wind":
                sheet_name = "gen_eoli"
            elif device_type == "battery":
                sheet_name = "accumulatore"
        
        # Carica i dati dal file Excel
        try:
            if device_type == "fuel":
                from carica_gen_comb import carica_gen_comb
                params = carica_gen_comb(self.excel_filename, sheet_name)
            elif device_type == "pv":
                from carica_gen_foto import carica_gen_foto
                params = carica_gen_foto(self.excel_filename, sheet_name)
            elif device_type == "wind":
                from carica_gen_eoli import carica_gen_eoli
                params = carica_gen_eoli(self.excel_filename, sheet_name)
            elif device_type == "battery":
                from carica_accumulatore import carica_accumulatore
                params = carica_accumulatore(self.excel_filename, sheet_name)
            else:
                messagebox.showerror("Error", f"Unknown device type: {device_type}")
                return
        except Exception as e:
            messagebox.showerror("Error", f"Failed to load parameters: {e}")
            return
            
        # Crea finestra di dialogo per mostrare i dettagli
        details_window = tk.Toplevel(self.root)
        details_window.title(f"Dettagli {device_type.upper()} - {sheet_name}")
        details_window.geometry("600x400")
        
        # Frame principale
        main_frame = ttk.Frame(details_window, padding="10")
        main_frame.pack(fill=tk.BOTH, expand=True)
        
        # Frame per i dettagli
        details_frame = ttk.LabelFrame(main_frame, text=f"Parametri da {sheet_name}", padding="10")
        details_frame.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        # Canvas per lo scrolling
        canvas = tk.Canvas(details_frame, highlightthickness=0)
        scrollbar = ttk.Scrollbar(details_frame, orient="vertical", command=canvas.yview)
        scroll_frame = ttk.Frame(canvas)
        
        scroll_frame.bind(
            "<Configure>",
            lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
        )
        
        canvas.create_window((0, 0), window=scroll_frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)
        
        canvas.pack(side="left", fill="both", expand=True, padx=5, pady=5)
        scrollbar.pack(side="right", fill="y", padx=0, pady=5)
        
        # Titolo
        row = 0
        ttk.Label(scroll_frame, text=f"{device_type.upper()} PARAMETERS", 
                 font=("Arial", 12, "bold")).grid(row=row, column=0, columnspan=2, 
                                                 padx=5, pady=10, sticky=tk.W)
        row += 1
        
        # Mostrare tutti i parametri
        for key, value in params.items():
            # Formattare il valore in modo leggibile
            if isinstance(value, (int, float)):
                if abs(value) > 0.01 or value == 0:
                    formatted_value = f"{value:.2f}"
                else:
                    formatted_value = f"{value:.6f}"
            else:
                # Gestire in modo sicuro i tipi CasADi MX e gli array
                try:
                    if hasattr(value, 'shape') and hasattr(value, '__len__'):
                        # Solo oggetti che supportano len()
                        if len(value) > 6:
                            formatted_value = f"Array[{len(value)}]: {value[:3]}... {value[-3:]}"
                        else:
                            formatted_value = str(value)
                    else:
                        formatted_value = str(value)
                except TypeError:
                    # Fallback per oggetti MX di CasADi che non supportano len()
                    formatted_value = "CasADi Symbolic Expression"
                
            ttk.Label(scroll_frame, text=key + ":", font=("Arial", 10, "bold")).grid(
                row=row, column=0, padx=5, pady=3, sticky=tk.W)
            ttk.Label(scroll_frame, text=formatted_value).grid(
                row=row, column=1, padx=5, pady=3, sticky=tk.W)
            row += 1
        
        # Pulsante OK
        ttk.Button(main_frame, text="OK", command=details_window.destroy).pack(side=tk.RIGHT, padx=5, pady=10)
        
    def remove_device(self, frame, device):
        if frame in self.device_frames:
            frame.destroy()
            self.device_frames.remove(frame)
            self.devices = [d for d in self.devices if d['frame'] != frame]
    
    def clear_devices(self):
        for frame in self.device_frames:
            frame.destroy()
        self.device_frames = []
        self.devices = []
    
    def show_statistics(self):
        """Mostra le statistiche usando l'oggetto MicrogridStatistics."""
        if self.statistics and self.optimizer and self.optimizer.results:
            self.statistics.show_statistics()
        else:
            messagebox.showerror("Error", "No simulation results available. Please run optimization first.")
    
    def open_html_report(self):
        """Apre il report HTML nel browser predefinito."""
        if not self.optimizer:
            messagebox.showerror("Error", "No optimizer available.")
            return
            
        html_path = os.path.join(self.optimizer.output_dir, "optimization_report.html")
        if os.path.exists(html_path):
            webbrowser.open('file://' + os.path.realpath(html_path))
        else:
            messagebox.showerror("Error", "HTML report not found. Please run optimization first.")
    
    def export_statistics(self, stats_text):
        """Esporta le statistiche in un file di testo."""
        output_file = filedialog.asksaveasfilename(
            title="Save Statistics",
            defaultextension=".txt",
            filetypes=(("Text files", "*.txt"), ("All files", "*.*"))
        )
        
        if output_file:
            try:
                with open(output_file, 'w', encoding='utf-8') as f:
                    f.write(stats_text)
                messagebox.showinfo("Success", f"Statistics saved to {output_file}")
            except Exception as e:
                messagebox.showerror("Error", f"Failed to save statistics: {e}")
    
    def run_optimization(self):
        if not self.excel_filename or not self.load_filename or not self.tariff_filename:
            messagebox.showerror("Error", "Please select all required files.")
            return
            
        if not self.devices:
            messagebox.showerror("Error", "Please add at least one device.")
            return
            
        # Crea ottimizzatore
        try:
            # Ottieni i fogli selezionati per carico, meteo e tariffa
            load_sheet = self.sheet_carico.get()
            meteo_sheet = self.sheet_meteo.get()
            tariff_sheet = self.sheet_tariffa.get()
            
            # Debug prints per verificare fogli selezionati
            print(f"Load sheet: {load_sheet}")
            print(f"Meteo sheet: {meteo_sheet}")
            print(f"Tariff sheet: {tariff_sheet}")
            
            self.optimizer = MicrogridOnGridOptimizer()
            
            # Inizializza i visualizzatori
            self.plot_viewer = MicrogridPlotViewer(self.root, self.optimizer)
            self.statistics = MicrogridStatistics(self.root, self.optimizer)
            
            # Add devices
            for device in self.devices:
                device_id = device["id"].get()
                sheet_name = device["sheet"].get()
                
                if device["type"] == "fuel":
                    self.optimizer.add_device(FuelGenerator(device_id, self.excel_filename, sheet_name))
                elif device["type"] == "pv":
                    self.optimizer.add_device(PVGenerator(device_id, self.excel_filename, sheet_name, self.weather_filename, meteo_sheet))
                elif device["type"] == "wind":
                    self.optimizer.add_device(WindGenerator(device_id, self.excel_filename, sheet_name, self.weather_filename, meteo_sheet))
                elif device["type"] == "battery":
                    self.optimizer.add_device(Battery(device_id, self.excel_filename, sheet_name))
            
            # Aggiungi carico con foglio selezionato
            load = Load("load1", self.load_filename, load_sheet)
            self.optimizer.add_load(load)
            
            # Aggiungi la connessione alla rete con tariffa
            grid = GridConnection("grid1", self.tariff_filename, tariff_sheet)
            self.optimizer.add_grid_connection(grid)
            
            # Run the optimization
            messagebox.showinfo("Info", "Starting optimization. This may take a while...")
            success = self.optimizer.setup_and_solve()
            
            if success:
                messagebox.showinfo("Success", "Optimization completed successfully!")
                
                # Mostra automaticamente la finestra delle statistiche
                self.statistics.show_statistics()
                
                # Mostra la pagina con i grafici
                self.plot_viewer.show_plots_page()
                
                # Informa l'utente sui file esportati
                messagebox.showinfo("Files Exported", 
                                  "Setpoints have been saved to SETPOINT_DEVICES.xlsx in the output folder.")
            else:
                messagebox.showerror("Error", "Optimization failed. Check console for details.")
                
        except Exception as e:
            messagebox.showerror("Error", f"An error occurred: {e}")
            import traceback
            traceback.print_exc()

# Run the application
if __name__ == "__main__":
    root = tk.Tk()
    app = MicrogridOnGridConfigApp(root)
    root.mainloop()