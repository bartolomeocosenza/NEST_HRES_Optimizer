import pandas as pd
import numpy as np
from update_accumulatore_ca_x import update_accumulatore_ca_x
from CONFIGURA import *  

def carica_accumulatore(excel_filename, sheetname_accumulatore):
    
    # Leggi i dati dal file Excel usando il foglio passato come parametro
    dati_accumulatore = pd.read_excel(
        excel_filename,
        sheet_name=sheetname_accumulatore,
        usecols='B',
        skiprows=4,
        nrows=11,
        header=None
    ).values.flatten()
    
    # Inizializza il dizionario accumulatore
    accumulatore = {}
    accumulatore['sheetname'] = sheetname_accumulatore
    accumulatore['PN'] = dati_accumulatore[0]   # potenza nominale batteria [kWe]
    accumulatore['EB'] = dati_accumulatore[1]     # capacità batteria (Energia massima accumulabile) [kWh]
    accumulatore['eta_C'] = dati_accumulatore[2]  # rendimento batteria in fase di carica [%]
    accumulatore['eta_S'] = dati_accumulatore[3]  # rendimento batteria in fase di scarica [%]
    SOC_min = dati_accumulatore[4]                # valore minimo SOC della batteria  [%]
    SOC_max = dati_accumulatore[5]                # valore massimo SOC della batteria [%]
    accumulatore['SOC_0'] = dati_accumulatore[6]    # valore iniziale SOC della batteria [%]
    accumulatore['AS'] = dati_accumulatore[7]       # autoscarica giornaliera della batteria [%]
    accumulatore['beta_min0'] = dati_accumulatore[8]# valore minimo di beta sotto il quale non vi è scambio di energia
    accumulatore['beta_min'] = dati_accumulatore[9] # reale valore minimo di beta sotto il quale non vi è scambio di energia
    accumulatore['rho'] =  2                      # valore di restrizione del vincolo
    accumulatore['SOC_min'] = SOC_min + accumulatore['rho']
    accumulatore['SOC_max'] = SOC_max - accumulatore['rho']
    accumulatore['SOC_Target'] =  dati_accumulatore[10]  # Stato di carica della batteria a fine giornata
    accumulatore['A'] = np.zeros(N)
    accumulatore['Psi'] = np.zeros(2 * N)
    
    # Setpoint che mantiene il SOC costante
    psi2 = -accumulatore['AS'] / N * 100
    psi3 = (tau / 60) * (accumulatore['PN'] / accumulatore['EB']) * 100
    
    # Legge il vettore SOC_0 dalla colonna M del foglio selezionato
    SOC_0 = pd.read_excel(
        excel_filename,
        sheet_name=sheetname_accumulatore,
        usecols='M',
        skiprows=4,
        nrows=800,
        header=None
    ).values.flatten()
    
    beta = np.zeros(N)
    num = (SOC_0[0] - accumulatore['SOC_0'] - psi2)
    beta[0] = num / psi3 if num >= 0 else num / (psi3 * accumulatore['eta_C'])
    
    for i in range(1, N):
        num = (SOC_0[i] - SOC_0[i - 1] - psi2)
        beta[i] = num / (psi3 * accumulatore['eta_C']) if num >= 0 else num / psi3
    
    beta = np.minimum(beta, 1)
    beta = np.maximum(beta, -1)
    accumulatore['beta'] = beta
    
    # Aggiorna accumulatore
    accumulatore = update_accumulatore_ca_x(accumulatore, accumulatore['beta'])

    # Definizione del numero di variabili di ottimizzazione
    accumulatore['n_x'] = N
    
    return accumulatore
