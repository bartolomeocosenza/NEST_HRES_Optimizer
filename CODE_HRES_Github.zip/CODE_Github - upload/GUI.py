"""
HRES System Selector - Selezione tra ON-GRID e OFF-GRID
"""

import tkinter as tk
from tkinter import ttk, messagebox
from PIL import Image, ImageTk
import subprocess
import sys
import os

class MicrogridSelector:
    def __init__(self, root):
        self.root = root
        self.root.title("HRES OPTIMIZATION - Selector")
        self.root.geometry("800x600")
        self.root.configure(bg='white')
        
        # Titolo principale
        title_label = tk.Label(root, text="HRES OPTIMIZATION", 
                              font=("Arial", 20, "bold"), bg='white', fg='#2c3e50')
        title_label.pack(pady=20)
        
        subtitle_label = tk.Label(root, text="Select your system configuration", 
                                 font=("Arial", 12), bg='white', fg='#7f8c8d')
        subtitle_label.pack(pady=5)
        
        # Frame principale per le immagini
        main_frame = tk.Frame(root, bg='white')
        main_frame.pack(expand=True, fill=tk.BOTH, padx=40, pady=20)
        
        # Frame per OFF-GRID
        off_grid_frame = tk.Frame(main_frame, bg='white', relief=tk.RAISED, bd=2)
        off_grid_frame.pack(side=tk.LEFT, expand=True, fill=tk.BOTH, padx=10)
        
        # Frame per ON-GRID  
        on_grid_frame = tk.Frame(main_frame, bg='white', relief=tk.RAISED, bd=2)
        on_grid_frame.pack(side=tk.RIGHT, expand=True, fill=tk.BOTH, padx=10)
        
        # Carica e mostra le immagini
        self.load_images(off_grid_frame, on_grid_frame)
        
        # Frame per i pulsanti
        button_frame = tk.Frame(root, bg='white')
        button_frame.pack(pady=20)
        
        # Pulsanti
        off_grid_btn = tk.Button(button_frame, text="OFF-GRID", 
                                font=("Arial", 16, "bold"), 
                                bg='#e74c3c', fg='white', 
                                width=12, height=2,
                                command=self.launch_off_grid)
        off_grid_btn.pack(side=tk.LEFT, padx=20)
        
        on_grid_btn = tk.Button(button_frame, text="ON-GRID", 
                               font=("Arial", 16, "bold"), 
                               bg='#27ae60', fg='white', 
                               width=12, height=2,
                               command=self.launch_on_grid)
        on_grid_btn.pack(side=tk.RIGHT, padx=20)
        
    def load_images(self, off_grid_frame, on_grid_frame):
        """Carica e mostra le immagini"""
        try:
            # Immagine OFF-GRID 
            off_grid_img = Image.open("OFF-GRID.png")  
            off_grid_img = off_grid_img.resize((300, 200), Image.Resampling.LANCZOS)
            self.off_grid_photo = ImageTk.PhotoImage(off_grid_img)
            
            off_grid_label = tk.Label(off_grid_frame, image=self.off_grid_photo, bg='white')
            off_grid_label.pack(pady=10)
            
            off_grid_text = tk.Label(off_grid_frame, text="OFF-GRID SYSTEM\nStandalone microgrid", 
                                    font=("Arial", 12), bg='white', fg='#2c3e50', justify=tk.CENTER)
            off_grid_text.pack(pady=10)
            
        except Exception as e:
            # Fallback se immagine non trovata
            off_grid_placeholder = tk.Label(off_grid_frame, text="OFF-GRID\nImage", 
                                          font=("Arial", 14), bg='#ecf0f1', fg='#7f8c8d',
                                          width=30, height=10)
            off_grid_placeholder.pack(pady=10)
            
        try:
            # Immagine ON-GRID 
            on_grid_img = Image.open("ON-GRID.png")  
            on_grid_img = on_grid_img.resize((300, 200), Image.Resampling.LANCZOS)
            self.on_grid_photo = ImageTk.PhotoImage(on_grid_img)
            
            on_grid_label = tk.Label(on_grid_frame, image=self.on_grid_photo, bg='white')
            on_grid_label.pack(pady=10)
            
            on_grid_text = tk.Label(on_grid_frame, text="ON-GRID SYSTEM\nGrid-connected microgrid", 
                                   font=("Arial", 12), bg='white', fg='#2c3e50', justify=tk.CENTER)
            on_grid_text.pack(pady=10)
            
        except Exception as e:
            # Fallback se immagine non trovata
            on_grid_placeholder = tk.Label(on_grid_frame, text="ON-GRID\nImage", 
                                         font=("Arial", 14), bg='#ecf0f1', fg='#7f8c8d',
                                         width=30, height=10)
            on_grid_placeholder.pack(pady=10)
    
    def launch_off_grid(self):
        """Lancia l'interfaccia OFF-GRID"""
        try:
            self.root.destroy()  # Chiude la finestra di selezione
            subprocess.run([sys.executable, "GUI_OFF_GRID.py"])
        except Exception as e:
            messagebox.showerror("Error", f"Failed to launch OFF-GRID interface: {e}")
    
    def launch_on_grid(self):
        """Lancia l'interfaccia ON-GRID"""
        try:
            self.root.destroy()  # Chiude la finestra di selezione
            subprocess.run([sys.executable, "GUI_ON_GRID.py"])
        except Exception as e:
            messagebox.showerror("Error", f"Failed to launch ON-GRID interface: {e}")

if __name__ == "__main__":
    root = tk.Tk()
    app = MicrogridSelector(root)
    root.mainloop()