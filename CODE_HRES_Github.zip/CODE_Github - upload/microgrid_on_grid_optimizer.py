import numpy as np
import matplotlib.cm as cm 
import matplotlib.pyplot as plt
import casadi as ca
import pandas as pd
from typing import List, Dict, Any, Optional, Tuple
from CONFIGURA import *
import time
import os
import webbrowser
import subprocess
import platform
from matplotlib.backends.backend_pdf import PdfPages
import base64
from io import BytesIO

from device_base import Device
from fuel_generator import FuelGenerator
from pv_generator import PVGenerator
from wind_generator import WindGenerator
from battery import Battery
from update_gen_comb_ca import calcola_Psi_vettoriale
from load import Load
from grid_connection import GridConnection
from CONFIGURA import P_fuel, P_acc, P_grid, P_slack_load, P_slack_soc

class MicrogridOnGridOptimizer:
    """Class for optimizing on-grid microgrid operation with multiple devices."""
    
    def __init__(self):
        self.devices = []
        self.loads = []
        self.grid_connection = None
        self.variables = {}
        self.results = {}
        
        # Assegna i pesi importati
        self.P_fuel = P_fuel            # Peso costo combustibile
        self.P_acc = P_acc              # Peso penalizzazione variazioni batteria
        self.P_grid = P_grid            # Peso per lo scambio con la rete
        self.P_slack_load = P_slack_load # Peso slack per il carico
        self.P_slack_soc = P_slack_soc   # Peso slack per SOC
        
        # Valore di tolleranza per bilancio energetico
        self.eps_balance = 1e-6
        
        # Directory per salvataggio output
        self.output_dir = "output"
        if not os.path.exists(self.output_dir):
            os.makedirs(self.output_dir)
        
    def add_device(self, device: Device) -> None:
        """Add a device to the microgrid."""
        self.devices.append(device)
        
    def add_load(self, load: Load) -> None:
        """Add a load to the microgrid."""
        self.loads.append(load)
        
    def add_grid_connection(self, grid: GridConnection) -> None:
        """Add grid connection to the microgrid."""
        self.grid_connection = grid
    
    def open_file(self, filepath):
        """Apre un file con l'applicazione predefinita del sistema operativo."""
        try:
            if platform.system() == 'Darwin':  # macOS
                subprocess.call(('open', filepath))
            elif platform.system() == 'Windows':  # Windows
                os.startfile(filepath)
            else:  # Linux
                subprocess.call(('xdg-open', filepath))
        except Exception as e:
            print(f"Couldn't open file {filepath}: {e}")
    
    def setup_and_solve(self) -> bool:
        """Set up and solve the optimization problem."""
        # Crea ottimizzatore CasADi 
        opti = ca.Opti()
        
        # Crea le variabili di slack for load and SOC
        slack_load_up = opti.variable(N)
        slack_load_down = opti.variable(N)
        slack_SOC = opti.variable()
        
        # ========================================================= #
        # P_grid non è una variabile ma un'espressione simbolica    #
        # ========================================================= #
        
        # Aggiungi le variabili slack al nostro dizionario delle variabili
        self.variables["slack_load_up"] = slack_load_up
        self.variables["slack_load_down"] = slack_load_down
        self.variables["slack_SOC"] = slack_SOC
        # P_grid non è una variabile 
        
        self.variables["P_grid"] = None  # Placeholder - verrà calcolato dopo la risoluzione
        
        # Vincoli sulle variabili di slack 
        opti.subject_to(slack_load_up >= 0)
        opti.subject_to(slack_load_down >= 0)
        opti.subject_to(slack_SOC >= 0)
        
        # Crea variabili di controllo per ciascun dispositivo 
        for device in self.devices:
            device_vars = device.create_control_variables(opti)
            for var_name, var in device_vars.items():
                self.variables[f"{device.device_id}_{var_name}"] = var
        # Passa grid connection alle variables per accesso da Battery
        # quindi aggiunge la connessione alla rete elettrica (grid_connection) 
        # al dizionario delle variabili
        self.variables["grid_connection"] = self.grid_connection

        # ================ Funzione obiettivo ================
        # Calcolo potenza scambiata con la rete
        energy_cost = 0
        
        # Carico totale per ogni timestep
        total_load = np.zeros(N)
        for load in self.loads:
            total_load += load.params['C']
        
        # Bilancio energetico e costo
        for i in range(N):
            # Bilancio di potenza per ogni timestep
            total_generation = 0
            for device in self.devices:
                total_generation += device.calculate_power_output_casadi(self.variables, i)
            
            # ====================================================================
            # In questa versione grid_power è una espressione simbolica, non una variabile
            # Non c'è più il vincolo opti.subject_to(P_grid[i] == grid_power)
            # ====================================================================
            grid_power = total_generation - total_load[i] + slack_load_up[i] - slack_load_down[i]
            
            # Costo/ricavo energia scambiata con la rete - usa direttamente grid_power
            prezzo_vendita = self.grid_connection.params['prezzo_vendita'][i]
            prezzo_acquisto = self.grid_connection.params['prezzo_acquisto'][i]
            
            energy_cost += ca.if_else(grid_power > 0, 
                                    -grid_power * prezzo_vendita, 
                                    -grid_power * prezzo_acquisto) * hours_per_interval / 100
        
        # Usa i metodi delle classi
        total_device_cost = 0
        
        for device in self.devices:
            device_contribution = device.add_to_objective(opti, self.variables)
            total_device_cost += device_contribution
        
        # Funzione obiettivo con tutti i termini
        slack_objective = self.P_slack_load * ca.sum1(slack_load_up + slack_load_down) + self.P_slack_soc * slack_SOC
        F_obj = total_device_cost + self.P_grid * energy_cost + slack_objective
        
        opti.minimize(F_obj)
        
        # ============ VINCOLI DI FATTIBILITÀ =============
        # Usa i metodi delle classi
        
        # 1. Aggiungi vincoli per ogni dispositivo e ogni timestep
        for i in range(N):
            for device in self.devices:
                # Ogni dispositivo gestisce i propri vincoli tramite il suo metodo
                device.add_constraints(opti, self.variables, i)
        
        # 2. Vincoli finali (es. SOC target)
        for device in self.devices:
            if isinstance(device, Battery):
                device.add_final_constraints(opti, self.variables, slack_SOC)
        
        # 3. VINCOLI GLOBALI GIÀ GESTITI IN add_to_objective()
        # I vincoli sui generatori a combustibile (Psi <= 0) sono già aggiunti
        # dal metodo add_to_objective() di FuelGenerator
        
        # ============ INIZIALIZZAZIONE INTELLIGENTE =============
        if self.grid_connection:
            prezzo_medio = np.mean(self.grid_connection.params['prezzo_acquisto'])
            
            # Stima costo produzione per fuel generators
            fuel_gens = [d for d in self.devices if isinstance(d, FuelGenerator)]
            costo_produzione = None
            if fuel_gens:
                fuel_gen = fuel_gens[0]
                eta_max = max(fuel_gen.params['eta_values'][1]) / 100.0
                consumo_specifico_teorico = 3.6 / (eta_max * fuel_gen.params['PCI'])
                costo_produzione = consumo_specifico_teorico * fuel_gen.params['cF'] * 100
                print(f"Initialization: production cost = {costo_produzione:.2f} c€/kWh")
            
            for i in range(N):
                # Fotovoltaico sempre al massimo quando disponibile
                for device in [d for d in self.devices if isinstance(d, PVGenerator)]:
                    alpha_var = self.variables[f"{device.device_id}_alpha"]
                    opti.set_initial(alpha_var[i], 1.0)
                
                # Eolico sempre al massimo quando disponibile
                for device in [d for d in self.devices if isinstance(d, WindGenerator)]:
                    alpha_var = self.variables[f"{device.device_id}_alpha"]
                    opti.set_initial(alpha_var[i], 1.0)
                
                #  Generatore a combustibile attivo quando prezzo VENDITA > costo produzione
                if costo_produzione:
                    for device in fuel_gens:
                        alpha_var = self.variables[f"{device.device_id}_alpha"]
                        if self.grid_connection.params['prezzo_vendita'][i] > costo_produzione:
                            opti.set_initial(alpha_var[i], 0.8)
                        else:
                            opti.set_initial(alpha_var[i], 0.0)
                
                # Batteria: strategia basata sul prezzo (CORRETTA)
                batteries = [d for d in self.devices if isinstance(d, Battery)]
                for device in batteries:
                    beta_var = self.variables[f"{device.device_id}_beta"]
                    if self.grid_connection.params['prezzo_acquisto'][i] < prezzo_medio:
                        opti.set_initial(beta_var[i], 0.2)   # carica quando prezzo basso (β > 0)
                    else:
                        opti.set_initial(beta_var[i], -0.2)  # scarica quando prezzo alto (β < 0)
        
        # Imposta i valori iniziali per le variabili Slack
        opti.set_initial(slack_load_up, 0)
        opti.set_initial(slack_load_down, 0)
        opti.set_initial(slack_SOC, 0)
        
        # Imposta le opzioni del solver
        opti.solver('ipopt', opts)
        
        # =============== Solve ===============
        print("Optimization in progress...")
        solve_start_time = time.time()
        
        try:
            sol = opti.solve()
            solve_time = time.time() - solve_start_time
            print(f"Optimization completed in {solve_time:.2f} seconds!")
            
            # Estrai i risultati
            self.results["slack_load_up_opt"] = sol.value(slack_load_up)
            self.results["slack_load_down_opt"] = sol.value(slack_load_down)
            self.results["slack_SOC_opt"] = sol.value(slack_SOC)
            
            # Estrai i risultati dei dispositivi PRIMA di ricostruire P_grid
            for device in self.devices:
                device_results = device.extract_results(sol, self.variables)
                self.results.update(device_results)
            
            # =========================================================================#
            # Adesso P_grid_opt post-solve viene ricostruito come espressione numerica #
            # dopo aver estratto i risultati dei dispositivi                           #
            # =========================================================================#
            P_grid_opt = np.zeros(N)
            for i in range(N):
                total_generation = 0
                for device in self.devices:
                    total_generation += device.calculate_power_output(self.results, i)
                P_grid_opt[i] = total_generation - total_load[i] + self.results["slack_load_up_opt"][i] - self.results["slack_load_down_opt"][i]
            
            self.results["P_grid_opt"] = P_grid_opt
            
            # Calcola le statistiche di scambio con la rete
            print("Calculating grid statistics...")
            if self.grid_connection:
                grid_stats = self.grid_connection.get_statistics(P_grid_opt, hours_per_interval)
                self.results.update(grid_stats)
            
            # Salva i setpoint in Excel
            print("Saving setpoints to Excel...")
            self.save_setpoints_to_excel()
            
            return True
        except Exception as e:
            print(f"Optimization failed: {e}")
            import traceback
            traceback.print_exc()
            return False
    
    def save_setpoints_to_excel(self):
        """Salva i setpoint dei dispositivi in un file Excel."""
        # Prepara i dati per il file Excel
        data = {'Time[h]': time_hours}
        
        # Aggiungi i setpoint di ogni dispositivo
        for device in self.devices:
            device_id = device.device_id
            device_type = device.__class__.__name__
            
            if isinstance(device, (PVGenerator, WindGenerator, FuelGenerator)):
                # Generatori con alpha come setpoint
                if f"{device_id}_alpha_opt" in self.results:
                    data[f"{device_id}_alpha"] = self.results[f"{device_id}_alpha_opt"]
            
            if isinstance(device, Battery):
                # Batterie con beta come setpoint
                if f"{device_id}_beta_opt" in self.results:
                    data[f"{device_id}_beta"] = self.results[f"{device_id}_beta_opt"]
            
        # Crea il DataFrame e salva in Excel
        df = pd.DataFrame(data)
        output_file = os.path.join(self.output_dir, "SETPOINT_DEVICES.xlsx")
        df.to_excel(output_file, index=False)
        print(f"Setpoints saved to {output_file}")
    
    def get_statistics_text(self) -> str:
        """Restituisce le statistiche del sistema come testo formattato."""
        if not self.results:
            return "No results to analyze."
            
        stats_text = "=== SYSTEM STATISTICS ===\n\n"
        
        # Calcola statistiche carico
        total_load_energy = 0
        for load in self.loads:
            load_energy = np.sum(load.params['C']) * hours_per_interval
            total_load_energy += load_energy
            stats_text += f"Load ({load.load_id}):\n"
            stats_text += f" - Total energy: {load_energy:.2f} kWh\n\n"
        
        # Raccogli le statistiche da ciascun dispositivo
        for device in self.devices:
            stats = device.get_statistics(self.results)
            device_type = device.__class__.__name__
            
            stats_text += f"{device_type} ({device.device_id}):\n"
            for name, value in stats.items():
                # Converti valori CasADi in tipi Python standard
                if hasattr(value, 'full'):  # Verifica se è un tipo CasADi
                    value = float(value.full().flatten()[0])
                    
                if name.endswith('_total_energy'):
                    stats_text += f" - Total energy: {float(value):.2f} kWh\n"
                elif name.endswith('_fuel_consumption') or name.endswith('_F_comb'):
                    stats_text += f" - Fuel consumption: {float(value):.2f} kg\n"
                elif name.endswith('_liters_of_diesel'):
                    if value is not None:
                        stats_text += f" - Diesel volume: {float(value):.2f} L\n"
                elif name.endswith('_num_starts') or name.endswith('_N_acc'):
                    stats_text += f" - Number of starts: {int(value)}\n"
                elif name.endswith('_total_exchanged'):
                    stats_text += f" - Energy exchanged: {float(value):.2f} kWh\n"
                elif name.endswith('_net_energy'):
                    sign = "discharge" if value > 0 else "charge"
                    stats_text += f" - Net energy ({sign}): {abs(float(value)):.2f} kWh\n"                    
                elif name.endswith('_final_SOC'):
                    stats_text += f" - Final SOC: {float(value):.2f}%\n"
                elif name.endswith('_min_SOC'):
                    stats_text += f" - Min SOC: {float(value):.2f}%\n"
                elif name.endswith('_max_SOC'):
                    stats_text += f" - Max SOC: {float(value):.2f}%\n"
            
            stats_text += "\n"
        
        # Statistiche specifiche della connessione alla rete
        if self.grid_connection and "P_grid_opt" in self.results:
            grid_id = self.grid_connection.grid_id
            P_grid_opt = self.results["P_grid_opt"]
            
            energy_bought = self.results[f"{grid_id}_energy_bought"]
            energy_sold = self.results[f"{grid_id}_energy_sold"]
            cost_bought = self.results[f"{grid_id}_cost_bought"]
            revenue_sold = self.results[f"{grid_id}_revenue_sold"]
            net_energy = self.results[f"{grid_id}_net_energy"]
            net_cost = self.results[f"{grid_id}_net_cost"]
            
            stats_text += f"Grid Connection ({grid_id}):\n"
            stats_text += f" - Energy purchased: {energy_bought:.2f} kWh\n"
            stats_text += f" - Energy sold: {energy_sold:.2f} kWh\n"
            stats_text += f" - Net energy exchange (- = purchase): {net_energy:.2f} kWh\n"
            stats_text += f" - Cost of purchased energy: {cost_bought:.2f} €\n"
            stats_text += f" - Revenue from sold energy: {revenue_sold:.2f} €\n"
            stats_text += f" - Net cost (- = revenue): {net_cost:.2f} €\n\n"
            
            # Analisi economica corretta per i generatori a combustibile
            if any(isinstance(dev, FuelGenerator) for dev in self.devices):
                stats_text += "Economic Analysis:\n"
                
                # Calcola costo medio dell'elettricità acquistata (per riferimento)
                avg_purchase_price = float(cost_bought / energy_bought if energy_bought > 0 else 0)
                stats_text += f" - Average purchase price: {avg_purchase_price:.4f} €/kWh\n"
                
                # Calcola anche il prezzo medio di vendita per confronto
                avg_sale_price = float(revenue_sold / energy_sold if energy_sold > 0 else 0)
                stats_text += f" - Average sale price: {avg_sale_price:.4f} €/kWh\n"
                
                for device in self.devices:
                    if isinstance(device, FuelGenerator):
                        # Verifica tutte le possibili chiavi per il consumo di combustibile
                        possible_fuel_keys = [
                            f"{device.device_id}_F_comb",
                            f"{device.device_id}_fuel_consumption"
                        ]
                        
                        # Verifica tutte le possibili chiavi per l'energia totale
                        possible_energy_keys = [
                            f"{device.device_id}_total_energy",
                            f"{device.device_id}_G_opt"  # Possiamo usare anche G_opt per calcolare l'energia
                        ]
                        
                        # Cerca nelle chiavi disponibili
                        fuel_consumption = None
                        fuel_energy = None
                        
                        for key in possible_fuel_keys:
                            if key in self.results:
                                fuel_consumption = self.results[key]
                                # Converti gli oggetti CasADi a float
                                if hasattr(fuel_consumption, 'full'):
                                    fuel_consumption = float(fuel_consumption.full())
                                break
                        
                        for key in possible_energy_keys:
                            if key in self.results:
                                if key.endswith('_G_opt'):
                                    # Se abbiamo G_opt, calcoliamo l'energia totale
                                    G_opt = self.results[key]
                                    fuel_energy = float(np.sum(G_opt) * hours_per_interval)
                                else:
                                    fuel_energy = self.results[key]
                                    # Converti gli oggetti CasADi a float
                                    if hasattr(fuel_energy, 'full'):
                                        fuel_energy = float(fuel_energy.full())
                                break
                        
                        # Verifica se abbiamo trovato dati validi
                        has_valid_data = fuel_consumption is not None and fuel_energy is not None
                        
                        # Se G_opt è presente e contiene valori positivi, il generatore è stato utilizzato
                        g_opt_key = f"{device.device_id}_G_opt"
                        if g_opt_key in self.results:
                            G_opt = self.results[g_opt_key]
                            generator_used = float(np.sum(G_opt)) > 0
                        else:
                            generator_used = False
                        
                        if generator_used and has_valid_data and float(fuel_energy) > 0:
                            # Converti esplicitamente a float
                            fuel_consumption = float(fuel_consumption)
                            fuel_energy = float(fuel_energy)
                            
                            # Calcola consumo specifico e costo di produzione MEDIO
                            specific_consumption = float(fuel_consumption / fuel_energy)  # kg/kWh
                            production_cost = float(specific_consumption * device.params['cF'])  # €/kWh
                            
                            stats_text += f" - {device.device_id} average specific consumption: {specific_consumption:.4f} kg/kWh\n"
                            stats_text += f" - {device.device_id} average production cost: {production_cost:.4f} €/kWh\n"
                            
                            # Confronta con prezzo VENDITA durante attivazione
                            alpha_opt_key = f"{device.device_id}_alpha_opt"
                            if alpha_opt_key in self.results:
                                alpha_opt = self.results[alpha_opt_key]
                                
                                # Calcola prezzo medio di VENDITA quando generatore è attivo
                                active_sale_prices = []
                                for i in range(len(alpha_opt)):
                                    if alpha_opt[i] > 0.01:  # Generatore attivo
                                        active_sale_prices.append(self.grid_connection.params['prezzo_vendita'][i])
                                
                                if active_sale_prices:
                                    avg_sale_price_active = np.mean(active_sale_prices) / 100  # c€/kWh → €/kWh
                                    cost_diff = float(avg_sale_price_active - production_cost)
                                    
                                    stats_text += f" - Average grid sale price during operation: {avg_sale_price_active:.4f} €/kWh\n"
                                    
                                    if cost_diff > 0:
                                        stats_text += f" - Producing with {device.device_id} earns {cost_diff:.4f} €/kWh vs average production cost\n"
                                        total_profit = float(cost_diff * fuel_energy)
                                        stats_text += f" - Total profit from generation: {total_profit:.2f} €\n"
                                    else:
                                        stats_text += f" - Average production cost exceeds sale price by {-cost_diff:.4f} €/kWh\n"
                                        revenue_loss = float(-cost_diff * fuel_energy)
                                        stats_text += f" - Revenue loss: {revenue_loss:.2f} €\n"
                                else:
                                    stats_text += f" - {device.device_id} was not active during simulation\n"
                            else:
                                # Fallback se non troviamo alpha_opt
                                stats_text += f" - {device.device_id} control data not found\n"
                        elif generator_used:
                            stats_text += f" - {device.device_id} was used but consumption data is incomplete\n"
                        else:
                            stats_text += f" - {device.device_id} was not used in this simulation\n"
        
        
        
        # Calcolo mismatch del bilancio energetico
        if "P_grid_opt" in self.results:
            total_load = np.zeros(N)
            for load in self.loads:
                total_load += load.params['C']
            
            # Calcola potenza totale generata
            total_generation = np.zeros(N)
            for device in self.devices:
                if hasattr(device, 'calculate_power_output') and f"{device.device_id}_alpha_opt" in self.results:
                    for i in range(N):
                        total_generation[i] += device.calculate_power_output(self.results, i)
                elif f"{device.device_id}_P_batt_opt" in self.results:  # Batteria
                    total_generation += self.results[f"{device.device_id}_P_batt_opt"]
            
            P_grid_opt = self.results["P_grid_opt"]
            mismatch = np.max(np.abs(total_generation - total_load - P_grid_opt))
            
            stats_text += f"\nPower Balance:\n"
            stats_text += f" - Max power mismatch: {mismatch:.6f} kW\n"
        
        # Analisi accensioni/spegnimenti generatori a combustibile
        fuel_gens = [d for d in self.devices if isinstance(d, FuelGenerator)]
        if fuel_gens and self.grid_connection:
            for gen in fuel_gens:
                device_id = gen.device_id
                if f"{device_id}_alpha_opt" in self.results:
                    alpha_opt = self.results[f"{device_id}_alpha_opt"]
                    
                    # Crea DataFrame per analisi (come nel non modulare)
                    import pandas as pd
                    df_analisi = pd.DataFrame({
                        'Ora': time_hours,
                        'Prezzo_vendita': self.grid_connection.params['prezzo_vendita'],  # usa prezzo vendita
                        'Generatore_acceso': [a > 0.01 for a in alpha_opt]
                    })
                    
                    # Trova accensioni e spegnimenti
                    cambio_stato = df_analisi['Generatore_acceso'].diff().fillna(df_analisi['Generatore_acceso'].iloc[0])
                    accensioni = df_analisi[cambio_stato & df_analisi['Generatore_acceso']]
                    spegnimenti = df_analisi[cambio_stato & ~df_analisi['Generatore_acceso']]
                    
                    if not accensioni.empty:
                        stats_text += f"\n{device_id} Activation Periods:\n"
                        for i, row in accensioni.iterrows():
                            # Trova il prossimo spegnimento
                            next_off = spegnimenti[spegnimenti.index > i].index.min() if not spegnimenti[spegnimenti.index > i].empty else len(df_analisi)
                            # Usa ultimo intervallo acceso + 0.25h
                            if next_off < len(df_analisi):
                                end_time = df_analisi.iloc[next_off - 1]['Ora'] + hours_per_interval
                            else:
                                end_time = df_analisi.iloc[-1]['Ora'] + hours_per_interval
    
                            stats_text += f" - Activation: {row['Ora']:.2f} → {end_time:.2f} | Sale price: {row['Prezzo_vendita']:.2f} c€/kWh\n"
        
        # =============== TIMELINE ORARIA GENERATORE vs COSTO PRODUZIONE ISTANTANEO ===============
        if self.grid_connection and fuel_gens:
            for gen in fuel_gens:
                device_id = gen.device_id
                
                if f"{device_id}_alpha_opt" in self.results:
                    alpha_opt = self.results[f"{device_id}_alpha_opt"]
                    
                    # Importa la funzione per l'interpolazione
                    from piecewise_linear import piecewise_linear_ca1
                    eta_vals = np.array(gen.params['eta_values'])
                    
                    # Calcola costo di produzione istantaneo per ogni timestep
                    costo_produzione_istante = np.zeros(N)
                    for i in range(N):
                        alpha_i = alpha_opt[i]
                        
                        # Gestisci il caso alpha = 0 per evitare divisioni per zero
                        if alpha_i < 0.001:
                            # Usa il valore minimo di alpha per stimare il costo massimo
                            alpha_calc = max(gen.params['P_min'] / gen.params['PN'], 0.1)
                        else:
                            alpha_calc = alpha_i
                        
                        # Interpolazione dell'efficienza al carico corrente
                        eta_alpha = piecewise_linear_ca1(eta_vals[1], eta_vals[0], alpha_calc) / 100
                        
                        # Consumo specifico [kg/kWh] con formula diretta
                        consumo_specifico = 3.6 / (gen.params['PCI'] * eta_alpha)
                        
                        # Costo produzione [c€/kWh]
                        costo_produzione_istante[i] = consumo_specifico * gen.params['cF'] * 100
                    
                    # === TIMELINE ORARIA GENERATORE vs PREZZI (15-min step) ===
                    stats_text += f"\n=== HOURLY TIMELINE {device_id} vs PRICES ===\n"
                    stats_text += f"{'Time':<8} {'Prod Cost':<12} {'Sale Price':<12} {'Diff':<8} {'Gen':<4} {'Decision'}\n"
                    stats_text += f"{'-'*65}\n"
                
                    for idx in range(0, N):  # Ogni intervallo da 15 min
                        t = time_hours[idx]
                        hh = int(t)
                        mm = int((t - hh) * 60)
                        tag = f"{hh:02d}:{mm:02d}h"
                
                        costo_prod = costo_produzione_istante[idx]
                        prezzo_vend = self.grid_connection.params['prezzo_vendita'][idx]
                        diff = prezzo_vend - costo_prod
                        gen_on = alpha_opt[idx] > 0.01
                        
                        # Valuta se la decisione è economicamente corretta
                        if diff > 0:  # Conveniente produrre
                            decisione_corretta = gen_on
                        else:  # Non conveniente produrre
                            decisione_corretta = not gen_on
                        
                        simbolo = "✓" if decisione_corretta else "✗"
                        stato_gen = "ON" if gen_on else "OFF"
                        
                        stats_text += (
                            f"{tag:<8} "
                            f"{costo_prod:>10.2f}c€ "
                            f"{prezzo_vend:>10.2f}c€ "
                            f"{diff:>+7.2f} "
                            f"{stato_gen:<4} "
                            f"{simbolo}\n"
                        )
                        
                    # Statistiche riassuntive
                    decisioni_corrette = 0
                    decisioni_totali = N
                    for i in range(N):
                        diff = self.grid_connection.params['prezzo_vendita'][i] - costo_produzione_istante[i]
                        gen_on = alpha_opt[i] > 0.01
                        if (diff > 0 and gen_on) or (diff <= 0 and not gen_on):
                            decisioni_corrette += 1
                    
                    precisione = decisioni_corrette / decisioni_totali * 100
                    stats_text += f"\nEconomically correct decisions: {decisioni_corrette}/{decisioni_totali} ({precisione:.1f}%)\n"
        
        return stats_text
    
    def generate_plot_on_figure(self, fig, plot_type):
        """Genera uno specifico tipo di grafico sulla figura fornita."""
        if not self.results:
            ax = fig.add_subplot(1, 1, 1)
            ax.text(0.5, 0.5, "No results available", ha='center', va='center', fontsize=14)
            return
            
        import matplotlib.cm as cm
        import numpy as np
        
        base_colors = {
            'fuel': '#808080',
            'pv': '#FDB813',
            'wind': '#00A0DC',
            'battery_discharge': '#2ECC71',
            'battery_charge': '#E74C3C',
            'grid_purchase': '#9B59B6',
            'grid_sale': '#3498DB'
        }

        # Raggruppa dispositivi per tipo
        fuel_gens = [d for d in self.devices if isinstance(d, FuelGenerator)]
        pv_gens = [d for d in self.devices if isinstance(d, PVGenerator)]
        wind_gens = [d for d in self.devices if isinstance(d, WindGenerator)]
        batteries = [d for d in self.devices if isinstance(d, Battery)]
        
        # Limita il numero di colori al numero di dispositivi
        pv_colors = cm.YlOrBr(np.linspace(0.3, 0.9, max(1, len(pv_gens))))
        wind_colors = cm.Blues(np.linspace(0.3, 0.9, max(1, len(wind_gens))))
        fuel_colors = cm.Greys(np.linspace(0.3, 0.9, max(1, len(fuel_gens))))
        batt_discharge_colors = cm.Greens(np.linspace(0.3, 0.9, max(1, len(batteries))))
        batt_charge_colors = cm.Reds(np.linspace(0.3, 0.9, max(1, len(batteries))))
        
        # Calcola il carico totale
        total_load = np.zeros(N)
        for load in self.loads:
            total_load += load.params['C']
            
        # Ottieni risultati della rete
        P_grid_opt = self.results["P_grid_opt"]
        
        # Genera il tipo di grafico specifico
        if plot_type == "generation_profile":
            # Prepara i dati per il grafico combinato
            generators = []
            gen_names = []
            gen_colors = []
            
            # Aggiungi generatori in ordine: PV, Wind, Fuel (dal più rinnovabile al meno)
            for i, device in enumerate(pv_gens):
                generators.append(self.results[f"{device.device_id}_G_opt"])
                gen_names.append(f"{device.device_id}")
                gen_colors.append(pv_colors[i])
                
            for i, device in enumerate(wind_gens):
                generators.append(self.results[f"{device.device_id}_G_opt"])
                gen_names.append(f"{device.device_id}")
                gen_colors.append(wind_colors[i])
                
            for i, device in enumerate(fuel_gens):
                generators.append(self.results[f"{device.device_id}_G_opt"])
                gen_names.append(f"{device.device_id}")
                gen_colors.append(fuel_colors[i])
                
            # Batterie (solo scarica)
            battery_discharge = []
            discharge_names = []
            discharge_colors = []
            
            for i, device in enumerate(batteries):
                P_batt = self.results[f"{device.device_id}_P_batt_opt"]
                battery_discharge.append(np.maximum(P_batt, 0))  # Solo scarica
                discharge_names.append(f"{device.device_id} (discharge)")
                discharge_colors.append(batt_discharge_colors[i])
                
            # Batterie (solo carica)
            battery_charge = []
            charge_names = []
            charge_colors = []
            
            for i, device in enumerate(batteries):
                P_batt = self.results[f"{device.device_id}_P_batt_opt"]
                battery_charge.append(np.maximum(-P_batt, 0))  # Solo carica (invertita)
                charge_names.append(f"{device.device_id} (charge)")
                charge_colors.append(batt_charge_colors[i])
                
            # Grid Exchange
            grid_purchase = np.maximum(0, -P_grid_opt)  # Acquisto dalla rete (valori positivi)
            grid_sale = np.maximum(0, P_grid_opt)      # Vendita alla rete (valori positivi)
            

            # Primo subplot: Generation Profile
            ax1 = fig.add_subplot(2, 1, 1)
            all_gen_data = generators.copy()
            all_gen_data.extend(battery_discharge)
            all_gen_data.append(grid_purchase)
            
            all_gen_names = gen_names.copy()
            all_gen_names.extend(discharge_names)
            all_gen_names.append('Grid Purchase')
            
            all_gen_colors = gen_colors.copy()
            all_gen_colors.extend(discharge_colors)
            all_gen_colors.append(base_colors['grid_purchase'])
            
            ax1.stackplot(time_hours, *all_gen_data, labels=all_gen_names, colors=all_gen_colors, alpha=0.7)
            ax1.plot(time_hours, total_load, 'k--', label='Load', linewidth=2)
            ax1.set_xlabel('Time [h]')
            ax1.set_ylabel('Power [kW]')
            ax1.set_title('Generation Profile')
            ax1.legend(loc='upper left')
            ax1.grid(True)
            
            # Secondo subplot: Scambio con la rete
            ax2 = fig.add_subplot(2, 1, 2)
            ax2.stackplot(time_hours, 
                        [grid_sale], 
                        [grid_purchase],
                        labels=['Grid Sale', 'Grid Purchase'],
                        colors=[base_colors['grid_sale'], base_colors['grid_purchase']],
                        alpha=0.7)
            ax2.axhline(y=0, color='k', linestyle='-', linewidth=0.5)
            ax2.set_xlabel('Time [h]')
            ax2.set_ylabel('Power [kW]')
            ax2.set_title('Grid Exchange Profile')
            ax2.legend(loc='upper left')
            ax2.grid(True)
            
            # Manteniamo il layout pulito
            fig.tight_layout()
            
        elif plot_type == "control_variables":
            # Grafico dei controlli 
            ax = fig.add_subplot(1, 1, 1)
            
            # Aggiungi variabili di controllo per ogni dispositivo
            for i, device in enumerate(fuel_gens):
                alpha = self.results[f"{device.device_id}_alpha_opt"]
                ax.plot(time_hours, alpha, label=f'Fuel Gen ({device.device_id})', 
                        color=fuel_colors[i], linewidth=1.5)
            
            for i, device in enumerate(pv_gens):
                alpha = self.results[f"{device.device_id}_alpha_opt"]
                ax.plot(time_hours, alpha, label=f'PV ({device.device_id})',
                        color=pv_colors[i], linewidth=1.5)
            
            for i, device in enumerate(wind_gens):
                alpha = self.results[f"{device.device_id}_alpha_opt"]
                ax.plot(time_hours, alpha, label=f'Wind ({device.device_id})',
                        color=wind_colors[i], linewidth=1.5)
            
            for i, device in enumerate(batteries):
                beta = self.results[f"{device.device_id}_beta_opt"]
                ax.plot(time_hours, beta, label=f'Battery ({device.device_id})',
                        color=batt_discharge_colors[i], linewidth=1.5)
            
  
            
            ax.set_xlabel('Time [h]')
            ax.set_ylabel('Control Value')
            ax.set_title('Control Variables')
            ax.legend(loc='upper right')
            ax.grid(True)
            fig.tight_layout()
            
        elif plot_type == "weather_data":
            # Grafico dati meteo
            # Cerca dispositivi fotovoltaici ed eolici nel sistema
            pv_generators = [dev for dev in self.devices if isinstance(dev, PVGenerator)]
            wind_generators = [dev for dev in self.devices if isinstance(dev, WindGenerator)]
        
            # DNI e Temperatura dal primo generatore PV
            if pv_generators:
                pv_gen = pv_generators[0]
                DNI = pv_gen.params['DNI']
                Ta = pv_gen.params['Ta']
        
                # DNI
                ax1 = fig.add_subplot(3, 1, 1)
                ax1.plot(time_hours, DNI, 'orange', linewidth=2, label="DNI (Solar Irradiance)")
                ax1.fill_between(time_hours, DNI, alpha=0.2, color='orange')
                ax1.set_xlabel('Time [h]')
                ax1.set_ylabel('Solar Irradiance [W/m²]')
                ax1.set_title('Solar Irradiance Profile')
                ax1.legend()
                ax1.grid(True)
        
                # Temperatura
                ax3 = fig.add_subplot(3, 1, 3)
                ax3.plot(time_hours, Ta, 'red', linewidth=2, label="Temperature")
                ax3.fill_between(time_hours, Ta, alpha=0.2, color='red')
                ax3.set_xlabel('Time [h]')
                ax3.set_ylabel('Temperature [°C]')
                ax3.set_title('Temperature Profile')
                ax3.legend()
                ax3.grid(True)
        
            else:
                # Se nessun PV, lasciare vuoto
                ax1 = fig.add_subplot(3, 1, 1)
                ax1.text(0.5, 0.5, "No PV Generator in the system.", ha='center')
                ax1.grid(False)
        
                ax3 = fig.add_subplot(3, 1, 3)
                ax3.text(0.5, 0.5, "No PV Generator in the system.", ha='center')
                ax3.grid(False)
        
            # Wind dal primo generatore eolico
            if wind_generators:
                wind_gen = wind_generators[0]
                wind_speed = wind_gen.params['v']
        
                ax2 = fig.add_subplot(3, 1, 2)
                ax2.plot(time_hours, wind_speed, 'blue', linewidth=2, label="Wind Speed")
                ax2.fill_between(time_hours, wind_speed, alpha=0.2, color='blue')
                ax2.set_xlabel('Time [h]')
                ax2.set_ylabel('Wind Speed [m/s]')
                ax2.set_title('Wind Speed Profile')
                ax2.legend()
                ax2.grid(True)
        
            else:
                ax2 = fig.add_subplot(3, 1, 2)
                ax2.text(0.5, 0.5, "No Wind Generator in the system.", ha='center')
                ax2.grid(False)
        
            fig.tight_layout()

        # NUOVI PLOT PER DISPOSITIVI INDIVIDUALI
        elif plot_type.startswith("device_energy_"):
            device_id = plot_type.replace("device_energy_", "")
            device = next((d for d in self.devices if d.device_id == device_id), None)
            
            if device and isinstance(device, (FuelGenerator, PVGenerator, WindGenerator)):
                # 2 subplot per generatori: Energia + Variabile controllo
                ax1 = fig.add_subplot(2, 1, 1)
                ax2 = fig.add_subplot(2, 1, 2)
                
                # Subplot 1: Energia
                G_opt = self.results[f"{device_id}_G_opt"]
                ax1.plot(time_hours, G_opt, linewidth=2, label=f'{device_id} Power Output')
                ax1.fill_between(time_hours, G_opt, alpha=0.3)
                ax1.set_xlabel('Time [h]')
                ax1.set_ylabel('Power [kW]')
                ax1.set_title(f'{device_id} - Energy Profile')
                ax1.legend()
                ax1.grid(True)
                
                # Subplot 2: Variabile controllo
                alpha_opt = self.results[f"{device_id}_alpha_opt"]
                ax2.plot(time_hours, alpha_opt, 'r-', linewidth=2, label=f'{device_id} Control (α)')
                ax2.set_xlabel('Time [h]')
                ax2.set_ylabel('Control Value')
                ax2.set_title(f'{device_id} - Control Variable')
                ax2.legend()
                ax2.grid(True)
                
            fig.tight_layout()

    def generate_battery_plot_on_figure(self, fig, device):
        """Genera il grafico della batteria sulla figura fornita"""
        if not self.results:
            ax = fig.add_subplot(1, 1, 1)
            ax.text(0.5, 0.5, "No results available", ha='center', va='center', fontsize=14)
            return
            
        # Ottieni i dati della batteria
        SOC_opt = self.results[f"{device.device_id}_SOC_opt"]
        P_batt_opt = self.results[f"{device.device_id}_P_batt_opt"]
        beta_opt = self.results[f"{device.device_id}_beta_opt"]
        
        # 1) Potenza batteria (carica/scarica)
        ax1 = fig.add_subplot(3, 1, 1)
        pos_batt = np.maximum(P_batt_opt, 0)  # scarica batteria
        neg_batt = np.minimum(P_batt_opt, 0)  # carica batteria
        
        ax1.stackplot(time_hours, 
                    pos_batt, 
                    neg_batt,
                    labels=['Discharging phase', 'Charging phase'],
                    colors=['#2ECC71', '#E74C3C'],
                    alpha=0.7)
        ax1.axhline(y=0, color='k', linestyle='-', linewidth=0.5)
        ax1.set_xlabel('Time [h]')
        ax1.set_ylabel('Power [kW]')
        ax1.set_title(f'Battery {device.device_id} - Power Profile')
        ax1.legend(loc='upper left')
        ax1.grid(True)
        
        # 2) SOC
        ax2 = fig.add_subplot(3, 1, 2)
        SOC_0 = device.params['SOC_0']
        t_path = np.r_[time_hours[0], time_hours + hours_per_interval]
        soc_path = np.r_[SOC_0, SOC_opt]
        soc_min_path = np.full_like(soc_path, device.params['SOC_min'])
        ax2.plot(t_path, soc_path, 'b-', linewidth=2, label='SOC')
        ax2.fill_between(time_hours, SOC_opt, device.params['SOC_min'], alpha=0.2, color='blue')
        ax2.axhline(y=device.params['SOC_min'], color='r', linestyle='--', label=f"SOC min = {device.params['SOC_min']}%")
        ax2.axhline(y=device.params['SOC_max'], color='g', linestyle='--', label=f"SOC max = {device.params['SOC_max']}%")
        ax2.axhline(y=device.params['SOC_Target'], color='y', linestyle='--', label=f"SOC target = {device.params['SOC_Target']}%")
        ax2.set_xlabel('Time [h]')
        ax2.set_ylabel('SOC [%]')
        ax2.set_title(f'Battery {device.device_id} - State of Charge')
        ax2.legend(loc='best')
        ax2.grid(True)
        
        # 3) NUOVO: Variabile di controllo
        ax3 = fig.add_subplot(3, 1, 3)
        ax3.plot(time_hours, beta_opt, 'purple', linewidth=2, label=f'Control Variable (β)')
        ax3.axhline(y=0, color='k', linestyle='-', linewidth=0.5)
        ax3.set_xlabel('Time [h]')
        ax3.set_ylabel('Control Value')
        ax3.set_title(f'Battery {device.device_id} - Control Variable')
        ax3.legend(loc='best')
        ax3.grid(True)
        
        fig.tight_layout()

    def generate_battery_energy_plot_on_figure(self, fig, device):
        """Genera il grafico dell'energia della batteria sulla figura fornita."""
        if not self.results:
            ax = fig.add_subplot(1, 1, 1)
            ax.text(0.5, 0.5, "No results available", ha='center', va='center', fontsize=14)
            return
            
        # Ottieni i dati della batteria
        P_batt_opt = self.results[f"{device.device_id}_P_batt_opt"]
        
        # Calcola energia di carica e scarica
        charge_energy = np.zeros(N)
        discharge_energy = np.zeros(N)
        
        for i in range(N):
            if P_batt_opt[i] < 0:  # Carica
                charge_energy[i] = -P_batt_opt[i] * hours_per_interval
            else:  # Scarica
                discharge_energy[i] = P_batt_opt[i] * hours_per_interval
        
        # Plot energia cumulativa
        cumulative_charge = np.cumsum(charge_energy)
        cumulative_discharge = np.cumsum(discharge_energy)
        
        ax = fig.add_subplot(1, 1, 1)
        ax.plot(time_hours, cumulative_charge, 'r-', linewidth=2, label='Charging Energy')
        ax.plot(time_hours, cumulative_discharge, 'g-', linewidth=2, label='Discharging Energy')
        ax.set_xlabel('Time [h]')
        ax.set_ylabel('Energy [kWh]')
        ax.set_title(f'Battery {device.device_id} - Cumulative Energy')
        ax.legend(loc='best')
        ax.grid(True)
        
        fig.tight_layout()

    def generate_economic_plot_on_figure(self, fig):
        """Genera il grafico di analisi economica completa con fasce orarie."""
        if not self.results:
            ax = fig.add_subplot(1, 1, 1)
            ax.text(0.5, 0.5, "No results available", ha='center', va='center', fontsize=14)
            return
            
        # Verifica se ci sono generatori a combustibile nel sistema
        fuel_gens = [d for d in self.devices if isinstance(d, FuelGenerator)]
        if not fuel_gens or not self.grid_connection:
            ax = fig.add_subplot(1, 1, 1)
            ax.text(0.5, 0.5, "No fuel generators or grid connection in the system", 
                    ha='center', va='center', fontsize=14)
            return
        
        # Se c'è un solo generatore, mostra analisi dettagliata
        # Se ce ne sono più di uno, mostra solo il confronto costi
        if len(fuel_gens) == 1:
            # Analisi dettagliata per singolo generatore
            gen = fuel_gens[0]
            device_id = gen.device_id
            
            try:
                # Estrai risultati
                alpha_opt = self.results[f"{device_id}_alpha_opt"]
                G_opt = self.results[f"{device_id}_G_opt"]
                
                # Importa la funzione per l'interpolazione
                from piecewise_linear import piecewise_linear_ca1
                eta_vals = np.array(gen.params['eta_values'])
                
                # Calcola costo di produzione istantaneo
                costo_produzione_istante = np.zeros(N)
                for i in range(N):
                    alpha_i = alpha_opt[i]
                    # Gestisci il caso alpha = 0
                    if alpha_i < 0.001:
                        alpha_calc = max(gen.params['P_min'] / gen.params['PN'], 0.1)
                    else:
                        alpha_calc = alpha_i
                    
                    # Interpolazione efficienza
                    eta_alpha = piecewise_linear_ca1(eta_vals[1], eta_vals[0], alpha_calc) / 100
                    # Consumo specifico [kg/kWh]
                    consumo_specifico = 3.6 / (gen.params['PCI'] * eta_alpha)
                    # Costo produzione [c€/kWh]
                    costo_produzione_istante[i] = consumo_specifico * gen.params['cF'] * 100
                
                # Crea DataFrame per l'analisi
                import pandas as pd
                df_analisi = pd.DataFrame({
                    'Ora': time_hours,
                    'Prezzo_vendita': self.grid_connection.params['prezzo_vendita'],
                    'Costo_produzione': costo_produzione_istante,
                    'Generatore_acceso': [a > 0.01 for a in alpha_opt],
                    'Differenza': self.grid_connection.params['prezzo_vendita'] - costo_produzione_istante
                })
                
                # Crea il grafico
                ax = fig.add_subplot(1, 1, 1)
                
                # Plot prezzi e costi
                ax.step(time_hours, self.grid_connection.params['prezzo_vendita'], 'g-', 
                        linewidth=2, label='Grid sale price')
                ax.plot(time_hours, costo_produzione_istante, 'r--', linewidth=2, 
                        marker='o', markersize=3, label=f'Production cost {device_id}')
                
                # Calcola i cambi di stato
                cambio_stato = df_analisi['Generatore_acceso'].diff().fillna(df_analisi['Generatore_acceso'].iloc[0])
                accensioni = df_analisi[cambio_stato & df_analisi['Generatore_acceso']]
                spegnimenti = df_analisi[cambio_stato & ~df_analisi['Generatore_acceso']]
                
                # Evidenzia le fasce in cui il generatore è attivo
                for i, row in df_analisi.iterrows():
                    if row['Generatore_acceso']:
                        ax.axvspan(row['Ora'] - hours_per_interval/2, 
                                  row['Ora'] + hours_per_interval/2, 
                                  alpha=0.2, color='green', label='_nolegend_')
                
                # Markers per accensione/spegnimento
                for i, row in accensioni.iterrows():
                    ax.plot(row['Ora'], self.grid_connection.params['prezzo_vendita'][i], 
                           'go', markersize=10, label='_nolegend_')
                
                for i, row in spegnimenti.iterrows():
                    ax.plot(row['Ora'], self.grid_connection.params['prezzo_vendita'][i], 
                           'ro', markersize=10, label='_nolegend_')
                
                # Linee di riferimento
                min_costo = np.min(costo_produzione_istante)
                max_costo = np.max(costo_produzione_istante)
                ax.axhline(y=min_costo, color='r', linestyle=':', alpha=0.5, 
                          label=f'Min cost ({min_costo:.2f} c€/kWh)')
                ax.axhline(y=max_costo, color='r', linestyle=':', alpha=0.5, 
                          label=f'Max cost ({max_costo:.2f} c€/kWh)')
                
                ax.set_title(f'Economic Analysis and Time Bands  - {device_id}')
                
            except Exception as e:
                print(f"Error processing generator {device_id}: {str(e)}")
                import traceback
                traceback.print_exc()
                
        else:
            # Analisi multi-generatore (solo confronto costi)
            ax = fig.add_subplot(1, 1, 1)
            
            from piecewise_linear import piecewise_linear_ca1
            all_costi_produzione = []
            
            for gen in fuel_gens:
                device_id = gen.device_id
                try:
                    alpha_opt = self.results[f"{device_id}_alpha_opt"]
                    eta_vals = np.array(gen.params['eta_values'])
                    
                    costo_produzione_istante = np.zeros(N)
                    for i in range(N):
                        alpha_i = alpha_opt[i]
                        if alpha_i < 0.001:
                            alpha_calc = max(gen.params['P_min'] / gen.params['PN'], 0.1)
                        else:
                            alpha_calc = alpha_i
                        
                        eta_alpha = piecewise_linear_ca1(eta_vals[1], eta_vals[0], alpha_calc) / 100
                        consumo_specifico = 3.6 / (gen.params['PCI'] * eta_alpha)
                        costo_produzione_istante[i] = consumo_specifico * gen.params['cF'] * 100
                    
                    all_costi_produzione.append(costo_produzione_istante)
                    ax.plot(time_hours, costo_produzione_istante, '-', marker='o', markersize=3, 
                           label=f'Cost {device_id}')
                    
                except Exception as e:
                    print(f"Error processing {device_id}: {e}")
                    continue
            
            # Prezzo vendita
            ax.plot(time_hours, self.grid_connection.params['prezzo_vendita'], 'g-', 
                    linewidth=2, label='Grid sale price')
            
            ax.set_title('Production Costs vs Sale Price Comparison')
        
        # Impostazioni comuni
        ax.set_xlabel('Time [h]')
        ax.set_ylabel('Cost [c€/kWh]')
        ax.legend(loc='best')
        ax.grid(True)
        fig.tight_layout()