import numpy as np
import pandas as pd
from typing import Dict, Any
from CONFIGURA import N

class GridConnection:
    """Class representing a connection to the electrical grid."""
    
    def __init__(self, grid_id: str, excel_filename: str, sheet_name: str):
        self.grid_id = grid_id
        self.excel_filename = excel_filename
        self.sheet_name = sheet_name
        self.load_parameters()
        
    def load_parameters(self) -> None:
        """Load grid tariff parameters from Excel file."""
        try:
            tariffe_data = pd.read_excel(
                self.excel_filename, 
                sheet_name=self.sheet_name,  
                skiprows=3, 
                header=None, 
                usecols=[1, 2],
                dtype={1: float, 2: float}
            )
        except Exception as e:
            print(f"Errore lettura file: {e}")
            return
            
        self.params = {
            'prezzo_vendita': tariffe_data.iloc[:, 0].values,   # colonna 1 -> indice 0
            'prezzo_acquisto': tariffe_data.iloc[:, 1].values,  # colonna 2 -> indice 1
            'sheetname': self.sheet_name
        }
        
    def calculate_cost(self, power_exchange: np.ndarray, hours_per_interval: float) -> float:
        """
        Calculate cost of grid energy exchange.
        Positive power means selling to the grid, negative means buying.
        """
        total_cost = 0
        
        for i in range(len(power_exchange)):
            if power_exchange[i] > 0:  # Vendita
                total_cost -= power_exchange[i] * self.params['prezzo_vendita'][i] * hours_per_interval / 100  # c€ to €
            else:  # Acquisto
                total_cost -= power_exchange[i] * self.params['prezzo_acquisto'][i] * hours_per_interval / 100  # c€ to €
                
        return total_cost
        
    def get_statistics(self, power_exchange: np.ndarray, hours_per_interval: float) -> Dict[str, float]:
        """
        Calculate statistics for grid exchange.
        """
        # Energia totale (acquistata e venduta)
        energy_bought = np.sum(np.maximum(0, -power_exchange)) * hours_per_interval
        energy_sold = np.sum(np.maximum(0, power_exchange)) * hours_per_interval
        
        # Calcola i costi 
        cost_bought = 0
        revenue_sold = 0
        
        for i in range(len(power_exchange)):
            if power_exchange[i] < 0:  # Acquisto
                cost_bought -= power_exchange[i] * self.params['prezzo_acquisto'][i] * hours_per_interval / 100
            else:  # Vendita
                revenue_sold += power_exchange[i] * self.params['prezzo_vendita'][i] * hours_per_interval / 100
                
        # Net energy and cost
        net_energy = energy_sold - energy_bought
        net_cost = cost_bought - revenue_sold
        
        return {
            f"{self.grid_id}_energy_bought": energy_bought,
            f"{self.grid_id}_energy_sold": energy_sold,
            f"{self.grid_id}_cost_bought": cost_bought,
            f"{self.grid_id}_revenue_sold": revenue_sold,
            f"{self.grid_id}_net_energy": net_energy,
            f"{self.grid_id}_net_cost": net_cost
        }