"""
Modulo per la visualizzazione di grafici e statistiche della microgrid.
Implementazione in stile Spyder con salvataggio garantito delle figure.
"""

import tkinter as tk
from tkinter import ttk, scrolledtext, filedialog, messagebox
import matplotlib
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg, NavigationToolbar2Tk
from matplotlib.figure import Figure
from fuel_generator import FuelGenerator
from pv_generator import PVGenerator
from wind_generator import WindGenerator
from battery import Battery
import os
import sys
import numpy as np
from datetime import datetime


# Classe personalizzata per la toolbar di matplotlib che garantisce il salvataggio
class EnhancedNavigationToolbar(NavigationToolbar2Tk):
    """Toolbar che garantisce il salvataggio in tutti i formati."""
    
    def __init__(self, canvas, window):
        super().__init__(canvas, window)
        
        # Aggiunge i formati di salvataggio mancanti
        self.toolitems = (
            ('Home', 'Reset original view', 'home', 'home'),
            ('Back', 'Back to previous view', 'back', 'back'),
            ('Forward', 'Forward to next view', 'forward', 'forward'),
            (None, None, None, None),
            ('Pan', 'Pan axes with left mouse, zoom with right', 'move', 'pan'),
            ('Zoom', 'Zoom to rectangle', 'zoom_to_rect', 'zoom'),
            (None, None, None, None),
            ('Save', 'Save the figure', 'filesave', 'save_figure'),
        )
        
        # Esplicita registrazione dei formati di file
        self.canvas.get_supported_filetypes().update({
            'pdf': 'Portable Document Format (*.pdf)',
            'png': 'Portable Network Graphics (*.png)',
            'jpg': 'Joint Photographic Experts Group (*.jpg)',
            'tif': 'Tagged Image File Format (*.tif)',
            'svg': 'Scalable Vector Graphics (*.svg)'
        })
    
    def save_figure(self, *args):
        """Override del metodo di salvataggio per garantire tutti i formati."""
        filetypes = self.canvas.get_supported_filetypes().copy()
        
        # Assicura che tutti i formati necessari siano presenti
        filetypes['pdf'] = 'Portable Document Format (*.pdf)'
        filetypes['png'] = 'Portable Network Graphics (*.png)'
        filetypes['jpg'] = 'Joint Photographic Experts Group (*.jpg)'
        filetypes['tif'] = 'Tagged Image File Format (*.tif)'
        filetypes['svg'] = 'Scalable Vector Graphics (*.svg)'
        
        # Costruisce lista di default_filetype
        default_filetype = self.canvas.get_default_filetype()
        
        # Costruisce il menu a tendina dei tipi di file
        sorted_filetypes = sorted(filetypes.items())
        tk_filetypes = [(name, '*.%s' % ext) for ext, name in sorted_filetypes]
        
        # Propone inizialmente 'pdf' come tipo di salvataggio
        default_filetype = 'pdf'
        default_filetype_name = filetypes[default_filetype]
        
        initialdir = os.path.expanduser(matplotlib.rcParams['savefig.directory'])
        initialfile = self.canvas.get_default_filename()
        
        fname = filedialog.asksaveasfilename(
            master=self.canvas.get_tk_widget().master,
            title='Save the figure',
            filetypes=tk_filetypes,
            defaultextension='.pdf',
            initialdir=initialdir,
            initialfile=initialfile,
        )
        
        if fname:
            # Salva il percorso come rcParam per usi futuri
            dirname = os.path.dirname(fname)
            if dirname:
                matplotlib.rcParams['savefig.directory'] = dirname
                
            # Salva la figura con impostazioni professionali
            try:
                self.canvas.figure.savefig(fname, dpi=300, bbox_inches='tight')
                messagebox.showinfo("Success", f"Figure saved as {os.path.basename(fname)}")
            except Exception as e:
                messagebox.showerror("Error", f"Error saving figure: {str(e)}")


# Classe per aprire figure in stile Spyder (finestre pop-up)
class SpyderStyleFigure:
    """Apre figure in stile Spyder in finestre separate."""
    
    def __init__(self, parent, optimizer, plot_type, title, device=None):
        self.parent = parent
        self.optimizer = optimizer
        self.plot_type = plot_type
        self.title = title
        self.device = device
        self.figure_window = None
        
    def show(self):
        """Mostra la figura in una finestra separata in stile Spyder."""
        # Crea una nuova finestra
        self.figure_window = tk.Toplevel(self.parent)
        self.figure_window.title(self.title)
        self.figure_window.geometry("800x600")
        self.figure_window.minsize(640, 480)
        
        # Configura la finestra per espandersi con il ridimensionamento
        self.figure_window.columnconfigure(0, weight=1)
        self.figure_window.rowconfigure(0, weight=1)
        
        # Crea un frame contenitore
        frame = ttk.Frame(self.figure_window)
        frame.grid(row=0, column=0, sticky="nsew")
        frame.columnconfigure(0, weight=1)
        frame.rowconfigure(0, weight=1)
        
        # Crea la figura
        fig = Figure(figsize=(10, 6), dpi=100)
               
        # Genera il grafico appropriato
        if self.plot_type == "generation_profile":
            self.optimizer.generate_plot_on_figure(fig, "generation_profile")
            fig.subplots_adjust(hspace=0.2, top=0.95, bottom=0.1, left=0.08, right=0.97)
        elif self.plot_type == "control_variables":
            self.optimizer.generate_plot_on_figure(fig, "control_variables")
        elif self.plot_type == "weather_data":
            self.optimizer.generate_plot_on_figure(fig, "weather_data")
        elif self.plot_type == "battery_profile" and self.device:
            self.optimizer.generate_battery_plot_on_figure(fig, self.device)
        elif self.plot_type == "economic_analysis":
            self.optimizer.generate_economic_plot_on_figure(fig)
        elif self.plot_type == "generator_periods" and self.device:
            self.optimizer.generate_economic_plot_on_figure(fig)
        elif self.plot_type.startswith("device_energy_"):  # AGGIUNGI QUESTO
            self.optimizer.generate_plot_on_figure(fig, self.plot_type)
        
        
        # Crea il canvas per la figura
        canvas = FigureCanvasTkAgg(fig, master=frame)
        canvas.draw()
        
        # Aggiungi la toolbar migliorata
        toolbar = EnhancedNavigationToolbar(canvas, frame)
        toolbar.update()
        
        # Posiziona canvas e toolbar
        toolbar.grid(row=1, column=0, sticky="ew")
        canvas.get_tk_widget().grid(row=0, column=0, sticky="nsew")
        
        # Aggiunge menu contestuale del tasto destro
        self.add_right_click_menu(canvas, fig)
        
        # Gestore eventi ridimensionamento
        def on_resize(event):
            # Ridisegna il grafico quando la finestra viene ridimensionata
            fig.tight_layout()
            canvas.draw_idle()
        
        # Collega evento ridimensionamento
        self.figure_window.bind("<Configure>", on_resize)
        
        # Porta la finestra in primo piano
        self.figure_window.lift()
        self.figure_window.focus_set()
        
        return self.figure_window
    
    def add_right_click_menu(self, canvas, fig):
        """Aggiunge menu contestuale del tasto destro per il salvataggio."""
        # Crea menu contestuale
        context_menu = tk.Menu(canvas.get_tk_widget(), tearoff=0)
        
        # Aggiungi opzioni di salvataggio
        context_menu.add_command(label="Save as PDF", 
                                command=lambda: self.save_figure(fig, "pdf"))
        context_menu.add_command(label="Save as JPEG", 
                                command=lambda: self.save_figure(fig, "jpg"))
        context_menu.add_command(label="Save as TIFF", 
                                command=lambda: self.save_figure(fig, "tif"))
        context_menu.add_command(label="Save as PNG", 
                                command=lambda: self.save_figure(fig, "png"))
        context_menu.add_command(label="Save as SVG", 
                                command=lambda: self.save_figure(fig, "svg"))
        
        # Funzione per mostrare menu contestuale
        def show_context_menu(event):
            context_menu.tk_popup(event.x_root, event.y_root)
        
        # Collega evento tasto destro
        canvas.get_tk_widget().bind("<Button-3>", show_context_menu)
    
    def save_figure(self, fig, format_type):
        """Salva la figura nel formato specificato."""
        extensions = {
            "pdf": "Portable Document Format (*.pdf)",
            "jpg": "Joint Photographic Experts Group (*.jpg)",
            "tif": "Tagged Image File Format (*.tif)",
            "png": "Portable Network Graphics (*.png)",
            "svg": "Scalable Vector Graphics (*.svg)"
        }
        
        # Genera nome file predefinito
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        default_filename = f"{self.title.replace(' ', '_')}_{timestamp}.{format_type}"
        
        # Dialogo di salvataggio
        file_path = filedialog.asksaveasfilename(
            defaultextension=f".{format_type}",
            filetypes=[(extensions[format_type], f"*.{format_type}"), ("All files", "*.*")],
            initialfile=default_filename
        )
        
        if file_path:
            try:
                # Salva la figura con alta qualità
                fig.savefig(file_path, format=format_type, dpi=300, bbox_inches='tight')
                messagebox.showinfo("Success", f"Figure saved successfully as {os.path.basename(file_path)}")
            except Exception as e:
                messagebox.showerror("Error", f"Error saving figure: {str(e)}")


class MicrogridPlotViewer:
    """Classe per visualizzare grafici dei risultati della microgrid."""
    
    def __init__(self, parent, optimizer):
        """
        Inizializza il visualizzatore dei grafici.
        
        Args:
            parent: Il widget tkinter genitore
            optimizer: L'oggetto MicrogridOnGridOptimizer con i risultati
        """
        self.parent = parent
        self.optimizer = optimizer
        self.figure_windows = []
    
    def show_plots_page(self):
        """Mostra tutte le figure in finestre separate in stile Spyder."""
        if not self.optimizer or not self.optimizer.results:
            messagebox.showerror("Error", "No simulation results available. Please run optimization first.")
            return
        
        try:
            # Chiude eventuali finestre aperte in precedenza
            for window in self.figure_windows:
                if window and window.winfo_exists():
                    window.destroy()
            
            self.figure_windows = []
            
            # ========== GRAFICI AGGREGATI (ESISTENTI) ==========
            # 1. Grafico profilo di generazione
            generation_fig = SpyderStyleFigure(
                self.parent, self.optimizer, "generation_profile", "Generation Profile")
            window = generation_fig.show()
            self.figure_windows.append(window)
            
            # 2. Grafico controlli
            control_fig = SpyderStyleFigure(
                self.parent, self.optimizer, "control_variables", "Control Variables")
            window = control_fig.show()
            self.figure_windows.append(window)
            
            # 3. Grafico meteo (solo se ci sono PV o Wind)
            has_weather_devices = any(isinstance(d, (PVGenerator, WindGenerator)) for d in self.optimizer.devices)
            if has_weather_devices:
                weather_fig = SpyderStyleFigure(
                    self.parent, self.optimizer, "weather_data", "Weather Data")
                window = weather_fig.show()
                self.figure_windows.append(window)
            
            # 4. Analisi economica (se ci sono generatori a combustibile)
            fuel_gens = [d for d in self.optimizer.devices if isinstance(d, FuelGenerator)]
            if fuel_gens and self.optimizer.grid_connection:
                # Grafico di analisi economica
                econ_fig = SpyderStyleFigure(
                    self.parent, self.optimizer, "economic_analysis", "Economic Analysis")
                window = econ_fig.show()
                self.figure_windows.append(window)
                
            
            # ========== NUOVI GRAFICI INDIVIDUALI PER OGNI DISPOSITIVO ==========
            
            # Grafici individuali per TUTTI i generatori a combustibile
            for device in self.optimizer.devices:
                if isinstance(device, FuelGenerator):
                    # Crea grafico individuale con 2 subplot
                    device_fig = SpyderStyleFigure(
                        self.parent, self.optimizer, f"device_energy_{device.device_id}", 
                        f"Fuel Generator {device.device_id} - Individual Analysis", device)
                    window = device_fig.show()
                    self.figure_windows.append(window)
            
            # Grafici individuali per tutti i generatori fotovoltaici
            for device in self.optimizer.devices:
                if isinstance(device, PVGenerator):
                    # Crea grafico individuale con 2 subplot
                    device_fig = SpyderStyleFigure(
                        self.parent, self.optimizer, f"device_energy_{device.device_id}", 
                        f"PV Generator {device.device_id} - Individual Analysis", device)
                    window = device_fig.show()
                    self.figure_windows.append(window)
            
            # Grafici individuali per tutti i generatori eolici
            for device in self.optimizer.devices:
                if isinstance(device, WindGenerator):
                    # Crea grafico individuale con 2 subplot
                    device_fig = SpyderStyleFigure(
                        self.parent, self.optimizer, f"device_energy_{device.device_id}", 
                        f"Wind Generator {device.device_id} - Individual Analysis", device)
                    window = device_fig.show()
                    self.figure_windows.append(window)
            
            # Grafici individuali per tutte le batterie (3 subplot ciascuna)
            for device in self.optimizer.devices:
                if isinstance(device, Battery):
                    # Grafico potenza batteria e SOC
                    battery_fig = SpyderStyleFigure(
                        self.parent, self.optimizer, "battery_profile", 
                        f"Battery {device.device_id} - Individual Analysis", device)
                    window = battery_fig.show()
                    self.figure_windows.append(window)
            
        except Exception as e:
            import traceback
            traceback.print_exc()
            messagebox.showerror("Error", f"Error generating plots: {str(e)}")


class MicrogridStatistics:
    """Classe per visualizzare le statistiche della microgrid."""
    
    def __init__(self, parent, optimizer):
        """
        Inizializza il visualizzatore delle statistiche.
        
        Args:
            parent: Il widget tkinter genitore
            optimizer: L'oggetto MicrogridOnGridOptimizer con i risultati
        """
        self.parent = parent
        self.optimizer = optimizer
    
    def show_statistics(self):
        """Mostra una finestra con le statistiche della simulazione."""
        if not self.optimizer or not self.optimizer.results:
            messagebox.showerror("Error", "No simulation results available. Please run optimization first.")
            return
        
        # Crea una nuova finestra
        stats_window = tk.Toplevel(self.parent)
        stats_window.title("Simulation Statistics")
        stats_window.geometry("800x600")
        
        # Frame principale
        main_frame = ttk.Frame(stats_window, padding="10")
        main_frame.pack(fill=tk.BOTH, expand=True)
        
        # TextBox per le statistiche
        stats_text = self.optimizer.get_statistics_text()
        text_box = scrolledtext.ScrolledText(main_frame, wrap=tk.WORD, font=("Courier New", 10))
        text_box.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        text_box.insert(tk.END, stats_text)
        

        # Pulsanti per esportare i dati e chiudere
        button_frame = ttk.Frame(main_frame)
        button_frame.pack(fill=tk.X, pady=10)
        
        ttk.Button(button_frame, text="Close", command=stats_window.destroy).pack(side=tk.RIGHT, padx=5)
        ttk.Button(button_frame, text="Export Statistics", 
                  command=lambda: self.export_statistics(stats_text)).pack(side=tk.RIGHT, padx=5)
        
    def export_statistics(self, stats_text):
        """Esporta le statistiche in un file di testo."""
        output_file = filedialog.asksaveasfilename(
            title="Save Statistics",
            defaultextension=".txt",
            filetypes=(("Text files", "*.txt"), ("All files", "*.*"))
        )
        
        if output_file:
            try:
                with open(output_file, 'w', encoding='utf-8') as f:
                    f.write(stats_text)
                messagebox.showinfo("Success", f"Statistics saved to {output_file}")
            except Exception as e:
                messagebox.showerror("Error", f"Failed to save statistics: {e}")