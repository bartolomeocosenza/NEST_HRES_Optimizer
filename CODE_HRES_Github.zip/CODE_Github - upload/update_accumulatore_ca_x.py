"""
update_accumulatore_ca_x.py

Convenzioni energetiche:
β > 0  ⇒  CHARGE   (SOC↑ , potenza assorbita W<0)
β < 0  ⇒  DISCHARGE (SOC↓ , potenza erogata W>0)
"""

import numpy as np
import casadi as ca
from CONFIGURA import *

def update_accumulatore_ca_x(accumulatore, beta):
    """
    Gestisce:
      - beta come vettore CasADi (MX/SX) o come array NumPy.
      - Se beta è scalare, lo trasforma in un array di un elemento.
    """
    PN = accumulatore['PN']        # potenza nominale batteria [kWe]
    EB = accumulatore['EB']        # capacità batteria [kWh]
    AS = accumulatore['AS']        # autoscarica giornaliera [%]
    eta_S = accumulatore['eta_S']  # rendimento in scarica [-]
    beta_min = accumulatore['beta_min0']  # soglia minima

   
    psi1 = -PN  
    accumulatore['beta'] = beta

    # Riconosciamo se beta è CasADi o NumPy.
    # Se non è CasADi e risulta scalar, lo convertiamo in array per uniformità.
    is_casadi = hasattr(beta, 'is_symbolic')
    if (not is_casadi) and np.isscalar(beta):
        beta = np.array([beta])

    # Calcolo efficienza di scarica (eta) in funzione di beta 
# eps_beta (η1): εβ_S = beta_min * eta_S / 10  # smoothing per η1 (parte "potenza")
    eps_beta = beta_min * eta_S / 10
    #  Protezione numerica per evitare divisione per zero
    eps_beta_safe = max(eps_beta, 1e-12)
    
    if is_casadi:
        eta = ca.MX.ones(beta.size1())  
        
        
        eta = ca.if_else(beta < -beta_min, eta_S, eta)
        

        cond1 = ca.logic_and(beta >= -beta_min, beta < -beta_min + eps_beta)
        slope_1 = -(eta_S - eps_beta) / eps_beta_safe  #  Protezione numerica
        eta = ca.if_else(cond1, slope_1 * (beta_min + beta) + eta_S, eta)
        

        cond2 = ca.logic_and(beta >= -beta_min + eps_beta, beta < beta_min - eps_beta)
        eta = ca.if_else(cond2, eps_beta, eta)
        

        cond3 = ca.logic_and(beta >= beta_min - eps_beta, beta < beta_min)
        slope_3 = (1 - eps_beta) / eps_beta_safe  # Protezione numerica
        eta = ca.if_else(cond3, slope_3 * (beta - beta_min) + 1, eta)
        
    else:
        # Caso NumPy array 
        eta = np.ones_like(beta)  # The otherwise case
        
        eta[beta < -beta_min] = eta_S
        

        idx_tmp_1 = (beta >= -beta_min) & (beta < -beta_min + eps_beta)
        slope_1 = -(eta_S - eps_beta) / eps_beta_safe  # Protezione numerica
        eta[idx_tmp_1] = slope_1 * (beta_min + beta[idx_tmp_1]) + eta_S
        

        idx_tmp_2 = (beta >= -beta_min + eps_beta) & (beta < beta_min - eps_beta)
        eta[idx_tmp_2] = eps_beta
        

        idx_tmp_3 = (beta >= beta_min - eps_beta) & (beta < beta_min)
        slope_3 = (1 - eps_beta) / eps_beta_safe  # Protezione numerica
        eta[idx_tmp_3] = slope_3 * (beta[idx_tmp_3] - beta_min) + 1

    accumulatore['A'] = psi1 * eta * beta
    accumulatore['eta'] = eta

    # Calcolo di Psi e SOC
    psi2 = -AS / N * 100
    psi3 = (tau / 60) * (PN / EB) * 100

    Psi, SOC = Psi_func(accumulatore, psi2, psi3, beta, beta_min)
    accumulatore['Psi'] = Psi
    accumulatore['SOC'] = SOC

    # Uscita di W (uguale ad A)
    accumulatore['W'] = accumulatore['A']

    return accumulatore


def Psi_func(accumulatore, psi2, psi3, beta, beta_min):
    """
    Calcolo di Psi e SOC 
    """
    # Parametri comuni
    eta_C = accumulatore['eta_C']
    SOC_min = accumulatore['SOC_min']
    SOC_max = accumulatore['SOC_max']
    SOC_0   = accumulatore['SOC_0']

    is_casadi = hasattr(beta, 'is_symbolic')
    if (not is_casadi) and np.isscalar(beta):
        beta = np.array([beta])


    eps_beta = beta_min * eta_C / 10  
    # PROTEZIONI NUMERICHE per evitare divisioni per zero
    eps_beta_safe = max(eps_beta, 1e-12)
    beta_min_diff_safe = max(abs(beta_min - eps_beta), 1e-12)
    
    if is_casadi:
        N_var = beta.size1()
        eta = eta_C * ca.MX.ones(N_var)  
        

        eta = ca.if_else(beta < -beta_min, 1.0, eta)
        

        cond1 = ca.logic_and(beta >= -beta_min, beta < -beta_min + eps_beta)
        slope_1 = -(1 - eps_beta) / beta_min_diff_safe  #  Protezione numerica
        eta = ca.if_else(cond1, slope_1 * (beta_min + beta) + 1, eta)
        

        cond2 = ca.logic_and(beta >= -beta_min + eps_beta, beta < beta_min - eps_beta)
        eta = ca.if_else(cond2, eps_beta, eta)
        

        cond3 = ca.logic_and(beta >= beta_min - eps_beta, beta < beta_min)
        slope_3 = (eta_C - eps_beta) / beta_min_diff_safe  #  Protezione numerica
        eta = ca.if_else(cond3, slope_3 * (beta - beta_min) + eta_C, eta)
        
        # Calcolo SOC
        SOC = ca.MX.zeros(N_var)
        SOC[0] = SOC_0 + psi2 + psi3 * eta[0] * beta[0]
        for i in range(1, N_var):
            SOC[i] = SOC[i-1] + psi2 + psi3 * eta[i] * beta[i]
            
        Psi = ca.vertcat((SOC - SOC_max) / 100, (SOC_min - SOC) / 100)
        
    else:
        # Caso NumPy 
        N_var = len(beta)
        eta = eta_C * np.ones(N_var)  
        

        eta[beta < -beta_min] = 1.0
        

        idx_tmp_1 = (beta >= -beta_min) & (beta < -beta_min + eps_beta)
        slope_1 = -(1 - eps_beta) / beta_min_diff_safe  #  Protezione numerica
        eta[idx_tmp_1] = slope_1 * (beta_min + beta[idx_tmp_1]) + 1
        

        idx_tmp_2 = (beta >= -beta_min + eps_beta) & (beta < beta_min - eps_beta)
        eta[idx_tmp_2] = eps_beta
        

        idx_tmp_3 = (beta >= beta_min - eps_beta) & (beta < beta_min)
        slope_3 = (eta_C - eps_beta) / beta_min_diff_safe  #  Protezione numerica
        eta[idx_tmp_3] = slope_3 * (beta[idx_tmp_3] - beta_min) + eta_C
        
        # Calcolo SOC
        SOC = np.zeros(N_var)
        SOC[0] = SOC_0 + psi2 + psi3 * eta[0] * beta[0]
        for i in range(1, N_var):
            SOC[i] = SOC[i-1] + psi2 + psi3 * eta[i] * beta[i]
            
        Psi = np.concatenate([(SOC - SOC_max) / 100, (SOC_min - SOC) / 100])

    return Psi, SOC


def calculate_psi_parameters(accumulatore, N, tau):
    """
    Calcola i parametri psi2_acc e psi3_acc a partire dall'oggetto accumulatore.
    
    Args:
        accumulatore: dizionario con i parametri dell'accumulatore
        N: numero di intervalli temporali
        tau: durata di ciascun intervallo in minuti
        
    Returns:
        tuple: (psi2_acc, psi3_acc)
    """
    AS = accumulatore['AS']        # autoscarica giornaliera [%]
    PN = accumulatore['PN']        # potenza nominale batteria [kWe]
    EB = accumulatore['EB']        # capacità batteria [kWh]
    
    psi2_acc = -AS/N * 100
    psi3_acc = (tau/60)*(PN/EB)*100
    
    return psi2_acc, psi3_acc