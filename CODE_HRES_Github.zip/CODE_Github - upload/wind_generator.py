import numpy as np
import matplotlib.cm as cm 
import matplotlib.pyplot as plt
import casadi as ca
import pandas as pd
from abc import ABC, abstractmethod
from typing import List, Dict, Any, Optional, Tuple
from CONFIGURA import *
from update_gen_eoli import update_gen_eoli_ca
from device_base import Device
from carica_gen_eoli import carica_gen_eoli

class WindGenerator(Device):
    """Class representing a wind generator."""
    
    def __init__(self, device_id: str, excel_filename: str, sheet_name: str, weather_filename: str, meteo_sheet: str = "Meteo8"):
        super().__init__(device_id, excel_filename, sheet_name)
        self.weather_filename = weather_filename
        self.meteo_sheet = meteo_sheet
        self.load_parameters()
        
    def load_parameters(self) -> None:
        """Load wind generator parameters from Excel file."""
       
        self.params = carica_gen_eoli(self.excel_filename, self.sheet_name)
        
        # Carica i dati meteo
        meteo_data = pd.read_excel(self.weather_filename, sheet_name=self.meteo_sheet)
        self.params['v'] = meteo_data['v(i)'].values[:N]
        
    def create_control_variables(self, opti: ca.Opti) -> Dict[str, ca.MX]:
        """Create control variables for wind generator."""
        alpha = opti.variable(N)  # [0, 1] control variable
        return {"alpha": alpha}
        
    def add_constraints(self, opti: ca.Opti, variables: Dict[str, Any], timestep: int) -> None:
        """Add constraints for wind generator at a specific timestep."""
        alpha = variables[f"{self.device_id}_alpha"][timestep]
        
        # Se la velocità del vento è sotto il valore limite, la turbina è spenta
        if self.params['v'][timestep] < self.params['v_min']:  # Velocità minima del vento
            opti.subject_to(alpha == 0)
        else:
            opti.subject_to(0 <= alpha)
            opti.subject_to(alpha <= 1)
        
    def add_to_objective(self, opti: ca.Opti, variables: Dict[str, Any]) -> ca.MX:
        """Add wind cost term to objective (if any)."""
        alpha = variables[f"{self.device_id}_alpha"]
        
        return P_wind * ca.sum1(alpha) # if 'P_wind' in globals() else 0
        
    def calculate_power_output(self, variables: Dict[str, Any], timestep: int) -> float:
        """Calculate power output for a specific timestep using numpy values."""
        
        alpha = variables[f"{self.device_id}_alpha_opt"][timestep]
        return update_gen_eoli_ca(self.params, alpha, timestep)['G']
    
    def calculate_power_output_casadi(self, variables: Dict[str, Any], timestep: int) -> ca.MX:
        """Calculate power output for a specific timestep using CasADi variables."""
        
        alpha = variables[f"{self.device_id}_alpha"][timestep]
        return update_gen_eoli_ca(self.params, alpha, timestep)['G']
        
    def extract_results(self, sol: ca.OptiSol, variables: Dict[str, Any]) -> Dict[str, Any]:
        """Extract optimization results for this generator."""
        
        
        alpha_opt = sol.value(variables[f"{self.device_id}_alpha"])
        
        # Calcola i valori ottimali della potenza
        G_opt = np.zeros(N)
        for i in range(N):
            G_opt[i] = update_gen_eoli_ca(self.params, alpha_opt[i], i)['G']
            
        return {
            f"{self.device_id}_alpha_opt": alpha_opt,
            f"{self.device_id}_G_opt": G_opt
        }
        
    def plot_results(self, time_hours: np.ndarray, results: Dict[str, Any], ax=None) -> None:
        """Plot wind generator results."""
        # Non fare nulla, i grafici individuali sono disabilitati
        pass
        
    def get_statistics(self, results: Dict[str, Any]) -> Dict[str, float]:
        """Calculate and return generator statistics."""
        G_opt = results[f"{self.device_id}_G_opt"]
        total_energy = np.sum(G_opt) * hours_per_interval
            
        return {
            f"{self.device_id}_total_energy": total_energy
        }



