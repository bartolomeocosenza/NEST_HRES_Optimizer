import numpy as np
import matplotlib.cm as cm 
import matplotlib.pyplot as plt
import casadi as ca
import pandas as pd
from abc import ABC, abstractmethod
from typing import List, Dict, Any, Optional, Tuple
from CONFIGURA import *
from device_base import Device
from pv_generator import PVGenerator
from wind_generator import WindGenerator
from fuel_generator import FuelGenerator
from battery import Battery
from load import Load
import os

class MicrogridOptimizer:
    """Class for optimizing microgrid operation with multiple devices."""
    
    def __init__(self):
        self.devices = []
        self.loads = []
        self.variables = {}
        self.results = {}
        
        # Pesi per le variabili di slack 
        self.P_slack_load = P_slack_load  # Peso penalizzazione slack per il carico
        self.P_slack_soc = P_slack_soc  # Peso penalizzazione slack per SOC finale
       
        # Valore di tolleranza per bilancio energetico
        self.eps_balance = 1e-6
        self.output_dir = "output"
        if not os.path.exists(self.output_dir):
            os.makedirs(self.output_dir)
        
        
    def add_device(self, device: Device) -> None:
        """Add a device to the microgrid."""
        self.devices.append(device)
        
    def add_load(self, load: Load) -> None:
        """Add a load to the microgrid."""
        self.loads.append(load)
    
    def preprocess_fuel_generators(self):
        """
        Identifica quando i generatori a combustibile sono necessari in base
        alla disponibilità massima di energia rinnovabile e al carico richiesto.
        Eseguito solo se non ci sono batterie nel sistema.
        
        Returns:
            dict: Un dizionario con chiavi device_id e valori array booleani che indicano
                  quando il generatore combustibile è necessario.
        """
        # Cerca tutti i dispositivi nel sistema
        fuel_gens = [d for d in self.devices if isinstance(d, FuelGenerator)]
        pv_gens = [d for d in self.devices if isinstance(d, PVGenerator)]
        wind_gens = [d for d in self.devices if isinstance(d, WindGenerator)]
        
        # Se non ci sono generatori a combustibile, non c'è bisogno di preprocessing
        if not fuel_gens:
            return {}
        
        # Calcolo carico totale in ogni timestep
        total_load = np.zeros(N)
        for load in self.loads:
            total_load += np.array([load.get_load(i) for i in range(N)])
        
        # Calcolo potenza massima rinnovabile in ogni timestep
        max_renewable = np.zeros(N)
        
        for i in range(N):
            # Potenza massima da PV
            pv_max_power = 0
            for device in pv_gens:
                # Verifica se c'è irraggiamento solare sufficiente
                if device.params['DNI'][i] > 1e-6:
                    # Usa direttamente i modelli dei dispositivi
                    from update_gen_foto import update_gen_foto_ca
                    # Simula alpha = 1 (massima potenza)
                    pv_max_power += float(update_gen_foto_ca(device.params, 1.0, i)['G'])
            
            # Potenza massima da eolico
            wind_max_power = 0
            for device in wind_gens:
                # Verifica se c'è vento sufficiente
                if device.params['v'][i] >= 3.0:
                    # Usa direttamente i modelli dei dispositivi
                    from update_gen_eoli import update_gen_eoli_ca
                    # Simula alpha = 1 (massima potenza)
                    wind_max_power += float(update_gen_eoli_ca(device.params, 1.0, i)['G'])
            
            max_renewable[i] = pv_max_power + wind_max_power
        
        # Determina quando ogni generatore è necessario
        fuel_gen_needed = {}
        
        # Usa questa logica: se il carico totale supera la potenza rinnovabile massima,
        # allora il generatore a combustibile sarà necessario
        comb_needed = total_load > max_renewable
        
        # Assegno lo stesso array a tutti i generatori a combustibile
        # In un sistema più complesso, si potrebbe differenziare la necessità tra i generatori
        for device in fuel_gens:
            fuel_gen_needed[device.device_id] = comb_needed
            
        return fuel_gen_needed
        
    def setup_and_solve(self) -> bool:
        """Set up and solve the optimization problem."""
        # Crea l'ottimizzatore Casadi
        opti = ca.Opti()
        
        # Crea le variabili di slack per load  SOC
        slack_load_up = opti.variable(N)
        slack_load_down = opti.variable(N)
        slack_SOC = opti.variable()
        
        # Aggiungi variabili Slack al nostro dizionario delle variabili
        self.variables["slack_load_up"] = slack_load_up
        self.variables["slack_load_down"] = slack_load_down
        self.variables["slack_SOC"] = slack_SOC
        
        # Vincoli sulle variabili Slack
        opti.subject_to(slack_load_up >= 0)
        opti.subject_to(slack_load_down >= 0)
        opti.subject_to(slack_SOC >= 0)
        
        # Crea variabili di controllo per ogni dispositivo
        for device in self.devices:
            device_vars = device.create_control_variables(opti)
            for var_name, var in device_vars.items():
                self.variables[f"{device.device_id}_{var_name}"] = var
        
        # Verifica se ci sono batterie nel sistema
        batteries = [device for device in self.devices if isinstance(device, Battery)]
        has_batteries = len(batteries) > 0
                                                                # =========== # 
        # Esegui preprocessing solo se non ci sono batterie     PREPROCESSING
        fuel_gen_needed = {}                                    # =========== #    
        if not has_batteries:
            fuel_gen_needed = self.preprocess_fuel_generators()
                
        # Aggiungere vincoli e costruire la funzione obiettivo
        objective = 0
        for device in self.devices:
            # Aggiungere termini oggettivi specifici del dispositivo
            objective += device.add_to_objective(opti, self.variables)
            
        # Aggiungere penalità di allentamento alla funzione obiettivo
        objective += self.P_slack_load * ca.sum1(slack_load_up + slack_load_down)
        objective += self.P_slack_soc * slack_SOC
            
        opti.minimize(objective)
        
        # Estende la classe FuelGenerator per supportare l'operazione di preprocessing
        # Determina quando il generatore è necessario in base alla disponibilità rinnovabile
        # al momento dell'aggiunta di vincoli
        
        def add_constraints_with_preprocessing(device, opti, variables, timestep):
            if isinstance(device, FuelGenerator) and device.device_id in fuel_gen_needed:
                # Modifica il comportamento per il generatore a combustibile
                # in base ai risultati del preprocessing
                alpha = variables[f"{device.device_id}_alpha"][timestep]
                
                comb_needed_array = fuel_gen_needed[device.device_id]
                min_power = device.params['P_min'] / device.params['PN']
                
                if comb_needed_array[timestep]:
                    # Se in questo timestep è necessario il generatore
                    opti.subject_to(alpha >= min_power)
                    opti.subject_to(alpha <= 1)
                    
                    # Aggiunge vincolo che potenza non zero
                    G_i = device.calculate_power_output_casadi(variables, timestep)
                    opti.subject_to(G_i > 1e-5)
                else:
                    # Altrimenti usa i vincoli standard definiti nella classe FuelGenerator
                    device.add_constraints(opti, variables, timestep)

            else:
                # Per tutti gli altri dispositivi, usa il metodo standard
                device.add_constraints(opti, variables, timestep)
        
        for i in range(N):
            # Prima i vincoli della batteria (SOC)
            for device in self.devices:
                if isinstance(device, Battery):
                    device.add_constraints(opti, self.variables, i)
            
            # Poi vincoli del fotovoltaico
            for device in self.devices:
                if isinstance(device, PVGenerator):
                    device.add_constraints(opti, self.variables, i)
            
            # Poi vincoli dell'eolico
            for device in self.devices:
                if isinstance(device, WindGenerator):
                    device.add_constraints(opti, self.variables, i)
            
            # Infine vincoli del generatore a combustibile, con preprocessing se necessario
            for device in self.devices:
                if isinstance(device, FuelGenerator):
                    add_constraints_with_preprocessing(device, opti, self.variables, i)
                
            # Vincolo di bilanciamento della potenza con variabili Slack
            generation = 0
            for device in self.devices:
                generation += device.calculate_power_output_casadi(self.variables, i)
                
            load = 0
            for load_obj in self.loads:
                load += load_obj.get_load(i)
                
            # Vincolo di bilanciamento con variabili slack
            opti.subject_to(generation <= load + self.eps_balance + slack_load_up[i])
            opti.subject_to(generation >= load - self.eps_balance - slack_load_down[i])
            

        for device in self.devices:
            if isinstance(device, Battery):
                device.add_final_constraints(opti, self.variables, slack_SOC)
    
        # Initial values con inizializzazione intelligente per i generatori a combustibile
        # in base al preprocessing
        pv_gens = [d for d in self.devices if isinstance(d, PVGenerator)]
        wind_gens = [d for d in self.devices if isinstance(d, WindGenerator)]
        fuel_gens = [d for d in self.devices if isinstance(d, FuelGenerator)]
        batteries = [d for d in self.devices if isinstance(d, Battery)]
        
        # Inizializzazione intelligente per ogni timestep
        for i in range(N):
            # Fotovoltaico
            for device in pv_gens:
                alpha_var = self.variables[f"{device.device_id}_alpha"]
                if device.params['DNI'][i] > 1e-6:
                    opti.set_initial(alpha_var[i], min(1.0, device.params['DNI'][i] / 1000.0))
                else:
                    opti.set_initial(alpha_var[i], 0.0)
            
            # Eolico
            for device in wind_gens:
                alpha_var = self.variables[f"{device.device_id}_alpha"]
                if device.params['v'][i] >= 3.0:
                    wind_factor = min(1.0, (device.params['v'][i] - 3.0) / 12.0)
                    opti.set_initial(alpha_var[i], wind_factor)
                else:
                    opti.set_initial(alpha_var[i], 0.0)
            
            # Generatore a combustibile con inizializzazione basata sul preprocessing
            for device in fuel_gens:
                alpha_var = self.variables[f"{device.device_id}_alpha"]
                if not has_batteries and device.device_id in fuel_gen_needed:
                    # Usa i risultati del preprocessing per l'inizializzazione
                    comb_needed_array = fuel_gen_needed[device.device_id]
                    min_power = device.params['P_min'] / device.params['PN']
                    
                    if comb_needed_array[i]:
                        # Se necessario, inizializza al valore minimo
                        opti.set_initial(alpha_var[i], min_power)
                    else:
                        # Altrimenti, inizializza a zero
                        opti.set_initial(alpha_var[i], 0.0)
                else:
                    # Inizializzazione standard
                    opti.set_initial(alpha_var[i], 0.2)  # Valore basso iniziale
            
            # Batteria
            for device in batteries:
                beta_var = self.variables[f"{device.device_id}_beta"]
                opti.set_initial(beta_var[i], 0.0)  # Valore neutro iniziale
                
        # Imposta i valori iniziali per le variabili Slack
        opti.set_initial(slack_load_up, 0)
        opti.set_initial(slack_load_down, 0)
        opti.set_initial(slack_SOC, 0)
        
        # Imposta le opzioni del risolutore
        opti.solver('ipopt', opts)
        
        # Solve
        
        try:
            sol = opti.solve()
            
            # Estrai i risultati delle variabili Slack
            self.results["slack_load_up_opt"] = sol.value(slack_load_up)
            self.results["slack_load_down_opt"] = sol.value(slack_load_down)
            self.results["slack_SOC_opt"] = sol.value(slack_SOC)
            
            # Metti i risultati del preprocessing nei risultati
            if not has_batteries:
                for device_id, needed_array in fuel_gen_needed.items():
                    self.results[f"{device_id}_preprocessing_needed"] = needed_array
            
            # Estrai i risultati dei dispositivi
            for device in self.devices:
                device_results = device.extract_results(sol, self.variables)
                self.results.update(device_results)
            
    
            # Salva i setpoint in Excel
            self.save_setpoints_to_excel()
                
            return True
        except Exception as e:
            print(f"Optimization failed: {e}")
            return False
           
    def generate_plots(self) -> None:
         """
         Metodo deprecato - la visualizzazione è ora gestita da microgrid_off_grid_visualization.py
         Mantenuto per compatibilità ma non genera più grafici direttamente.
         """
         print("Note: Plot generation is now handled by the visualization module.")
         print("Use MicrogridOffGridPlotViewer for interactive plotting.")
     
    def plot_meteo(self) -> None:
        """
        Metodo deprecato - la visualizzazione è ora gestita da microgrid_off_grid_visualization.py
        Mantenuto per compatibilità ma non genera più grafici direttamente.
        """
        print("Note: Weather plot generation is now handled by the visualization module.")
        print("Use MicrogridOffGridPlotViewer for interactive plotting.")    
   
    
    def print_statistics(self) -> None:
        """Print statistics for the optimized system."""
        if not self.results:
            print("No results to analyze.")
            return

        # Calcolo del mismatch
        P_tot = np.zeros(N)
        
        # Somma generatori e batterie
        for device in self.devices:
            device_power_key = f"{device.device_id}_G_opt"
            if device_power_key in self.results:
                P_tot += np.array(self.results[device_power_key])
            
            battery_power_key = f"{device.device_id}_P_batt_opt"
            if battery_power_key in self.results:
                P_tot += np.array(self.results[battery_power_key])
        
        # Calcola carico totale
        total_load = np.zeros(N)
        for load in self.loads:
            for i in range(N):
                total_load[i] += load.get_load(i)
        
        # Raccogli statistiche da ogni dispositivo
        for device in self.devices:
            stats = device.get_statistics(self.results)
            device_type = device.__class__.__name__
            
            print(f"\n{device_type} ({device.device_id}):")
            for name, value in stats.items():
                # Converti valori CasADi in tipi Python standard
                if hasattr(value, 'full'):  # Verifica se è un tipo CasADi
                    value = float(value.full().flatten()[0])
                    
                if name.endswith('_total_energy'):
                    print(f" - Total energy: {float(value):.2f} kWh")
                elif name.endswith('_fuel_consumption'):
                    print(f" - Fuel consumption: {float(value):.2f} kg")
                elif name.endswith('_liters_of_diesel'):
                    if value is not None:
                        print(f" - Diesel volume: {float(value):.2f} L")
                elif name.endswith('_num_starts'):
                    print(f" - Number of starts: {int(value)}")
                elif name.endswith('_total_exchanged'):
                    print(f" - Energy exchanged: {float(value):.2f} kWh")
                elif name.endswith('_net_energy'):
                    print(f" - Net energy (pos=discharge): {float(value):.2f} kWh")
                elif name.endswith('_final_SOC'):
                    print(f" - Final SOC: {float(value):.2f}%")
                elif name.endswith('_min_SOC'):
                    print(f" - Min SOC: {float(value):.2f}%")
                elif name.endswith('_max_SOC'):
                    print(f" - Max SOC: {float(value):.2f}%")
     
    def save_setpoints_to_excel(self):
        """Salva i setpoint dei dispositivi in un file Excel."""
        # Prepara i dati per il file Excel
        data = {'Time[h]': time_hours}
        
        # Aggiungi i setpoint di ogni dispositivo
        for device in self.devices:
            device_id = device.device_id
            
            if isinstance(device, (PVGenerator, WindGenerator, FuelGenerator)):
                # Generatori con alpha come setpoint
                if f"{device_id}_alpha_opt" in self.results:
                    data[f"{device_id}_alpha"] = self.results[f"{device_id}_alpha_opt"]
            
            if isinstance(device, Battery):
                # Batterie con beta come setpoint
                if f"{device_id}_beta_opt" in self.results:
                    data[f"{device_id}_beta"] = self.results[f"{device_id}_beta_opt"]
            
        # Crea il DataFrame e salva in Excel
        df = pd.DataFrame(data)
        output_file = os.path.join(self.output_dir, "SETPOINT_DEVICES.xlsx")
        df.to_excel(output_file, index=False)
        print(f"Setpoints saved to {output_file}")                
     
    def debug_mismatch(self):
        """
        Individua il timestep con mismatch massimo e mostra:
        - carico
        - potenza da rinnovabili
        - potenze per device
        - slack
        """
        if not self.results:
            print("No results to analyze.")
            return
    
        P_tot = np.zeros(N)
        for dev in self.devices:
            P_tot += np.array(self.results.get(f"{dev.device_id}_G_opt", np.zeros(N)))
            P_tot += np.array(self.results.get(f"{dev.device_id}_P_batt_opt", np.zeros(N)))
    
        total_load = np.zeros(N)
        for i in range(N):
            for ld in self.loads:
                total_load[i] += ld.get_load(i)
    
        mismatch = P_tot - total_load
        max_mismatch = np.max(np.abs(mismatch))
        
        # SOGLIA PER CONSIDERARE IL MISMATCH TRASCURABILE
        MISMATCH_THRESHOLD = 1e-3  # 1 mW
        
        if max_mismatch < MISMATCH_THRESHOLD:
            print(f"\n✅ Perfect power balance achieved! (max mismatch: {max_mismatch:.6f} kW - negligible)")
            return
        
        # Se il mismatch è significativo, mostra i dettagli
        idx = int(np.argmax(np.abs(mismatch)))
    
        # --- Blocco: carico e rinnovabili ---
        load_at_idx = total_load[idx]
    
        pv_kW = sum(
            self.results[f"{dev.device_id}_G_opt"][idx]
            for dev in self.devices if isinstance(dev, PVGenerator)
        )
        wind_kW = sum(
            self.results[f"{dev.device_id}_G_opt"][idx]
            for dev in self.devices if isinstance(dev, WindGenerator)
        )
        renew_kW = pv_kW + wind_kW
    
        print(f"\n⚠️  Significant mismatch detected: {mismatch[idx]:.3f} kW (timestep {idx})")
        print(f"    • Load             : {load_at_idx:8.3f} kW")
        print(f"    • Renewables (PV+W): {renew_kW:8.3f} kW  "
              f"(PV {pv_kW:.3f}  –  Wind {wind_kW:.3f})")
    
        # --- dettagli per generatore ---
        for dev in self.devices:
            g = self.results.get(f"{dev.device_id}_G_opt", [0]*N)[idx]
            b = self.results.get(f"{dev.device_id}_P_batt_opt", [0]*N)[idx]
            print(f"  {dev.device_id:15s}  G={g:8.3f} kW   P_batt={b:8.3f} kW")
    
        # --- slack nello stesso timestep ---
        up   = self.results['slack_load_up_opt'][idx]
        down = self.results['slack_load_down_opt'][idx]
        print(f"  slack_up={up:.3f}  slack_down={down:.3f}\n")





