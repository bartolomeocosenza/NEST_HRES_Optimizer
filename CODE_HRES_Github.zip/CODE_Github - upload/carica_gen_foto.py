import pandas as pd
import numpy as np
from update_gen_foto import update_gen_foto
from CONFIGURA import *  # Importa i parametri dalla configurazione

def carica_gen_foto(excel_filename, sheetname, weather_filename=None, meteo_sheet=None, ta_column=None, dni_column=None):

    # Legge i dati dal foglio specificato
    dati_gen_foto = pd.read_excel(
        excel_filename,
        sheet_name=sheetname,
        usecols="B",
        skiprows=4,
        nrows=8,
        header=None
    ).values.flatten()
    
    gen_foto = {}
    gen_foto['sheetname'] = sheetname
    gen_foto['type'] = 'gen_foto'
    gen_foto['DNIr'] = dati_gen_foto[0]        # DNI_r: irraggiamento di riferimento [1000 W/m^2]
    gen_foto['gamma'] = dati_gen_foto[1]       # γ(k): coefficiente di correzione della potenza [°C^-1]
    gen_foto['Tr'] = dati_gen_foto[2]          # T_r: temperatura di riferimento [°C]
    gen_foto['c'] = dati_gen_foto[3]           # c(k): coefficiente di tilt per il pannello [-]
    gen_foto['r'] = dati_gen_foto[4]           # r(k): coefficiente correttivo di Ross [°C m^2/W]
    gen_foto['eta'] = dati_gen_foto[5]         # η(k): rendimento complessivo di sistema [-]
    gen_foto['Delta_Tr'] = dati_gen_foto[6]    # ΔT_r(k): differenza di temperatura standard [°C]
    gen_foto['PN'] = dati_gen_foto[7]          # PN(k): potenza nominale [kWe]
    
    gen_foto['G'] = np.zeros(N)
    
    # Legge il vettore alpha di default dalla colonna M
    alpha = pd.read_excel(
        excel_filename,
        sheet_name=sheetname,
        usecols="M",
        skiprows=4,
        nrows=N,
        header=None
    )
    gen_foto['alpha'] = alpha.values.flatten()  
    
    # CARICAMENTO DATI METEO
    if weather_filename and meteo_sheet and ta_column and dni_column:
        # Carica dati meteo
        meteo_data = pd.read_excel(weather_filename, sheet_name=meteo_sheet)
        gen_foto['Ta'] = meteo_data[ta_column].values[:N]
        gen_foto['DNI'] = meteo_data[dni_column].values[:N]
    else:
        # Se dati meteo non forniti, imposta array vuoti
        gen_foto['Ta'] = np.zeros(N)
        gen_foto['DNI'] = np.zeros(N)
    
    # Aggiorna i dati con la funzione di aggiornamento
    gen_foto = update_gen_foto(gen_foto, gen_foto['alpha'])
    
    # Definizione del numero di variabili di ottimizzazione
    gen_foto['n_x'] = N
    
    return gen_foto

