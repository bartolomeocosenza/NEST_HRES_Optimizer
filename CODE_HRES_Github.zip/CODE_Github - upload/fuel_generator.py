import numpy as np
import matplotlib.cm as cm 
import matplotlib.pyplot as plt
import casadi as ca
import pandas as pd
from abc import ABC, abstractmethod
from typing import List, Dict, Any, Optional, Tuple
from CONFIGURA import *
from update_gen_comb_ca import *
from device_base import Device
from carica_gen_comb import carica_gen_comb

class FuelGenerator(Device):
    """Class representing a fuel-based generator."""
    
    def __init__(self, device_id: str, excel_filename: str, sheet_name: str):
        super().__init__(device_id, excel_filename, sheet_name)
        self.load_parameters()
        
    def load_parameters(self) -> None:
        """Load fuel generator parameters from Excel file."""
        
        self.params = carica_gen_comb(self.excel_filename, self.sheet_name)
        
    def create_control_variables(self, opti: ca.Opti) -> Dict[str, ca.MX]:
        """Create control variables for fuel generator."""
        alpha = opti.variable(N)  # [0, 1] control variable
       
        return {"alpha": alpha}
        
    def add_constraints(self, opti: ca.Opti, variables: Dict[str, Any], timestep: int) -> None:
        """Add constraints for fuel generator at a specific timestep."""
        alpha = variables[f"{self.device_id}_alpha"][timestep]
        
        # Vincoli su alpha
        opti.subject_to(0 <= alpha)
        opti.subject_to(alpha <= 1)
        
        # Aggiunge il seguente vincolo: se la potenza è sotto il valore limite allora alpha deve essere zero
        G_i = self.calculate_power_output_casadi(variables, timestep)
        opti.subject_to(ca.if_else(G_i < 1e-5, alpha, 0) == 0)
        
    def add_to_objective(self, opti: ca.Opti, variables: Dict[str, Any]) -> ca.MX:
        """Add fuel consumption and smoothing terms to objective."""
        alpha = variables[f"{self.device_id}_alpha"]
        
        # Consumo di combustibile
        F_comb = 0
        for i in range(N):
            # Usa una copia 
            params_copy = self.params.copy()
            out_comb = update_gen_comb_ca(params_copy, alpha[i])
            F_comb += out_comb['F'] * hours_per_interval
            
        # Calcola Psi per i vincoli
        min_power = self.params['P_min'] / self.params['PN']
        Psi, Psi_sig, N_acc, N_acc_sig = calcola_Psi_vettoriale(alpha, min_power, self.params['N_acc_max'])
        variables[f"{self.device_id}_N_acc"] = N_acc
        
        # Vincolo sul numero di accensioni usando Psi (equivalente a N_acc <= N_acc_max)
        opti.subject_to(Psi <= 0)
            
        # Smoothing term
        smoothing = ca.sum1(alpha**2)
        
        # usa il costo specifico del combustibile caricato da Excel
        fuel_cost = F_comb * self.params['cF']
        
        # Opzionale qualora si volesse considerare anche il costo di accensione
        # start_cost = N_acc * self.params['c_acc']
        
        return P_fuel * fuel_cost + P_comb * smoothing
        # Alternativa con costo di accensione: 
        # return P_fuel * fuel_cost + P_comb * smoothing + P_start * start_cost
        
    def calculate_power_output(self, variables: Dict[str, Any], timestep: int) -> float:
        """Calculate power output for a specific timestep using numpy values."""
        alpha = variables[f"{self.device_id}_alpha_opt"][timestep]
        return update_gen_comb_ca(self.params, alpha)['G']
    
    def calculate_power_output_casadi(self, variables: Dict[str, Any], timestep: int) -> ca.MX:
        """Calculate power output for a specific timestep using CasADi variables."""
        alpha = variables[f"{self.device_id}_alpha"][timestep]
        return update_gen_comb_ca(self.params, alpha)['G']
        
    def calculate_fuel_consumption_casadi(self, variables: Dict[str, Any], timestep: int) -> ca.MX:
        """Calculate fuel consumption for a specific timestep using CasADi variables."""
        alpha = variables[f"{self.device_id}_alpha"][timestep]
        return update_gen_comb_ca(self.params, alpha)['F']
    
    def extract_results(self, sol: ca.OptiSol, variables: Dict[str, Any]) -> Dict[str, Any]:
        """Extract optimization results for this generator."""
        alpha_opt = sol.value(variables[f"{self.device_id}_alpha"])
        
        # Calcola i valori di potenza ottimali
        G_opt = np.zeros(N)
        F_comb = 0
        for i in range(N):
            out = update_gen_comb_ca(self.params, alpha_opt[i])
            G_opt[i] = out['G']
            F_comb += out['F'] * hours_per_interval
            
        # Ottieni il numero di avvii
        if f"{self.device_id}_N_acc" in variables:
            N_acc = sol.value(variables[f"{self.device_id}_N_acc"])
        else:
            # Calcola se non memorizzato nelle variabili
            min_power = self.params['P_min'] / self.params['PN']
            N_acc = calcola_Psi(alpha_opt, min_power, self.params['N_acc_max'], use_sigmoid=False)
        
        return {
            f"{self.device_id}_alpha_opt": alpha_opt,
            f"{self.device_id}_G_opt": G_opt,
            f"{self.device_id}_F_comb": F_comb,
            f"{self.device_id}_N_acc": N_acc
        }
        
    def plot_results(self, time_hours: np.ndarray, results: Dict[str, Any], ax=None) -> None:
        """Plot fuel generator results."""
        # Non fare nulla, i grafici individuali sono disabilitati
        pass
        
    def get_statistics(self, results: Dict[str, Any]) -> Dict[str, float]:
        """Calculate and return generator statistics."""
        G_opt = results[f"{self.device_id}_G_opt"]
        F_comb = results[f"{self.device_id}_F_comb"]
        N_acc = results[f"{self.device_id}_N_acc"]
        
        total_energy = np.sum(G_opt) * hours_per_interval
        
        # Calcola i litri di combustibile se il valore della densità non è disponibile.
        liters_of_diesel = None
        if 'ro' in self.params and self.params['ro'] > 0:
            if hasattr(F_comb, 'full'):
                F_comb_value = float(F_comb.full().flatten()[0])
            else:
                F_comb_value = float(F_comb)
            liters_of_diesel = F_comb_value / self.params['ro']
        
        # Converti N_acc da tipo CasADi a numero Python
        if hasattr(N_acc, 'full'):  # Verifica se è un tipo CasADi
            N_acc_value = int(float(N_acc.full().flatten()[0]))
        else:
            N_acc_value = int(float(N_acc))
            
        return {
            f"{self.device_id}_total_energy": total_energy,
            f"{self.device_id}_fuel_consumption": F_comb,
            f"{self.device_id}_liters_of_diesel": liters_of_diesel,
            f"{self.device_id}_num_starts": N_acc_value
        }