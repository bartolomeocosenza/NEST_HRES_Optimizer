import tkinter as tk
from tkinter import ttk, scrolledtext, filedialog, messagebox
import matplotlib
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg, NavigationToolbar2Tk
from matplotlib.figure import Figure
import os
import sys
import numpy as np
from datetime import datetime
import matplotlib.cm as cm

# Import device types per type checking
sys.path.append(os.path.dirname(os.path.abspath(__file__)))
from fuel_generator import FuelGenerator
from pv_generator import PVGenerator
from wind_generator import WindGenerator
from battery import Battery
from CONFIGURA import N, time_hours, hours_per_interval


# Classe personalizzata per la toolbar di matplotlib che garantisce il salvataggio
class EnhancedNavigationToolbar(NavigationToolbar2Tk):
    """Toolbar migliorata che garantisce il salvataggio in tutti i formati."""
    
    def __init__(self, canvas, window):
        super().__init__(canvas, window)
        
        # Aggiunge i formati di salvataggio mancanti
        self.toolitems = (
            ('Home', 'Reset original view', 'home', 'home'),
            ('Back', 'Back to previous view', 'back', 'back'),
            ('Forward', 'Forward to next view', 'forward', 'forward'),
            (None, None, None, None),
            ('Pan', 'Pan axes with left mouse, zoom with right', 'move', 'pan'),
            ('Zoom', 'Zoom to rectangle', 'zoom_to_rect', 'zoom'),
            (None, None, None, None),
            ('Save', 'Save the figure', 'filesave', 'save_figure'),
        )
        
        # Esplicita registrazione dei formati di file
        self.canvas.get_supported_filetypes().update({
            'pdf': 'Portable Document Format (*.pdf)',
            'png': 'Portable Network Graphics (*.png)',
            'jpg': 'Joint Photographic Experts Group (*.jpg)',
            'tif': 'Tagged Image File Format (*.tif)',
            'svg': 'Scalable Vector Graphics (*.svg)'
        })
    
    def save_figure(self, *args):
        """Override del metodo di salvataggio per garantire tutti i formati."""
        filetypes = self.canvas.get_supported_filetypes().copy()
        
        # Assicura che tutti i formati necessari siano presenti
        filetypes['pdf'] = 'Portable Document Format (*.pdf)'
        filetypes['png'] = 'Portable Network Graphics (*.png)'
        filetypes['jpg'] = 'Joint Photographic Experts Group (*.jpg)'
        filetypes['tif'] = 'Tagged Image File Format (*.tif)'
        filetypes['svg'] = 'Scalable Vector Graphics (*.svg)'
        
        # Costruire lista di default_filetype
        default_filetype = self.canvas.get_default_filetype()
        
        # Costruire il menu a tendina dei tipi di file
        sorted_filetypes = sorted(filetypes.items())
        tk_filetypes = [(name, '*.%s' % ext) for ext, name in sorted_filetypes]
        
        # Proporre inizialmente 'pdf' come tipo di salvataggio
        default_filetype = 'pdf'
        default_filetype_name = filetypes[default_filetype]
        
        initialdir = os.path.expanduser(matplotlib.rcParams['savefig.directory'])
        initialfile = self.canvas.get_default_filename()
        
        fname = filedialog.asksaveasfilename(
            master=self.canvas.get_tk_widget().master,
            title='Save the figure',
            filetypes=tk_filetypes,
            defaultextension='.pdf',
            initialdir=initialdir,
            initialfile=initialfile,
        )
        
        if fname:
            # Salva il percorso come rcParam per usi futuri
            dirname = os.path.dirname(fname)
            if dirname:
                matplotlib.rcParams['savefig.directory'] = dirname
                
            # Salva la figura con impostazioni professionali
            try:
                self.canvas.figure.savefig(fname, dpi=300, bbox_inches='tight')
                messagebox.showinfo("Success", f"Figure saved as {os.path.basename(fname)}")
            except Exception as e:
                messagebox.showerror("Error", f"Error saving figure: {str(e)}")


# Classe per aprire figure in stile Spyder (finestre pop-up)
class SpyderStyleFigure:
    """Apre figure in stile Spyder in finestre separate."""
    
    def __init__(self, parent, optimizer, plot_type, title):
        self.parent = parent
        self.optimizer = optimizer
        self.plot_type = plot_type
        self.title = title
        self.figure_window = None
        
    def show(self):
        """Mostra la figura in una finestra separata in stile Spyder."""
        # Crea una nuova finestra
        self.figure_window = tk.Toplevel(self.parent)
        self.figure_window.title(self.title)
        self.figure_window.geometry("900x700")
        self.figure_window.minsize(640, 480)
        
        # Configura la finestra per espandersi con il ridimensionamento
        self.figure_window.columnconfigure(0, weight=1)
        self.figure_window.rowconfigure(0, weight=1)
        
        # Crea un frame contenitore
        frame = ttk.Frame(self.figure_window)
        frame.grid(row=0, column=0, sticky="nsew")
        frame.columnconfigure(0, weight=1)
        frame.rowconfigure(0, weight=1)
        
        # Crea la figura
        fig = Figure(figsize=(12, 8), dpi=100)
        
        # Genera il grafico appropriato
        if self.plot_type == "generation_profile":
            self.optimizer.generate_combined_plot_on_figure(fig)
        elif self.plot_type == "energy_balance":
            self.optimizer.generate_energy_balance_plot_on_figure(fig)
        elif self.plot_type == "control_variables":
            self.optimizer.generate_control_plot_on_figure(fig)
        elif self.plot_type == "weather_data":
            self.optimizer.generate_weather_plot_on_figure(fig)
        elif self.plot_type.startswith("device_energy_"):  # AGGIUNGI QUESTO
            device_id = self.plot_type.replace("device_energy_", "")
            self.optimizer.generate_device_plot_on_figure(fig, device_id)
        elif self.plot_type.startswith("battery_profile_"):  # AGGIUNGI QUESTO
            device_id = self.plot_type.replace("battery_profile_", "")
            self.optimizer.generate_battery_plot_on_figure(fig, device_id)
        
        # Crea il canvas per la figura
        canvas = FigureCanvasTkAgg(fig, master=frame)
        canvas.draw()
        
        # Aggiunge la toolbar migliorata
        toolbar = EnhancedNavigationToolbar(canvas, frame)
        toolbar.update()
        
        # Posiziona canvas e toolbar
        toolbar.grid(row=1, column=0, sticky="ew")
        canvas.get_tk_widget().grid(row=0, column=0, sticky="nsew")
        
        # Aggiunge menu contestuale del tasto destro
        self.add_right_click_menu(canvas, fig)
        
        # Gestore eventi ridimensionamento
        def on_resize(event):
            # Ridisegnare il grafico quando la finestra viene ridimensionata
            fig.tight_layout()
            canvas.draw_idle()
        
        # Collega evento ridimensionamento
        self.figure_window.bind("<Configure>", on_resize)
        
        # Porta la finestra in primo piano
        self.figure_window.lift()
        self.figure_window.focus_set()
        
        return self.figure_window
    
    def add_right_click_menu(self, canvas, fig):
        """Aggiunge menu contestuale del tasto destro per il salvataggio."""
        # Crea menu contestuale
        context_menu = tk.Menu(canvas.get_tk_widget(), tearoff=0)
        
        # Aggiunge opzioni di salvataggio
        context_menu.add_command(label="Save as PDF", 
                                command=lambda: self.save_figure(fig, "pdf"))
        context_menu.add_command(label="Save as JPEG", 
                                command=lambda: self.save_figure(fig, "jpg"))
        context_menu.add_command(label="Save as TIFF", 
                                command=lambda: self.save_figure(fig, "tif"))
        context_menu.add_command(label="Save as PNG", 
                                command=lambda: self.save_figure(fig, "png"))
        context_menu.add_command(label="Save as SVG", 
                                command=lambda: self.save_figure(fig, "svg"))
        
        # Funzione per mostrare menu contestuale
        def show_context_menu(event):
            context_menu.tk_popup(event.x_root, event.y_root)
        
        # Collega evento tasto destro
        canvas.get_tk_widget().bind("<Button-3>", show_context_menu)
    
    def save_figure(self, fig, format_type):
        """Salva la figura nel formato specificato."""
        extensions = {
            "pdf": "Portable Document Format (*.pdf)",
            "jpg": "Joint Photographic Experts Group (*.jpg)",
            "tif": "Tagged Image File Format (*.tif)",
            "png": "Portable Network Graphics (*.png)",
            "svg": "Scalable Vector Graphics (*.svg)"
        }
        
        # Genera nome file predefinito
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        default_filename = f"{self.title.replace(' ', '_')}_{timestamp}.{format_type}"
        
        # Dialogo di salvataggio
        file_path = filedialog.asksaveasfilename(
            defaultextension=f".{format_type}",
            filetypes=[(extensions[format_type], f"*.{format_type}"), ("All files", "*.*")],
            initialfile=default_filename
        )
        
        if file_path:
            try:
                # Salva la figura con alta qualità
                fig.savefig(file_path, format=format_type, dpi=300, bbox_inches='tight')
                messagebox.showinfo("Success", f"Figure saved successfully as {os.path.basename(file_path)}")
            except Exception as e:
                messagebox.showerror("Error", f"Error saving figure: {str(e)}")


class MicrogridOffGridPlotViewer:
    """Classe per visualizzare grafici dei risultati della microgrid OFF-GRID."""
    
    def __init__(self, parent, optimizer):
        """
        Inizializza il visualizzatore dei grafici.
        
        Args:
            parent: Il widget tkinter genitore
            optimizer: L'oggetto MicrogridOptimizer con i risultati
        """
        self.parent = parent
        self.optimizer = optimizer
        self.figure_windows = []
        
        # COLORI 
        self.base_colors = {
            'fuel': '#4A4A4A',        # Grigio scuro più marcato (era #808080)
            'pv': '#FF9500',          # Arancione solare più brillante (era #FDB813)
            'wind': '#007AFF',        # Blu vento più intenso (era #00A0DC)
            'battery_discharge': '#00C853',  # Verde scarica più vivido (era #2ECC71)
            'battery_charge': '#FF1744'      # Rosso carica più acceso (era #E74C3C)
        }
        
        # Aggiungere metodi per generare i plot sul MicrogridOptimizer
        self._add_plotting_methods()
    
    def _add_plotting_methods(self):
        """Aggiunge metodi di plotting all'optimizer per generare plot su figure specifiche."""
        
        def generate_combined_plot_on_figure(fig):
            """Genera il grafico combinato (3 subplot) sulla figura fornita."""
            if not self.optimizer.results:
                ax = fig.add_subplot(1, 1, 1)
                ax.text(0.5, 0.5, "No results available", ha='center', va='center', fontsize=14)
                return
            
            # Raggruppa dispositivi per tipo
            fuel_gens = [d for d in self.optimizer.devices if isinstance(d, FuelGenerator)]
            pv_gens = [d for d in self.optimizer.devices if isinstance(d, PVGenerator)]
            wind_gens = [d for d in self.optimizer.devices if isinstance(d, WindGenerator)]
            batteries = [d for d in self.optimizer.devices if isinstance(d, Battery)]
            
            # Colori più vividi con gradiente
            pv_colors = cm.YlOrBr(np.linspace(0.4, 1.0, max(1, len(pv_gens))))
            wind_colors = cm.Blues(np.linspace(0.4, 1.0, max(1, len(wind_gens))))
            fuel_colors = cm.Greys(np.linspace(0.5, 0.9, max(1, len(fuel_gens))))
            batt_discharge_colors = cm.Greens(np.linspace(0.4, 1.0, max(1, len(batteries))))
            batt_charge_colors = cm.Reds(np.linspace(0.4, 1.0, max(1, len(batteries))))
            
            # Calcola il carico totale
            total_load = np.zeros(N)
            for load in self.optimizer.loads:
                total_load += load.params['C']
            
            # Prepara i dati
            generators = []
            gen_names = []
            gen_colors = []
            
            # Aggiungere generatori in ordine: PV, Wind, Fuel
            for i, device in enumerate(pv_gens):
                generators.append(self.optimizer.results[f"{device.device_id}_G_opt"])
                gen_names.append(f"{device.device_id}")
                gen_colors.append(pv_colors[i])
                
            for i, device in enumerate(wind_gens):
                generators.append(self.optimizer.results[f"{device.device_id}_G_opt"])
                gen_names.append(f"{device.device_id}")
                gen_colors.append(wind_colors[i])
                
            for i, device in enumerate(fuel_gens):
                generators.append(self.optimizer.results[f"{device.device_id}_G_opt"])
                gen_names.append(f"{device.device_id}")
                gen_colors.append(fuel_colors[i])
            
            # Batterie
            battery_discharge = []
            discharge_names = []
            discharge_colors = []
            
            for i, device in enumerate(batteries):
                P_batt = self.optimizer.results[f"{device.device_id}_P_batt_opt"]
                battery_discharge.append(np.maximum(P_batt, 0))
                discharge_names.append(f"{device.device_id} (discharge)")
                discharge_colors.append(batt_discharge_colors[i])
            
            # 1) Generazione totale + carico
            ax1 = fig.add_subplot(3, 1, 1)
            all_gen_data = generators.copy()
            all_gen_data.extend(battery_discharge)
            all_gen_names = gen_names.copy()
            all_gen_names.extend(discharge_names)
            all_gen_colors = gen_colors.copy()
            all_gen_colors.extend(discharge_colors)
            
            ax1.stackplot(time_hours, *all_gen_data, labels=all_gen_names, 
                         colors=all_gen_colors, alpha=0.8, edgecolor='white', linewidth=0.5)
            ax1.plot(time_hours, total_load, 'k--', label='Load', linewidth=2.5)
            ax1.set_xlabel('Time [h]', fontsize=11)
            ax1.set_ylabel('Power [kW]', fontsize=11)
            ax1.set_title('Generation Profile', fontsize=13, fontweight='bold')
            ax1.legend(loc='upper left', fontsize=9)
            ax1.grid(True, alpha=0.3)
            ax1.set_facecolor('#f8f9fa')
            
            # 2) Potenza batteria
            ax2 = fig.add_subplot(3, 1, 2)
            if batteries:
                all_batt_discharge = np.zeros(N)
                all_batt_charge = np.zeros(N)
                
                for P_discharge in battery_discharge:
                    all_batt_discharge += P_discharge
                
                battery_charge = []
                for i, device in enumerate(batteries):
                    P_batt = self.optimizer.results[f"{device.device_id}_P_batt_opt"]
                    battery_charge.append(np.maximum(-P_batt, 0))
                
                for P_charge in battery_charge:
                    all_batt_charge += P_charge
                
                ax2.fill_between(time_hours, 0, all_batt_discharge, 
                                color=self.base_colors['battery_discharge'], alpha=0.8, 
                                label='Discharging phase', step='mid', edgecolor='white', linewidth=1)
                ax2.fill_between(time_hours, 0, -all_batt_charge,
                                color=self.base_colors['battery_charge'], alpha=0.8, 
                                label='Charging phase', step='mid', edgecolor='white', linewidth=1)
                ax2.axhline(y=0, color='k', linestyle='-', linewidth=0.8)
            else:
                ax2.text(0.5, 0.5, 'No batteries in the system', 
                        ha='center', va='center', fontsize=14, color='gray')
            
            ax2.set_xlabel('Time [h]', fontsize=11)
            ax2.set_ylabel('Power [kW]', fontsize=11)
            ax2.set_title('Battery Power Profile', fontsize=13, fontweight='bold')
            if batteries:
                ax2.legend(loc='upper left', fontsize=9)
            ax2.grid(True, alpha=0.3)
            ax2.set_facecolor('#f8f9fa')
            
            # 3) SOC
            ax3 = fig.add_subplot(3, 1, 3)
            if batteries:
                for i, device in enumerate(batteries):
                    SOC_opt = self.optimizer.results[f"{device.device_id}_SOC_opt"]
                    SOC_0 = device.params['SOC_0']
                    t_path = np.r_[time_hours[0], time_hours + hours_per_interval]
                    soc_path = np.r_[SOC_0, SOC_opt]
                    soc_min_path = np.full_like(soc_path, device.params['SOC_min'])
                    
                    ax3.plot(t_path, soc_path, '-', linewidth=2.5, 
                            label=f'{device.device_id} SOC', color=batt_discharge_colors[i])
                    ax3.fill_between(t_path, soc_path, soc_min_path, 
                                    alpha=0.3, color=batt_discharge_colors[i])
                    
                    # Linee di riferimento
                    ax3.axhline(y=device.params['SOC_min'], color='#FF1744', linestyle='--', 
                               linewidth=1.5, label='Min SOC' if i == 0 else '')
                    ax3.axhline(y=device.params['SOC_max'], color='#00C853', linestyle='--', 
                               linewidth=1.5, label='Max SOC' if i == 0 else '')
                    ax3.axhline(y=device.params['SOC_Target'], color='#FFD600', linestyle='--', 
                               linewidth=1.5, label='Target SOC' if i == 0 else '')
            else:
                ax3.text(0.5, 0.5, 'No batteries in the system', 
                        ha='center', va='center', fontsize=14, color='gray')
            
            ax3.set_xlabel('Time [h]', fontsize=11)
            ax3.set_ylabel('SOC [%]', fontsize=11)
            ax3.set_title('Battery State of Charge', fontsize=13, fontweight='bold')
            if batteries:
                ax3.legend(loc='best', fontsize=9)
            ax3.grid(True, alpha=0.3)
            ax3.set_facecolor('#f8f9fa')
            
            fig.tight_layout(pad=2.0)
        
        def generate_energy_balance_plot_on_figure(fig):
            """Genera il grafico del bilancio energetico sulla figura fornita."""
            if not self.optimizer.results:
                ax = fig.add_subplot(1, 1, 1)
                ax.text(0.5, 0.5, "No results available", ha='center', va='center', fontsize=14)
                return
            
            # Raggruppa dispositivi
            fuel_gens = [d for d in self.optimizer.devices if isinstance(d, FuelGenerator)]
            pv_gens = [d for d in self.optimizer.devices if isinstance(d, PVGenerator)]
            wind_gens = [d for d in self.optimizer.devices if isinstance(d, WindGenerator)]
            batteries = [d for d in self.optimizer.devices if isinstance(d, Battery)]
            
            # Colori vividi
            pv_colors = cm.YlOrBr(np.linspace(0.4, 1.0, max(1, len(pv_gens))))
            wind_colors = cm.Blues(np.linspace(0.4, 1.0, max(1, len(wind_gens))))
            fuel_colors = cm.Greys(np.linspace(0.5, 0.9, max(1, len(fuel_gens))))
            batt_discharge_colors = cm.Greens(np.linspace(0.4, 1.0, max(1, len(batteries))))
            batt_charge_colors = cm.Reds(np.linspace(0.4, 1.0, max(1, len(batteries))))
            
            # Carico totale
            total_load = np.zeros(N)
            for load in self.optimizer.loads:
                total_load += load.params['C']
            
            ax = fig.add_subplot(1, 1, 1)
            
            # Prepara dati
            all_data = []
            all_names = []
            all_colors = []
            
            # Aggiunge generatori
            for i, device in enumerate(fuel_gens):
                all_data.append(self.optimizer.results[f"{device.device_id}_G_opt"])
                all_names.append(f"{device.device_id}")
                all_colors.append(fuel_colors[i])
            
            for i, device in enumerate(pv_gens):
                all_data.append(self.optimizer.results[f"{device.device_id}_G_opt"])
                all_names.append(f"{device.device_id}")
                all_colors.append(pv_colors[i])
            
            for i, device in enumerate(wind_gens):
                all_data.append(self.optimizer.results[f"{device.device_id}_G_opt"])
                all_names.append(f"{device.device_id}")
                all_colors.append(wind_colors[i])
            
            # Aggiunge batterie (scarica)
            for i, device in enumerate(batteries):
                P_batt = self.optimizer.results[f"{device.device_id}_P_batt_opt"]
                all_data.append(np.maximum(P_batt, 0))
                all_names.append(f"{device.device_id} (discharge)")
                all_colors.append(batt_discharge_colors[i])
            
            # Stackplot
            ax.stackplot(time_hours, *all_data, labels=all_names, colors=all_colors, 
                        alpha=0.8, edgecolor='white', linewidth=0.5)
            
            # Aggiunge batterie (carica)
            if batteries:
                for i, device in enumerate(batteries):
                    P_batt = self.optimizer.results[f"{device.device_id}_P_batt_opt"]
                    charge = np.maximum(-P_batt, 0)
                    ax.stackplot(time_hours, charge, 
                                labels=[f"{device.device_id} (charge)"],
                                colors=[batt_charge_colors[i]],
                                alpha=0.8, edgecolor='white', linewidth=0.5)
            
            ax.plot(time_hours, total_load, 'k--', label='Load', linewidth=2.5)
            ax.set_xlabel('Time [h]', fontsize=12)
            ax.set_ylabel('Power [kW]', fontsize=12)
            ax.set_title('Energy Balance with Battery Charge/Discharge', fontsize=14, fontweight='bold')
            ax.legend(loc='upper right', fontsize=10)
            ax.grid(True, alpha=0.3)
            ax.set_facecolor('#f8f9fa')
            
            fig.tight_layout()
        
        def generate_control_plot_on_figure(fig):
            """Genera il grafico delle variabili di controllo sulla figura fornita."""
            if not self.optimizer.results:
                ax = fig.add_subplot(1, 1, 1)
                ax.text(0.5, 0.5, "No results available", ha='center', va='center', fontsize=14)
                return
            
            # Raggruppa dispositivi
            fuel_gens = [d for d in self.optimizer.devices if isinstance(d, FuelGenerator)]
            pv_gens = [d for d in self.optimizer.devices if isinstance(d, PVGenerator)]
            wind_gens = [d for d in self.optimizer.devices if isinstance(d, WindGenerator)]
            batteries = [d for d in self.optimizer.devices if isinstance(d, Battery)]
            
            # Colori vividi
            fuel_colors = ['#4A4A4A', '#6A6A6A', '#8A8A8A']
            pv_colors = ['#FF9500', '#FFB143', '#FFCC86']
            wind_colors = ['#007AFF', '#339CFF', '#66BEFF']
            battery_colors = ['#00C853', '#00E676', '#69F0AE']
            
            ax = fig.add_subplot(1, 1, 1)
            
            # Plot variabili di controllo
            line_idx = 0
            for i, device in enumerate(fuel_gens):
                alpha = self.optimizer.results[f"{device.device_id}_alpha_opt"]
                ax.plot(time_hours, alpha, label=f'Fuel Gen ({device.device_id})', 
                       color=fuel_colors[i % len(fuel_colors)], linewidth=2.0, marker='o', markersize=3)
                line_idx += 1
            
            for i, device in enumerate(pv_gens):
                alpha = self.optimizer.results[f"{device.device_id}_alpha_opt"]
                ax.plot(time_hours, alpha, label=f'PV ({device.device_id})',
                       color=pv_colors[i % len(pv_colors)], linewidth=2.0, marker='s', markersize=3)
                line_idx += 1
            
            for i, device in enumerate(wind_gens):
                alpha = self.optimizer.results[f"{device.device_id}_alpha_opt"]
                ax.plot(time_hours, alpha, label=f'Wind ({device.device_id})',
                       color=wind_colors[i % len(wind_colors)], linewidth=2.0, marker='^', markersize=3)
                line_idx += 1
            
            for i, device in enumerate(batteries):
                beta = self.optimizer.results[f"{device.device_id}_beta_opt"]
                ax.plot(time_hours, beta, label=f'Battery ({device.device_id})',
                       color=battery_colors[i % len(battery_colors)], linewidth=2.0, marker='d', markersize=3)
                line_idx += 1
            
            ax.set_xlabel('Time [h]', fontsize=12)
            ax.set_ylabel('Control Value', fontsize=12)
            ax.set_title('Control Variables', fontsize=14, fontweight='bold')
            ax.legend(loc='best', fontsize=10, ncol=2)
            ax.grid(True, alpha=0.3)
            ax.set_facecolor('#f8f9fa')
            ax.set_ylim(-0.1, 1.1)
            
            fig.tight_layout()
        
        def generate_weather_plot_on_figure(fig):
            """Genera il grafico dei dati meteo sulla figura fornita."""
            # Cerca dispositivi
            pv_generators = [dev for dev in self.optimizer.devices if isinstance(dev, PVGenerator)]
            wind_generators = [dev for dev in self.optimizer.devices if isinstance(dev, WindGenerator)]
            
            if not pv_generators and not wind_generators:
                ax = fig.add_subplot(1, 1, 1)
                ax.text(0.5, 0.5, "No weather-dependent devices in the system", 
                       ha='center', va='center', fontsize=14)
                return
            
            # DNI e Temperatura
            if pv_generators:
                pv_gen = pv_generators[0]
                DNI = pv_gen.params['DNI']
                Ta = pv_gen.params['Ta']
                
                ax1 = fig.add_subplot(3, 1, 1)
                ax1.plot(time_hours, DNI, '#FF9500', linewidth=2.5, label="DNI (Solar Irradiance)")
                ax1.fill_between(time_hours, DNI, alpha=0.4, color='#FF9500')
                ax1.set_xlabel('Time [h]', fontsize=11)
                ax1.set_ylabel('Solar Irradiance [W/m²]', fontsize=11)
                ax1.set_title('Solar Irradiance Profile', fontsize=13, fontweight='bold')
                ax1.legend(fontsize=10)
                ax1.grid(True, alpha=0.3)
                ax1.set_facecolor('#fff8e1')
                
                ax3 = fig.add_subplot(3, 1, 3)
                ax3.plot(time_hours, Ta, '#FF1744', linewidth=2.5, label="Temperature")
                ax3.fill_between(time_hours, Ta, alpha=0.4, color='#FF1744')
                ax3.set_xlabel('Time [h]', fontsize=11)
                ax3.set_ylabel('Temperature [°C]', fontsize=11)
                ax3.set_title('Temperature Profile', fontsize=13, fontweight='bold')
                ax3.legend(fontsize=10)
                ax3.grid(True, alpha=0.3)
                ax3.set_facecolor('#ffebee')
            else:
                ax1 = fig.add_subplot(3, 1, 1)
                ax1.text(0.5, 0.5, "No PV Generator in the system.", ha='center', va='center', color='gray')
                ax1.set_axis_off()
                
                ax3 = fig.add_subplot(3, 1, 3)
                ax3.text(0.5, 0.5, "No PV Generator in the system.", ha='center', va='center', color='gray')
                ax3.set_axis_off()
            
            # Wind
            if wind_generators:
                wind_gen = wind_generators[0]
                wind_speed = wind_gen.params['v']
                
                ax2 = fig.add_subplot(3, 1, 2)
                ax2.plot(time_hours, wind_speed, '#007AFF', linewidth=2.5, label="Wind Speed")
                ax2.fill_between(time_hours, wind_speed, alpha=0.4, color='#007AFF')
                ax2.set_xlabel('Time [h]', fontsize=11)
                ax2.set_ylabel('Wind Speed [m/s]', fontsize=11)
                ax2.set_title('Wind Speed Profile', fontsize=13, fontweight='bold')
                ax2.legend(fontsize=10)
                ax2.grid(True, alpha=0.3)
                ax2.set_facecolor('#e3f2fd')
            else:
                ax2 = fig.add_subplot(3, 1, 2)
                ax2.text(0.5, 0.5, "No Wind Generator in the system.", ha='center', va='center', color='gray')
                ax2.set_axis_off()
            
            fig.tight_layout(pad=2.0)
        
        def generate_device_plot_on_figure(fig, device_id):
            """Genera il grafico individuale per un dispositivo con 2 subplot."""
            if not self.optimizer.results:
                ax = fig.add_subplot(1, 1, 1)
                ax.text(0.5, 0.5, "No results available", ha='center', va='center', fontsize=14)
                return
            
            # Trovare il dispositivo
            device = next((d for d in self.optimizer.devices if d.device_id == device_id), None)
            if not device:
                ax = fig.add_subplot(1, 1, 1)
                ax.text(0.5, 0.5, f"Device {device_id} not found", ha='center', va='center', fontsize=14)
                return
            
            if isinstance(device, (FuelGenerator, PVGenerator, WindGenerator)):
                # 2 subplot per generatori: Energia + Variabile controllo
                ax1 = fig.add_subplot(2, 1, 1)
                ax2 = fig.add_subplot(2, 1, 2)
                
                # Subplot 1: Energia
                G_opt = self.optimizer.results[f"{device_id}_G_opt"]
                ax1.plot(time_hours, G_opt, linewidth=2.5, label=f'{device_id} Power Output')
                ax1.fill_between(time_hours, G_opt, alpha=0.3)
                ax1.set_xlabel('Time [h]', fontsize=11)
                ax1.set_ylabel('Power [kW]', fontsize=11)
                ax1.set_title(f'{device_id} - Energy Profile', fontsize=13, fontweight='bold')
                ax1.legend(fontsize=10)
                ax1.grid(True, alpha=0.3)
                ax1.set_facecolor('#f8f9fa')
                
                # Subplot 2: Variabile controllo
                alpha_opt = self.optimizer.results[f"{device_id}_alpha_opt"]
                ax2.plot(time_hours, alpha_opt, 'r-', linewidth=2.5, label=f'{device_id} Control (α)')
                ax2.set_xlabel('Time [h]', fontsize=11)
                ax2.set_ylabel('Control Value', fontsize=11)
                ax2.set_title(f'{device_id} - Control Variable', fontsize=13, fontweight='bold')
                ax2.legend(fontsize=10)
                ax2.grid(True, alpha=0.3)
                ax2.set_facecolor('#f8f9fa')
                ax2.set_ylim(-0.1, 1.1)
                
            fig.tight_layout(pad=2.0)

        def generate_battery_plot_on_figure(fig, device_id):
            """Genera il grafico individuale per una batteria con 3 subplot."""
            if not self.optimizer.results:
                ax = fig.add_subplot(1, 1, 1)
                ax.text(0.5, 0.5, "No results available", ha='center', va='center', fontsize=14)
                return
            
            # Trovare il dispositivo
            device = next((d for d in self.optimizer.devices if d.device_id == device_id), None)
            if not device or not isinstance(device, Battery):
                ax = fig.add_subplot(1, 1, 1)
                ax.text(0.5, 0.5, f"Battery {device_id} not found", ha='center', va='center', fontsize=14)
                return
            
            # Ottiene i dati della batteria
            SOC_opt = self.optimizer.results[f"{device_id}_SOC_opt"]
            P_batt_opt = self.optimizer.results[f"{device_id}_P_batt_opt"]
            beta_opt = self.optimizer.results[f"{device_id}_beta_opt"]
            
            # 1) Potenza batteria (carica/scarica)
            ax1 = fig.add_subplot(3, 1, 1)
            pos_batt = np.maximum(P_batt_opt, 0)  # scarica batteria
            neg_batt = np.minimum(P_batt_opt, 0)  # carica batteria
            
            ax1.stackplot(time_hours, 
                        pos_batt, 
                        neg_batt,
                        labels=['Discharging phase', 'Charging phase'],
                        colors=['#00C853', '#FF1744'],
                        alpha=0.8)
            ax1.axhline(y=0, color='k', linestyle='-', linewidth=0.8)
            ax1.set_xlabel('Time [h]', fontsize=11)
            ax1.set_ylabel('Power [kW]', fontsize=11)
            ax1.set_title(f'Battery {device.device_id} - Power Profile', fontsize=13, fontweight='bold')
            ax1.legend(loc='upper left', fontsize=10)
            ax1.grid(True, alpha=0.3)
            ax1.set_facecolor('#f8f9fa')
            
            # 2) SOC
            ax2 = fig.add_subplot(3, 1, 2)
            SOC_0 = float(device.params['SOC_0'])
            soc_path = np.r_[SOC_0, np.asarray(SOC_opt).reshape(-1)]        # N+1 punti
            t_path   = np.arange(soc_path.size) * hours_per_interval         # 0, Δt, ... NΔt
            soc_min_path = np.full_like(soc_path, device.params['SOC_min'])
            
            ax2.plot(t_path, soc_path, 'b-', linewidth=2.5, label='SOC')
            ax2.fill_between(t_path, soc_path, soc_min_path, alpha=0.3, color='blue')
            ax2.axhline(y=device.params['SOC_min'], color='#FF1744', linestyle='--', 
                       linewidth=1.5, label=f"Min SOC = {device.params['SOC_min']}%")
            ax2.axhline(y=device.params['SOC_max'], color='#00C853', linestyle='--', 
                       linewidth=1.5, label=f"Max SOC = {device.params['SOC_max']}%")
            ax2.axhline(y=device.params['SOC_Target'], color='#FFD600', linestyle='--', 
                       linewidth=1.5, label=f"Target SOC = {device.params['SOC_Target']}%")
            ax2.set_xlabel('Time [h]', fontsize=11)
            ax2.set_ylabel('SOC [%]', fontsize=11)
            ax2.set_title(f'Battery {device.device_id} - State of Charge', fontsize=13, fontweight='bold')
            ax2.legend(loc='best', fontsize=9)
            ax2.grid(True, alpha=0.3)
            ax2.set_facecolor('#f8f9fa')
            
            # 3) Variabile di controllo
            ax3 = fig.add_subplot(3, 1, 3)
            ax3.plot(time_hours, beta_opt, 'purple', linewidth=2.5, label=f'Control Variable (β)')
            ax3.axhline(y=0, color='k', linestyle='-', linewidth=0.8)
            ax3.set_xlabel('Time [h]', fontsize=11)
            ax3.set_ylabel('Control Value', fontsize=11)
            ax3.set_title(f'Battery {device.device_id} - Control Variable', fontsize=13, fontweight='bold')
            ax3.legend(loc='best', fontsize=10)
            ax3.grid(True, alpha=0.3)
            ax3.set_facecolor('#f8f9fa')
            
            fig.tight_layout(pad=2.0)
        
        # Assegna i metodi all'optimizer
        self.optimizer.generate_combined_plot_on_figure = generate_combined_plot_on_figure
        self.optimizer.generate_energy_balance_plot_on_figure = generate_energy_balance_plot_on_figure
        self.optimizer.generate_control_plot_on_figure = generate_control_plot_on_figure
        self.optimizer.generate_weather_plot_on_figure = generate_weather_plot_on_figure
        self.optimizer.generate_device_plot_on_figure = generate_device_plot_on_figure
        self.optimizer.generate_battery_plot_on_figure = generate_battery_plot_on_figure
    
    def show_plots_page(self):
        """Mostra tutte le figure in finestre separate in stile Spyder."""
        if not self.optimizer or not self.optimizer.results:
            messagebox.showerror("Error", "No simulation results available. Please run optimization first.")
            return
        
        try:
            # Chiude eventuali finestre aperte in precedenza
            for window in self.figure_windows:
                if window and window.winfo_exists():
                    window.destroy()
            
            self.figure_windows = []
            
            # ========== GRAFICI AGGREGATI (ESISTENTI) ==========
            # 1. Grafico combinato (3 subplot)
            combined_fig = SpyderStyleFigure(
                self.parent, self.optimizer, "generation_profile", "Combined System Overview")
            window = combined_fig.show()
            self.figure_windows.append(window)
            
            # 2. Bilancio energetico
            balance_fig = SpyderStyleFigure(
                self.parent, self.optimizer, "energy_balance", "Energy Balance")
            window = balance_fig.show()
            self.figure_windows.append(window)
            
            # 3. Variabili di controllo
            control_fig = SpyderStyleFigure(
                self.parent, self.optimizer, "control_variables", "Control Variables")
            window = control_fig.show()
            self.figure_windows.append(window)
            
            # 4. Dati meteo (solo se ci sono PV o Wind)
            has_weather_devices = any(isinstance(d, (PVGenerator, WindGenerator)) 
                                    for d in self.optimizer.devices)
            if has_weather_devices:
                weather_fig = SpyderStyleFigure(
                    self.parent, self.optimizer, "weather_data", "Weather Data")
                window = weather_fig.show()
                self.figure_windows.append(window)
            
            # ========== NUOVI GRAFICI INDIVIDUALI PER OGNI DISPOSITIVO ==========
            
            # Grafici individuali per TUTTI i generatori a combustibile
            for device in self.optimizer.devices:
                if isinstance(device, FuelGenerator):
                    # Crea grafico individuale con 2 subplot
                    device_fig = SpyderStyleFigure(
                        self.parent, self.optimizer, f"device_energy_{device.device_id}", 
                        f"Fuel Generator {device.device_id} - Individual Analysis")
                    window = device_fig.show()
                    self.figure_windows.append(window)
            
            # Grafici individuali per tutti i generatori fotovoltaici
            for device in self.optimizer.devices:
                if isinstance(device, PVGenerator):
                    # Crea grafico individuale con 2 subplot
                    device_fig = SpyderStyleFigure(
                        self.parent, self.optimizer, f"device_energy_{device.device_id}", 
                        f"PV Generator {device.device_id} - Individual Analysis")
                    window = device_fig.show()
                    self.figure_windows.append(window)
            
            # Grafici individuali per TUTTI i generatori eolici
            for device in self.optimizer.devices:
                if isinstance(device, WindGenerator):
                    # Crea grafico individuale con 2 subplot
                    device_fig = SpyderStyleFigure(
                        self.parent, self.optimizer, f"device_energy_{device.device_id}", 
                        f"Wind Generator {device.device_id} - Individual Analysis")
                    window = device_fig.show()
                    self.figure_windows.append(window)
            
            # Grafici individuali per TUTTE le batterie (3 subplot ciascuna)
            for device in self.optimizer.devices:
                if isinstance(device, Battery):
                    # Grafico potenza batteria e SOC
                    battery_fig = SpyderStyleFigure(
                        self.parent, self.optimizer, f"battery_profile_{device.device_id}", 
                        f"Battery {device.device_id} - Individual Analysis")
                    window = battery_fig.show()
                    self.figure_windows.append(window)
            
        except Exception as e:
            import traceback
            traceback.print_exc()
            messagebox.showerror("Error", f"Error generating plots: {str(e)}")


class MicrogridOffGridStatistics:
    """Classe per visualizzare le statistiche della microgrid OFF-GRID."""
    
    def __init__(self, parent, optimizer):
        """
        Inizializza il visualizzatore delle statistiche.
        
        Args:
            parent: Il widget tkinter genitore
            optimizer: L'oggetto MicrogridOptimizer con i risultati
        """
        self.parent = parent
        self.optimizer = optimizer
    
    def show_statistics(self):
        """Mostra una finestra con le statistiche della simulazione."""
        if not self.optimizer or not self.optimizer.results:
            messagebox.showerror("Error", "No simulation results available. Please run optimization first.")
            return
        
        # Crea una nuova finestra
        stats_window = tk.Toplevel(self.parent)
        stats_window.title("Off-Grid System Statistics")
        stats_window.geometry("800x600")
        
        # Frame principale
        main_frame = ttk.Frame(stats_window, padding="10")
        main_frame.pack(fill=tk.BOTH, expand=True)
        
        # TextBox per le statistiche
        stats_text = self.get_statistics_text()
        text_box = scrolledtext.ScrolledText(main_frame, wrap=tk.WORD, font=("Courier New", 10))
        text_box.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        text_box.insert(tk.END, stats_text)
        text_box.config(state=tk.DISABLED)
        
        # Pulsanti per esportare i dati e chiudere
        button_frame = ttk.Frame(main_frame)
        button_frame.pack(fill=tk.X, pady=10)
        
        ttk.Button(button_frame, text="Close", command=stats_window.destroy).pack(side=tk.RIGHT, padx=5)
        ttk.Button(button_frame, text="Export Statistics", 
                  command=lambda: self.export_statistics(stats_text)).pack(side=tk.RIGHT, padx=5)
    
    def get_statistics_text(self):
        """Genera il testo delle statistiche formattato."""
        if not self.optimizer.results:
            return "No results to analyze."
        
        stats_text = "=== OFF-GRID SYSTEM STATISTICS ===\n\n"
        
        # Statistiche per ogni dispositivo
        for device in self.optimizer.devices:
            stats = device.get_statistics(self.optimizer.results)
            device_type = device.__class__.__name__
            
            stats_text += f"{device_type} ({device.device_id}):\n"
            for name, value in stats.items():
                # Converti valori CasADi in tipi Python standard
                if hasattr(value, 'full'):
                    value = float(value.full().flatten()[0])
                    
                if name.endswith('_total_energy'):
                    stats_text += f" - Total energy: {float(value):.2f} kWh\n"
                elif name.endswith('_fuel_consumption') or name.endswith('_F_comb'):
                    stats_text += f" - Fuel consumption: {float(value):.2f} kg\n"
                elif name.endswith('_liters_of_diesel'):
                    if value is not None:
                        stats_text += f" - Diesel volume: {float(value):.2f} L\n"
                elif name.endswith('_num_starts') or name.endswith('_N_acc'):
                    stats_text += f" - Number of starts: {int(value)}\n"
                elif name.endswith('_total_exchanged'):
                    stats_text += f" - Energy exchanged: {float(value):.2f} kWh\n"
                elif name.endswith('_net_energy'):
                    sign = "discharge" if value > 0 else "charge"
                    stats_text += f" - Net energy ({sign}): {abs(float(value)):.2f} kWh\n"
                elif name.endswith('_final_SOC'):
                    stats_text += f" - Final SOC: {float(value):.2f}%\n"
                elif name.endswith('_min_SOC'):
                    stats_text += f" - Min SOC: {float(value):.2f}%\n"
                elif name.endswith('_max_SOC'):
                    stats_text += f" - Max SOC: {float(value):.2f}%\n"
            
            stats_text += "\n"
        
        # Statistiche carichi
        total_load_energy = 0
        for load in self.optimizer.loads:
            load_energy = np.sum(load.params['C']) * hours_per_interval
            total_load_energy += load_energy
            stats_text += f"Load ({load.load_id}):\n"
            stats_text += f" - Total energy: {load_energy:.2f} kWh\n\n"
        
        # Statistiche slack variables
        stats_text += "System Performance:\n"             
        # Calcolare potenza totale generata per ogni timestep
        P_tot = np.zeros(N)
        
        # Somma generatori e batterie
        for device in self.optimizer.devices:
            device_power_key = f"{device.device_id}_G_opt"
            if device_power_key in self.optimizer.results:
                P_tot += np.array(self.optimizer.results[device_power_key])
            
            # Aggiungi potenza batteria se presente
            battery_power_key = f"{device.device_id}_P_batt_opt"
            if battery_power_key in self.optimizer.results:
                P_tot += np.array(self.optimizer.results[battery_power_key])
        
        # Calcola carico totale per ogni timestep
        total_load = np.zeros(N)
        for load in self.optimizer.loads:
            for i in range(N):
                total_load[i] += load.get_load(i)
        
        # Calcola mismatch massimo
        mismatch = np.max(np.abs(P_tot - total_load))
        
        stats_text += f" - Max power mismatch: {mismatch:.6f} kW\n"
        slack_load_up = np.sum(self.optimizer.results["slack_load_up_opt"])
        slack_load_down = np.sum(self.optimizer.results["slack_load_down_opt"])
        slack_SOC = self.optimizer.results["slack_SOC_opt"]
        
        stats_text += f" - Total load slack (up): {slack_load_up:.6f} kWh\n"
        stats_text += f" - Total load slack (down): {slack_load_down:.6f} kWh\n"
        stats_text += f" - SOC slack: {slack_SOC:.2f}%\n"
        
        # Bilancio energetico
        total_generation = 0
        for device in self.optimizer.devices:
            if hasattr(device, 'get_statistics'):
                stats = device.get_statistics(self.optimizer.results)
                for key, value in stats.items():
                    if key.endswith('_total_energy') and not isinstance(device, Battery):
                        if hasattr(value, 'full'):
                            value = float(value.full().flatten()[0])
                        total_generation += float(value)
        
        stats_text += f"\nEnergy Balance:\n"
        stats_text += f" - Total generation: {total_generation:.2f} kWh\n"
        stats_text += f" - Total load demand: {total_load_energy:.2f} kWh\n"
        stats_text += f" - Balance: {total_generation - total_load_energy:.2f} kWh\n"
        
 # === Max mismatch details ===
        mismatch_profile = P_tot - total_load
        max_mismatch = np.max(np.abs(mismatch_profile))
        
        # SOGLIA PER CONSIDERARE IL MISMATCH TRASCURABILE
        MISMATCH_THRESHOLD = 1e-3  # 1 mW
        
        if max_mismatch < MISMATCH_THRESHOLD:
            stats_text += f"\n✅ Perfect power balance achieved! (max mismatch: {max_mismatch:.6f} kW - negligible)\n"
        else:
            idx = int(np.argmax(np.abs(mismatch_profile)))
            mismatch_val = mismatch_profile[idx]
            
            load_at_idx = total_load[idx]
            pv_kW = sum(
                self.optimizer.results[f"{d.device_id}_G_opt"][idx]
                for d in self.optimizer.devices if isinstance(d, PVGenerator)
            )
            wind_kW = sum(
                self.optimizer.results[f"{d.device_id}_G_opt"][idx]
                for d in self.optimizer.devices if isinstance(d, WindGenerator)
            )
            slack_up = self.optimizer.results["slack_load_up_opt"][idx]
            slack_down = self.optimizer.results["slack_load_down_opt"][idx]
            
            stats_text += f"\n⚠️ Significant mismatch detected: {mismatch_val:.3f} kW (timestep {idx})\n"
            stats_text += f" - Load: {load_at_idx:.3f} kW\n"
            stats_text += f" - Renewables (PV+Wind): {pv_kW + wind_kW:.3f} kW (PV {pv_kW:.3f} / Wind {wind_kW:.3f})\n"
            
            for d in self.optimizer.devices:
                g = self.optimizer.results.get(f"{d.device_id}_G_opt", [0]*N)[idx]
                b = self.optimizer.results.get(f"{d.device_id}_P_batt_opt", [0]*N)[idx]
                stats_text += f" - {d.device_id}: G = {g:.3f} kW, P_batt = {b:.3f} kW\n"
            
            stats_text += f" - Slack up: {slack_up:.3f} kW\n"
            stats_text += f" - Slack down: {slack_down:.3f} kW\n"

        return stats_text
    
    def export_statistics(self, stats_text):
        """Esporta le statistiche in un file di testo."""
        output_file = filedialog.asksaveasfilename(
            title="Save Statistics",
            defaultextension=".txt",
            filetypes=(("Text files", "*.txt"), ("All files", "*.*"))
        )
        
        if output_file:
            try:
                with open(output_file, 'w', encoding='utf-8') as f:
                    f.write(stats_text)
                messagebox.showinfo("Success", f"Statistics saved to {output_file}")
            except Exception as e:
                messagebox.showerror("Error", f"Failed to save statistics: {e}")