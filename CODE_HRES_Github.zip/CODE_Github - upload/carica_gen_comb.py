import pandas as pd
from update_gen_comb_ca import *
from CONFIGURA import *  

def carica_gen_comb(excel_filename, sheetname_gen_comb):
    # Prima legge i dati di generatore a combustibile dalla colonna B, skiprows=5, nrows=6
    dati_gen_comb = pd.read_excel(
        excel_filename,
        sheet_name=sheetname_gen_comb,
        usecols='B',
        skiprows=5,
        nrows=6,
        header=None
    ).values.flatten()
    
    gen_comb = {}
    
    # Legge il nome del combustibile (colonna B, skiprows=4)
    gen_comb['comb'] = pd.read_excel(
        excel_filename,
        sheet_name=sheetname_gen_comb,
        usecols='B',
        skiprows=4,
        header=None
    ).iloc[0, 0]
    
    gen_comb['sheetname'] = sheetname_gen_comb
    
    # Converti PCI da MJ/kg a kJ/kg
    gen_comb['PCI'] = dati_gen_comb[0]  # MJ/kg
    gen_comb['cF'] = dati_gen_comb[1]   # Costo combustibile [€/kg]
    gen_comb['PN'] = dati_gen_comb[2]   # Potenza nominale [kWe]
    gen_comb['N_acc_max'] = dati_gen_comb[3]  # Numero massimo di accensioni [-]
    gen_comb['c_acc'] = dati_gen_comb[4]      # Coeff. penalizzazione accensione [€/N_acc]
    gen_comb['P_min'] = dati_gen_comb[5]      # Potenza minima tecnica [kWe]
    
    # Legge la densità del combustibile (colonna G, skiprows=15)
    ro_values = pd.read_excel(
        excel_filename,
        sheet_name=sheetname_gen_comb,
        usecols='G',
        skiprows=15,
        nrows=1,
        header=None
    ).values.flatten()
    gen_comb['ro'] = float(ro_values[0])
    
    # Legge i valori di efficienza (colonne B:C, skiprows=20, nrows=5)
    eta_values_raw = pd.read_excel(
        excel_filename,
        sheet_name=sheetname_gen_comb,
        usecols="B:C",
        skiprows=20,
        nrows=5,
        header=None
    )
    gen_comb['eta_values'] = [
        eta_values_raw.iloc[:, 0].values / gen_comb['PN'],
        eta_values_raw.iloc[:, 1].values
    ]
    
    # Legge un alpha di default dalla colonna M (skiprows=4, nrows=800)
    gen_comb['alpha'] = pd.read_excel(
        excel_filename,
        sheet_name=sheetname_gen_comb,
        usecols="M",
        skiprows=4,
        header=None,
        nrows=800
    ).values.flatten()
    
    gen_comb['n_x'] = N
    
    # Aggiorna con la funzione di update
    gen_comb = update_gen_comb_ca(gen_comb, gen_comb['alpha'])
    
    return gen_comb
