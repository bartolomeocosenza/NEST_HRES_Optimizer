import numpy as np
import matplotlib.cm as cm 
import matplotlib.pyplot as plt
import casadi as ca
import pandas as pd
from abc import ABC, abstractmethod
from typing import List, Dict, Any, Optional, Tuple
from CONFIGURA import *

class Device(ABC):
    """Base abstract class for all energy devices in the microgrid."""
    
    def __init__(self, device_id: str, excel_filename: str, sheet_name: str):
        self.device_id = device_id
        self.excel_filename = excel_filename
        self.sheet_name = sheet_name
        self.params = {}  
        
    @abstractmethod
    def load_parameters(self) -> None:
        """Load device parameters from Excel file."""
        pass
    
    @abstractmethod
    def create_control_variables(self, opti: ca.Opti) -> Dict[str, ca.MX]:
        """Create device control variables for the optimization problem."""
        pass
    
    @abstractmethod
    def add_constraints(self, opti: ca.Opti, variables: Dict[str, Any], timestep: int) -> None:
        """Add device constraints to the optimization problem for a specific timestep."""
        pass
    
    @abstractmethod
    def add_to_objective(self, opti: ca.Opti, variables: Dict[str, Any]) -> ca.MX:
        """Add device-specific terms to the objective function."""
        pass
    
    @abstractmethod
    def calculate_power_output(self, variables: Dict[str, Any], timestep: int) -> float:
        """Calculate device power output for a specific timestep."""
        pass
    
    @abstractmethod
    def calculate_power_output_casadi(self, variables: Dict[str, Any], timestep: int) -> ca.MX:
        """Calculate device power output for a specific timestep using CasADi variables."""
        pass
    
    @abstractmethod
    def extract_results(self, sol: ca.OptiSol, variables: Dict[str, Any]) -> Dict[str, Any]:
        """Extract optimization results for this device."""
        pass
    
    @abstractmethod
    def plot_results(self, time_hours: np.ndarray, results: Dict[str, Any], ax=None) -> None:
        """Plot device-specific results."""
        pass
    
    @abstractmethod
    def get_statistics(self, results: Dict[str, Any]) -> Dict[str, float]:
        """Calculate and return device statistics."""
        pass



