import casadi as ca
import numpy as np
from piecewise_linear import *

def update_gen_comb_ca(gen_comb, alpha):
    """
    Aggiorna i campi 'F' (consumo combustibile) e 'G' (potenza generata) 
    in base al valore di controllo alpha (da 0 a 1).
    Restituisce un dizionario con le stesse chiavi di gen_comb, più 
    'F', 'G', 'theta', 'W', 'Psi', 'N_acc'.
    """
    # Caricamento dei parametri di ingresso
    PN = gen_comb['PN']       # Potenza nominale [kWe]
    P_min = gen_comb['P_min'] # Potenza minima [kWe]
    PCI = gen_comb['PCI']     # Potere calorifico inferiore [kJ/kg]
    N_acc_max = gen_comb['N_acc_max']  # Numero massimo di accensioni
    eta_values = np.array(gen_comb['eta_values'])
    
    # Calcolo di alpha_min
    alpha_min = P_min / PN
    
    # Calcolo di F, G, F_sig, G_sig, theta, theta_sig
    F, G, F_sig, G_sig, theta, theta_sig = calcola_FG(gen_comb, alpha)
    
    # Calcolo di Psi e N_acc (se alpha è un vettore)
    if hasattr(alpha, '__len__') or isinstance(alpha, (ca.MX, ca.SX)):
        if isinstance(alpha, (ca.MX, ca.SX)) and alpha.shape[0] > 1:
            Psi, Psi_sig, N_acc, N_acc_sig = calcola_Psi_vettoriale(alpha, alpha_min, N_acc_max)
        elif hasattr(alpha, '__len__') and len(alpha) > 1:
            Psi, Psi_sig, N_acc, N_acc_sig = calcola_Psi_vettoriale(alpha, alpha_min, N_acc_max)
        else:
            # Scalare o vettore di lunghezza 1
            Psi = -1.0  # (0/(2*N_acc_max) - 1)
            Psi_sig = -1.0
            N_acc = 0.0
            N_acc_sig = 0.0
    else:
        # Se alpha è scalare, Psi e N_acc sono 0
        Psi = -1.0
        Psi_sig = -1.0
        N_acc = 0.0
        N_acc_sig = 0.0
    
    # Uscita W
    W = G
    
    # Output per verificare se il generatore può avere incentivo 
    G_Upsilon = 0.0
    if 'comb' in gen_comb and isinstance(gen_comb['comb'], list) and len(gen_comb['comb']) > 0:
        if gen_comb['comb'][0] == 'biomassa':
            G_Upsilon = G
    
    # Aggiorna il dizionario 
    gen_comb['F'] = F
    gen_comb['G'] = G
    gen_comb['F_sig'] = F_sig
    gen_comb['G_sig'] = G_sig
    gen_comb['theta'] = theta
    gen_comb['theta_sig'] = theta_sig
    gen_comb['W'] = W
    gen_comb['Psi'] = Psi
    gen_comb['N_acc'] = N_acc
    gen_comb['G_Upsilon'] = G_Upsilon
    gen_comb['alpha'] = alpha
   
    return gen_comb

def sigmoid_ca(alpha, alpha_min):
    """
    Implementa una funzione sigmoidea per approssimare la funzione a gradino.
    Restituisce sia la funzione a gradino esatta (theta) che la versione sigmoidea (theta_sig).
    
    pendenza a = 20
    """
    theta = ca.if_else(alpha >= alpha_min, 1.0, 0.0)  # theta esatto (discontinuo)
    a = 20  # Parametro di pendenza della sigmoidea 
    theta_sig = 1 / (1 + ca.exp(-a * (alpha - alpha_min)))  # theta approssimato (continuo)
    return theta, theta_sig

def calcola_Psi_vettoriale(alpha, alpha_min, N_acc_max):
    """
    Calcola Psi e N_acc per un vettore alpha.
       
    Parametri:
    - alpha: vettore di controllo del generatore
    - alpha_min: soglia di potenza minima per considerare il generatore acceso
    - N_acc_max: numero massimo di avviamenti consentiti
    
    Restituisce Psi, Psi_sig, N_acc, N_acc_sig
    """
    
    if isinstance(alpha, (ca.MX, ca.SX)):
        # Per variabili CasADi 
        n = alpha.shape[0]
        
        # Passo 1: Calcolo di theta e theta_sig per ogni elemento 
        theta_vec = []
        theta_sig_vec = []
        
        for i in range(n):
            theta_i, theta_sig_i = sigmoid_ca(alpha[i], alpha_min)
            theta_vec.append(theta_i)
            theta_sig_vec.append(theta_sig_i)
        
        theta = ca.vertcat(*theta_vec)
        theta_sig = ca.vertcat(*theta_sig_vec)
        
        if n > 1:
            # Passo 2: Calcolo delle differenze 
            Delta_theta = []
            Delta_theta_sig = []
            for i in range(1, n):
                Delta_theta.append(theta[i] - theta[i-1])
                Delta_theta_sig.append(theta_sig[i] - theta_sig[i-1])
            
            Delta_theta = ca.vertcat(*Delta_theta)
            Delta_theta_sig = ca.vertcat(*Delta_theta_sig)
            
            # Passo 3: Calcolo di Psi 
            # Psi = (sum(abs(Delta_theta)))/(2*N_acc_max)-1
            sum_abs_delta = 0
            sum_abs_delta_sig = 0
            for i in range(Delta_theta.shape[0]):
                sum_abs_delta += ca.fabs(Delta_theta[i])
                sum_abs_delta_sig += ca.fabs(Delta_theta_sig[i])
            
            Psi = sum_abs_delta / (2 * N_acc_max) - 1
            Psi_sig = sum_abs_delta_sig / (2 * N_acc_max) - 1
            
            # Passo 4: Calcolo di N_acc ( sum(Delta_theta > 0))
            N_acc = 0
            N_acc_sig = 0
            for i in range(Delta_theta.shape[0]):
                N_acc += ca.if_else(Delta_theta[i] > 0, 1.0, 0.0)
                N_acc_sig += ca.if_else(Delta_theta_sig[i] > 0, 1.0, 0.0)
        else:
            # Un solo timestep - nessuna transizione
            Psi = -1.0  # (0/(2*N_acc_max) - 1)
            Psi_sig = -1.0
            N_acc = 0.0
            N_acc_sig = 0.0
            
    else:
        # Per array NumPy 
        theta, theta_sig = sigmoid_numpy(alpha, alpha_min)
        
        # diff() 
        Delta_theta = np.diff(theta)
        Delta_theta_sig = np.diff(theta_sig)
        
        # Formule 
        Psi = (np.sum(np.abs(Delta_theta))) / (2 * N_acc_max) - 1
        Psi_sig = (np.sum(np.abs(Delta_theta_sig))) / (2 * N_acc_max) - 1
        N_acc = np.sum(Delta_theta > 0)
        N_acc_sig = np.sum(Delta_theta_sig > 0)
    
    return Psi, Psi_sig, N_acc, N_acc_sig

def calcola_Psi(alpha, alpha_min, N_acc_max, use_sigmoid=False):
    """
    Se use_sigmoid=False ritorna N_acc, se True ritorna N_acc_sig.
    """
    Psi, Psi_sig, N_acc, N_acc_sig = calcola_Psi_vettoriale(alpha, alpha_min, N_acc_max)
    
    if use_sigmoid:
        return N_acc_sig
    else:
        return N_acc

def calcola_FG(gen_comb, alpha):
    """
    Calcola il consumo di combustibile (F) e la potenza generata (G)
    utilizzando sia la versione discreta che quella sigmoidea.
    
    G = phi1*theta.*alpha;
    F = phi2.*theta.*alpha./eta;
    """
    PN = gen_comb['PN']       # Potenza nominale [kWe]
    P_min = gen_comb['P_min'] # Potenza minima [kWe]
    PCI = gen_comb['PCI']     # Potere calorifico inferiore [kJ/kg]
    eta_values = np.array(gen_comb['eta_values'])
    
    # Calcolo G e Nabla_G 
    alpha_min = P_min / PN
    theta, theta_sig = sigmoid_ca(alpha, alpha_min)
    
    # Calcolo G 
    phi1 = PN
    G = phi1 * theta * alpha
    G_sig = phi1 * theta_sig * alpha
    
    # Calcolo F 
    phi2 = (PN / (1000 * PCI)) * 3600
    
    # Interpolazione Rendimento eta_alpha 
    eta = piecewise_linear_ca1(eta_values[1], eta_values[0], alpha) / 100.0
    
    F = phi2 * theta * alpha / eta
    F_sig = phi2 * theta_sig * alpha / eta
    
    return F, G, F_sig, G_sig, theta, theta_sig

def sigmoid_numpy(alpha, alpha_min):
    """
    Versione NumPy della funzione sigmoid per compatibilità.
    Pendenza a = 20
    """
    theta = (alpha >= alpha_min).astype(float)  # theta esatto (discontinuo)
    a = 20  
    theta_sig = 1.0 / (1.0 + np.exp(-a * (alpha - alpha_min)))  # theta approssimato (continuo)
    return theta, theta_sig

