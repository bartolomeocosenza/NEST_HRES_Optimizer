import numpy as np
# Configurazione globale per il sistema di ottimizzazione energetica

# Parametri temporali
N = 96    # numero di intervalli su 24h (con step di 15 min)
tau = 15  # minuti per intervallo
hours_per_interval = tau/60.0
time_hours = np.arange(N)*0.25

# Percorsi dei file
excel_filename = 'DEVICES.xlsx'
load_filename = 'LOAD.xlsx'
weather_filename = 'WEATHER.xlsx'
tariffa = 'Tariffa.xlsx'

# Nomi dei fogli comuni
SHEET_GEN_COMB = 'gen_comb'
SHEET_GEN_FOTO = 'gen_foto'
SHEET_GEN_EOLI = 'gen_eoli'
SHEET_CARICO = 'carico_L1f'
SHEET_ACCUMULATORE = 'accumulatore'
SHEET_METEO = 'Meteo5'

# =============== Risolutore ===============
# Risolutore con parametri più aggressivi
opts = {
    'ipopt.max_iter': 5000,  # Riduci da 20000
    'ipopt.tol': 1e-4,  # Aumenta da 1e-4
    'ipopt.constr_viol_tol': 1e-4,  # Aumenta da 1e-4
    'ipopt.acceptable_tol': 1e-3,  # Aumenta da 1e-3
    'ipopt.acceptable_iter': 12,  # Riduci da 15
    'ipopt.print_level': 4,  # Riduci da 5 per meno output
    'print_time': 0,
    'ipopt.mu_strategy': 'adaptive',
    'ipopt.linear_solver': 'mumps',
    'ipopt.warm_start_init_point': 'yes',  # IMPORTANTE: warm start
    'ipopt.warm_start_bound_push': 1e-6,
    'ipopt.warm_start_mult_bound_push': 1e-6,
    'ipopt.nlp_scaling_method': 'gradient-based',  # Scaling automatico
    'ipopt.derivative_test': 'none'  # Disabilita test derivate per velocità
}
# Pesi obiettivo per sistema grid-connected winter, summer, spring
P_fuel = 0.001        # Peso costo combustibile
P_comb = 0.001        # Peso penalizzazione variazioni generatore combustibile
P_acc = 0.01         # 0.0001  Peso penalizzazione variazioni batteria
P_grid = 0.03        # Peso per lo scambio con la rete (1.0 = priorità massima)
P_wind = -0.001          #incentivo rinnovabili eolico
P_foto = -0.001           #incentivo rinnovabili solare
P_slack_load = 1.0  # Peso per slack load
P_slack_soc = 1.0   # Peso per slack SOC

DEFAULT_TEMPERATURE = 25.0  # °C - temperatura default per PV
DEFAULT_DNI = 0.0          # W/m² - irraggiamento default per PV
EMERGENCY_LOAD = 5.0       # kW - carico di emergenza se lettura fallisce
#P_penality = 0.01

# # Pesi obiettivo RICALIBRATI per valorizzare il generatore SIMULAZIONE AUTUNNO
# P_fuel = 0.0001       # RIDOTTO: meno peso al costo combustibile
# P_comb = 0.01         # AUMENTATO: penalizza meno le accensioni
# P_acc = 0.01          # OK: mantieni per stabilità batteria
# P_grid = 0.01         # AUMENTATO: valorizza di più lo scambio con rete
# P_wind = 0            # Azzerato: già favorito naturalmente
# P_foto = 0            # Azzerato: già favorito naturalmente
# P_slack_load = 1000.0 # Aumentato per garantire fattibilità
# P_slack_soc = 10.0    # Ridotto per più flessibilità SOC


