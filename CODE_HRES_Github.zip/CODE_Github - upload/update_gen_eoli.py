import numpy as np
from casadi import*
import pandas as pd
import casadi as ca
from CONFIGURA import * 


def update_gen_eoli(gen_eoli, alpha):
    """
    Versione corretta della prima funzione 
    """
    # Caricamento dei parametri di ingresso
    v_min = gen_eoli['v_min']  # v_{\min}: velocità minima del vento [m/s]
    v_max = gen_eoli['v_max']  # v_{\max}: velocità massima del vento [m/s]
    PN = gen_eoli['PN']
    Pmin = 0
    fk_values = gen_eoli['fk_values']  # Curva caratteristica della macchina f_k(v)
  
    if 'v' not in gen_eoli:
            v = np.zeros(N)
    else:
            v = gen_eoli['v']     
    
    # Inizializzare array fk
    fk = np.zeros(N)
    # Check curva caratteristica
    for i in range(N):
        # Controllare le velocità massime e minime
        if v[i] <= v_min or v[i] >= v_max:
            fk[i] = 0
        else: 
            for j in range(len(fk_values) - 1):
                if fk_values[j][0] <= v[i] <= fk_values[j + 1][0]:
                    fk[i] = fk_values[j][1] + ((fk_values[j + 1][1] - fk_values[j][1]) / (fk_values[j + 1][0] - fk_values[j][0])) * (v[i] - fk_values[j][0])
                    break  
             
    phi = fk
    gen_eoli['alpha'] = alpha
    gen_eoli['G'] = phi * alpha
    gen_eoli['W'] = gen_eoli['G']
    return gen_eoli

# SECONDA FUNZIONE CASADI 
def update_gen_eoli_ca(gen_eoli, alpha, i):
    """
    Versione CasADi della funzione update_gen_eoli
    Opera su un singolo valore invece che su tutto l'array
    """
    v = gen_eoli['v'][i]
    v_min = gen_eoli['v_min']
    v_max = gen_eoli['v_max']
    fk_values = gen_eoli['fk_values']
    
    # Potenza iniziale
    fk = 0.0
    
    # Controllare velocità massime e minime
    if (v <= v_min) or (v >= v_max):
        fk = 0.0
    else:
        # Controllare intervalli in curva caratteristica
        for j in range(len(fk_values) - 1):
            if (v >= fk_values[j][0]) and (v <= fk_values[j + 1][0]):
                # linear interpolation y = y0 +[(y1-y0)/(x1-x0)](x - x0)
                fk = fk_values[j][1] + ((fk_values[j+1][1] - fk_values[j][1]) / 
                                        (fk_values[j+1][0] - fk_values[j][0])) * (v - fk_values[j][0])
                break
    
    G = fk * alpha
    return {'G': G}