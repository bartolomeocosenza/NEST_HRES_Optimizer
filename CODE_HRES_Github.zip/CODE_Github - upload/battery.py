import numpy as np
import casadi as ca
from abc import ABC, abstractmethod
from typing import List, Dict, Any, Optional, Tuple
from CONFIGURA import *
from carica_accumulatore import carica_accumulatore
from device_base import Device
from update_accumulatore_ca_x import update_accumulatore_ca_x, calculate_psi_parameters, Psi_func

class Battery(Device):
    """
    Class representing a battery
    β > 0  ⇒  CHARGE   (SOC↑ , potenza assorbita W<0)
    β < 0  ⇒  DISCHARGE (SOC↓ , potenza erogata W>0)
    """
    
    def __init__(self, device_id: str, excel_filename: str, sheet_name: str):
        super().__init__(device_id, excel_filename, sheet_name)
        self.load_parameters()
        
    def load_parameters(self) -> None:
        """Load battery parameters from Excel file."""
      
        self.params = carica_accumulatore(self.excel_filename, self.sheet_name)
        print(f"[DEBUG] Battery {self.device_id} - SOC_0 from Excel: {self.params.get('SOC_0', 'NOT FOUND')}")
        print(f"[DEBUG] Battery {self.device_id} - AS (autoscarica): {self.params.get('AS', 'NOT FOUND')}")
            
        
        # Calcola parametri psi per SOC
        
        self.psi2_acc, self.psi3_acc = calculate_psi_parameters(self.params, N, tau)
        self.beta_min = self.params['beta_min0']
        
    def create_control_variables(self, opti: ca.Opti) -> Dict[str, ca.MX]:
        """Create control variables for battery."""
        beta = opti.variable(N)  # [-1, 1] control variable for charge/discharge
        return {"beta": beta}
        
    def add_constraints(self, opti: ca.Opti, variables: Dict[str, Any], timestep: int) -> None:
        """Add constraints for battery at a specific timestep."""
        beta = variables[f"{self.device_id}_beta"][timestep]
        
        # Vincoli sui bounds di beta
        opti.subject_to(-1 <= beta)
        opti.subject_to(beta <= 1)
        
        # Vincoli SOC per questo timestep 
        if f"{self.device_id}_SOC" in variables:
            SOC = variables[f"{self.device_id}_SOC"]
            opti.subject_to(SOC[timestep] >= self.params['SOC_min'])
            opti.subject_to(SOC[timestep] <= self.params['SOC_max'])
    
    def add_to_objective(self, opti: ca.Opti, variables: Dict[str, Any]) -> ca.MX:
        """Add battery smoothing term to objective and calculate global SOC."""
        beta = variables[f"{self.device_id}_beta"]
        
        # Calcola SOC globale usando Psi_func 

        Psi, SOC = Psi_func(self.params, self.psi2_acc, self.psi3_acc, beta, self.beta_min)
        
        # Salva SOC nelle variables per uso in vincoli e risultati finali
        variables[f"{self.device_id}_SOC"] = SOC
        variables[f"{self.device_id}_Psi"] = Psi
        
        # Smoothing term per penalizzare variazioni brusche
        smoothing = ca.sum1(beta**2)
        """per rendere la batteria più sensibile al prezzo dell'energia"""        
        return P_acc * smoothing      
    
    def add_final_constraints(self, opti: ca.Opti, variables: Dict[str, Any], slack_SOC: ca.MX) -> None:
        """Add final constraints for battery (SOC target with slack variable)."""
        SOC = variables[f"{self.device_id}_SOC"]
        
        # Vincolo SOC finale con slack variable
        opti.subject_to(SOC[-1] + slack_SOC >= self.params['SOC_Target'])
        opti.subject_to(SOC[-1] <= self.params['SOC_max'])
        
    """per rendere la batteria più libera"""          
    # def add_final_constraints(self, opti: ca.Opti, variables: Dict[str, Any], slack_SOC: ca.MX) -> None:
    #     
    #     SOC = variables[f"{self.device_id}_SOC"]
    
    #     # Vincolo finale SOC morbido, range più ampio del target fisso
    #     opti.subject_to(SOC[-1] >= 40)  # Limite inferiore desiderato
    #     opti.subject_to(SOC[-1] <= 90)  # Limite superiore desiderato
        
        
    def calculate_power_output(self, variables: Dict[str, Any], timestep: int) -> float:
        """Calculate power output for a specific timestep using numpy values."""
    
        beta = variables[f"{self.device_id}_beta_opt"][timestep]
        params_copy = self.params.copy()  # Copia
        return update_accumulatore_ca_x(params_copy, beta)['W'] 
    
    def calculate_power_output_casadi(self, variables: Dict[str, Any], timestep: int) -> ca.MX:
        """Calculate power output for a specific timestep using CasADi variables."""
        
        beta = variables[f"{self.device_id}_beta"][timestep]
        params_copy = self.params.copy()  # Copia
        return update_accumulatore_ca_x(params_copy, beta)['W'] 
        
    def extract_results(self, sol: ca.OptiSol, variables: Dict[str, Any]) -> Dict[str, Any]:
        """Extract optimization results for this battery."""
      
        
        beta_opt = sol.value(variables[f"{self.device_id}_beta"])
        SOC_opt = sol.value(variables[f"{self.device_id}_SOC"])
        
        # Calcola potenze ottime per ogni timestep
        P_batt_opt = np.zeros(N)
        for i in range(N):
            params_copy = self.params.copy()  # Copia
            out_batt = update_accumulatore_ca_x(params_copy, beta_opt[i])
            P_batt_opt[i] = float(out_batt['W'])
        
        return {
            f"{self.device_id}_beta_opt": beta_opt,
            f"{self.device_id}_SOC_opt": SOC_opt,
            f"{self.device_id}_P_batt_opt": P_batt_opt
        }
        
    def plot_results(self, time_hours: np.ndarray, results: Dict[str, Any], ax=None) -> None:
        """Plot battery results."""
        # Non fare nulla, i grafici individuali sono disabilitati
        pass
        
    def get_statistics(self, results: Dict[str, Any]) -> Dict[str, float]:
        """Calculate and return battery statistics."""
        SOC_opt = results[f"{self.device_id}_SOC_opt"]
        P_batt_opt = results[f"{self.device_id}_P_batt_opt"]
        
        # Energia di carica e scarica 
        charge_energy = np.sum(np.maximum(0, -P_batt_opt)) * hours_per_interval  # W < 0 = carica (β > 0)
        discharge_energy = np.sum(np.maximum(0, P_batt_opt)) * hours_per_interval  # W > 0 = scarica (β < 0)
        
        # Energia totale scambiata
        total_exchanged = charge_energy + discharge_energy
        
        # Energia netta (positiva = scarica netta, negativa = carica netta)
        net_energy = discharge_energy - charge_energy
        
        # Statistiche SOC
        final_SOC = SOC_opt[-1]
        min_SOC = np.min(SOC_opt)
        max_SOC = np.max(SOC_opt)
        
        return {
            f"{self.device_id}_charge_energy": charge_energy,
            f"{self.device_id}_discharge_energy": discharge_energy,
            f"{self.device_id}_total_exchanged": total_exchanged,
            f"{self.device_id}_net_energy": net_energy,
            f"{self.device_id}_final_SOC": final_SOC,
            f"{self.device_id}_min_SOC": min_SOC,
            f"{self.device_id}_max_SOC": max_SOC
        }