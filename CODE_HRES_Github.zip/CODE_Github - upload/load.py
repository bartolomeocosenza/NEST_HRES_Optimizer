import numpy as np
import matplotlib.cm as cm 
import matplotlib.pyplot as plt
import casadi as ca
import pandas as pd
from abc import ABC, abstractmethod
from typing import List, Dict, Any, Optional, Tuple
from CONFIGURA import *

from device_base import Device

class Load:
    """Class representing an electrical load."""
    
    def __init__(self, load_id: str, load_filename: str, sheet_name: str):
        self.load_id = load_id
        self.load_filename = load_filename
        self.sheet_name = sheet_name
        self.load_parameters()
        
    def load_parameters(self) -> None:
        import pandas as pd
        import numpy as np
        from CONFIGURA import N
    
        print(f"[DEBUG] Inizio caricamento carico dal file '{self.load_filename}', foglio '{self.sheet_name}'")
    
        try:
            
            df = pd.read_excel(
                self.load_filename,
                sheet_name=self.sheet_name,
                usecols='B',    
                skiprows=3,      
                header=None
            )
    
            data = df.iloc[:, 0].values
    
            numeric_data = []
            for i, val in enumerate(data):
                if pd.isna(val):
                    numeric_data.append(0.0)
                    print(f"[ATTENZIONE] Valore NaN alla riga {i+4}, impostato a 0.0")
                else:
                    try:
                        numeric_data.append(float(str(val).replace(',', '.')))
                    except ValueError:
                        numeric_data.append(0.0)
                        print(f"[ATTENZIONE] Valore non convertibile '{val}' alla riga {i+4}, impostato a 0.0")
    
            numeric_data = np.array(numeric_data)
    
            if len(numeric_data) < N:
                numeric_data = np.pad(numeric_data, (0, N - len(numeric_data)), 'edge')
                print(f"[ATTENZIONE] Solo {len(numeric_data)} valori trovati, estesi fino a {N}")
            elif len(numeric_data) > N:
                numeric_data = numeric_data[:N]
                print(f"[ATTENZIONE] {len(numeric_data)} valori trovati, troncati a {N}")
    
            self.params = {
                'C': numeric_data,
                'W': -numeric_data,
                'sheetname': self.sheet_name
            }
    
            print(f"[SUCCESSO] Carico caricato correttamente dal foglio '{self.sheet_name}'.")
            print(f"Range valori carico: min={numeric_data.min():.2f}, max={numeric_data.max():.2f}, media={numeric_data.mean():.2f}")
    
        except Exception as e:
            print(f"[ERRORE] caricamento carico fallito: {e}. Carico di emergenza 5kW attivato.")
            carico_values = np.ones(N) * EMERGENCY_LOAD
            self.params = {
                'C': carico_values,
                'W': -carico_values,
                'sheetname': 'emergency_load'
            }

        
    def get_load(self, timestep: int) -> float:
        """Get load value for a specific timestep."""
        return self.params['C'][timestep]



