import pandas as pd
from CONFIGURA import *
def carica_carico_L1(excel_filename, sheetname_carico_L1):

    carico_L1 = {}
    carico_L1['sheetname'] = sheetname_carico_L1

    # Carica i dati dalla colonna B 
    carico_L1['C'] = pd.read_excel(excel_filename, sheet_name=SHEET_CARICO, usecols='B', skiprows=3, nrows=800, header=None).values.flatten()
    # Calcola la colonna W come negativo di C
    carico_L1['W'] = -carico_L1['C']

    # Stampa il dizionario carico_L1
    #print(carico_L1)

    # Restituisci il dizionario
    return carico_L1
