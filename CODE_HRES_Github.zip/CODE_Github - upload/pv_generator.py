import numpy as np
import matplotlib.cm as cm 
import matplotlib.pyplot as plt
import casadi as ca
import pandas as pd
from abc import ABC, abstractmethod
from typing import List, Dict, Any, Optional, Tuple
from CONFIGURA import *
from update_gen_foto import update_gen_foto_ca
from device_base import Device
from carica_gen_foto import carica_gen_foto

class PVGenerator(Device):
    """Class representing a photovoltaic generator."""
    
    def __init__(self, device_id: str, excel_filename: str, sheet_name: str, weather_filename: str, meteo_sheet: str = ""):
        super().__init__(device_id, excel_filename, sheet_name)
        self.weather_filename = weather_filename
        self.meteo_sheet = meteo_sheet
        self.load_parameters()
        
    def find_column_name(self, df: pd.DataFrame, possible_names: list) -> str:
        """Trova il nome della colonna tra le possibili alternative."""
        for name in possible_names:
            if name in df.columns:
                return name
        return None
        
    def load_parameters(self) -> None:
        """Load PV generator parameters from Excel file."""
        
        
        # Carica parametri base
        self.params = carica_gen_foto(self.excel_filename, self.sheet_name)
        
        try:
            # carica dati meteo separatamente
            meteo_data = pd.read_excel(self.weather_filename, sheet_name=self.meteo_sheet)
            
            print(f"Weather file columns: {list(meteo_data.columns)}")
            
            # Lista di possibili nomi per la temperatura
            temp_names = ['Ta(i)', 'Ta', 'Temperature', 'Temp', 'T_amb', 'T_air']
            temp_col = self.find_column_name(meteo_data, temp_names)
            
            # Lista di possibili nomi per l'irraggiamento solare 
            dni_names = ['DNI(i)', 'DNI', 'Solar_Irradiance', 'Irradiance', 'GHI', 'GlobalIrradiance']
            dni_col = self.find_column_name(meteo_data, dni_names)
            
            if temp_col is None:
                print(f"Warning: Temperature column not found. Available columns: {list(meteo_data.columns)}")
                print("Using default temperature values (25°C)")
                self.params['Ta'] = np.full(N, DEFAULT_TEMPERATURE)  # Default temperature
            else:
                print(f"Using temperature column: {temp_col}")
                
                self.params['Ta'] = meteo_data[temp_col].values[:N]
                
            if dni_col is None:
                print(f"Warning: DNI column not found. Available columns: {list(meteo_data.columns)}")
                print("Using default DNI values (0 W/m²)")
                self.params['DNI'] = np.full(N, DEFAULT_DNI)  # Default DNI (no solare)
            else:
                print(f"Using DNI column: {dni_col}")               
                self.params['DNI'] = meteo_data[dni_col].values[:N]
                
            # Verifica che i dati abbiano la lunghezza corretta
            if len(self.params['Ta']) < N:
                print(f"Warning: Temperature data has only {len(self.params['Ta'])} values, need {N}")
                # Estendi con l'ultimo valore o valori di default
                missing_count = N - len(self.params['Ta'])
                last_value = self.params['Ta'][-1] if len(self.params['Ta']) > 0 else 25.0
                self.params['Ta'] = np.concatenate([self.params['Ta'], np.full(missing_count, last_value)])
                
            if len(self.params['DNI']) < N:
                print(f"Warning: DNI data has only {len(self.params['DNI'])} values, need {N}")
                # Estendi con l'ultimo valore o zero
                missing_count = N - len(self.params['DNI'])
                last_value = self.params['DNI'][-1] if len(self.params['DNI']) > 0 else 0.0
                self.params['DNI'] = np.concatenate([self.params['DNI'], np.full(missing_count, last_value)])
            
            # Assicurati che i valori DNI siano non negativi
            self.params['DNI'] = np.maximum(self.params['DNI'], 0)
            # Validazione dati meteo
            if np.any(self.params['Ta'] < -273.15):
                print(f"Warning: Invalid temperature values detected (< -273.15°C), setting to default")
                self.params['Ta'][self.params['Ta'] < -273.15] = DEFAULT_TEMPERATURE
            
            if np.any(self.params['DNI'] < 0):
                print(f"Warning: Negative DNI values detected, setting to 0")
                self.params['DNI'] = np.maximum(self.params['DNI'], 0)
            print(f"Loaded weather data - Ta range: [{np.min(self.params['Ta']):.1f}, {np.max(self.params['Ta']):.1f}]°C")
            print(f"Loaded weather data - DNI range: [{np.min(self.params['DNI']):.1f}, {np.max(self.params['DNI']):.1f}] W/m²")
            
        except Exception as e:
            print(f"Error loading weather data: {e}")
            print("Using default weather values")
            # Valori di default se il caricamento fallisce
            self.params['Ta'] = np.full(N, 25.0)  # 25°C costante
            self.params['DNI'] = np.zeros(N)      # Non c'è sole
        
    def create_control_variables(self, opti: ca.Opti) -> Dict[str, ca.MX]:
        """Create control variables for PV generator."""
        alpha = opti.variable(N)  # [0, 1] control variable
        return {"alpha": alpha}
        
    def add_constraints(self, opti: ca.Opti, variables: Dict[str, Any], timestep: int) -> None:
        """Add constraints for PV generator at a specific timestep."""
        alpha = variables[f"{self.device_id}_alpha"][timestep]
        
        # Se non c'è irradiazione solare il fotovoltaico dovrebbe essere spento
        if self.params['DNI'][timestep] < 1e-6:
            opti.subject_to(alpha == 0)
        else:
            opti.subject_to(0 <= alpha)
            opti.subject_to(alpha <= 1)
        
    def add_to_objective(self, opti: ca.Opti, variables: Dict[str, Any]) -> ca.MX:
        """Add PV cost term to objective (if any)."""
        alpha = variables[f"{self.device_id}_alpha"]
        
        # Nel caso ci fosse qualche cost/penalty per usare il fotovoltaico, allora va aggiunta qui.
   
        return P_foto * ca.sum1(alpha) #if 'P_foto' in globals() else 0
        
    def calculate_power_output(self, variables: Dict[str, Any], timestep: int) -> float:
        """Calculate power output for a specific timestep using numpy values."""
      
        alpha = variables[f"{self.device_id}_alpha_opt"][timestep]
        return update_gen_foto_ca(self.params, alpha, timestep)['G']
    
    def calculate_power_output_casadi(self, variables: Dict[str, Any], timestep: int) -> ca.MX:
        """Calculate power output for a specific timestep using CasADi variables."""
      
        
        alpha = variables[f"{self.device_id}_alpha"][timestep]
        return update_gen_foto_ca(self.params, alpha, timestep)['G']
        
    def extract_results(self, sol: ca.OptiSol, variables: Dict[str, Any]) -> Dict[str, Any]:
        """Extract optimization results for this generator."""
        
        
        
        alpha_opt = sol.value(variables[f"{self.device_id}_alpha"])
        
        # Calcola i valori ottimali di potenza 
        G_opt = np.zeros(N)
        for i in range(N):
            G_opt[i] = update_gen_foto_ca(self.params, alpha_opt[i], i)['G']
            
        return {
            f"{self.device_id}_alpha_opt": alpha_opt,
            f"{self.device_id}_G_opt": G_opt
        }
        
    def plot_results(self, time_hours: np.ndarray, results: Dict[str, Any], ax=None) -> None:
        """Plot PV generator results."""
        # Non fare nulla, i grafici individuali sono disabilitati
        pass
        
    def get_statistics(self, results: Dict[str, Any]) -> Dict[str, float]:
        """Calculate and return generator statistics."""
        G_opt = results[f"{self.device_id}_G_opt"]
        total_energy = np.sum(G_opt) * hours_per_interval
            
        return {
            f"{self.device_id}_total_energy": total_energy
        }