import numpy as np
from casadi import*
import pandas as pd
import casadi as ca
from CONFIGURA import * 

def update_gen_foto(gen_foto, alpha):
    """
    Versione NumPy dell'aggiornamento del generatore fotovoltaico.
    Utilizza i parametri meteo (Ta, DNI) già presenti nel dizionario gen_foto.
    """
    # Caricamento dei parametri di ingresso
    DNIr = gen_foto['DNIr']  # DNI_r: irraggiamento di riferimento [1000 W/m^2]
    gamma = gen_foto['gamma']  # gamma(k): coefficiente di correzione della potenza [°C^-1]
    Tr = gen_foto['Tr']  # T_r: temperatura di riferimento [°C]
    c = gen_foto['c']  # c(k): coefficiente di tilt per il pannello [-]
    r = gen_foto['r']  # r(k): coefficiente correttivo di Ross [°C m^2/W]
    eta = gen_foto['eta']  # eta(k): rendimento complessivo di sistema [-]
    Delta_Tr = gen_foto['Delta_Tr']  # Delta T_r(k): differenza di temperatura standard [°C]
    PN = gen_foto['PN']  # PN(k): potenza nominale [kWe]
    
    
    if 'Ta' not in gen_foto or 'DNI' not in gen_foto:
        Ta = np.zeros(N)
        DNI = np.zeros(N)
    else:
        Ta = gen_foto['Ta']  # T_a(i): temperatura ambiente [°C]
        DNI = gen_foto['DNI']  # Radiazione solare diretta [W/m2]
     
    # Inizializzazione del vettore di potenza G
    G = np.zeros(len(alpha) if isinstance(alpha, np.ndarray) else 1)
    
    for i in range(len(G)):
        idx = min(i, len(DNI)-1)  # Protezione contro indici fuori range
        DNIa = c * DNI[idx]
        Tc = Ta[idx] + r * DNIa
        Tb = Tc - (DNIa / DNIr) * Delta_Tr
        phi = (DNIa / DNIr) * PN * (1 + gamma * (Tb - Tr)) * eta
        
        # Calcolo potenza
        G[i] = phi * (alpha[i] if isinstance(alpha, np.ndarray) else alpha)
    
    gen_foto['type'] = 'gen_foto'
    gen_foto['G'] = G
    gen_foto['alpha'] = alpha

    # Uscita W
    gen_foto['W'] = gen_foto['G']

    return gen_foto


def update_gen_foto_ca(gen_foto, alpha, i):
      """
      Versione CasADi dell'aggiornamento del generatore fotovoltaico.
      Calcola la potenza in funzione di alpha per il timestep i.
      """
      DNIr = gen_foto['DNIr']
      gamma = gen_foto['gamma']
      Tr = gen_foto['Tr']
      c = gen_foto['c']
      r = gen_foto['r']
      eta = gen_foto['eta']
      Delta_Tr = gen_foto['Delta_Tr']
      PN = gen_foto['PN']
      
      Ta = gen_foto['Ta'][i]
      DNI = gen_foto['DNI'][i]
      
      DNIa = c * DNI
      Tc = Ta + r * DNIa
      Tb = Tc - (DNIa / DNIr) * Delta_Tr
      phi = (DNIa / DNIr) * PN * (1 + gamma * (Tb - Tr)) * eta
      
      G = phi * alpha
      
      return {'G': G}